Windows HTML update · 16 October 2026

The approved calculation engines, ephemeris tables, original KP ayanamsha,
Raphael interpolation/rounding, LMT, sidereal time and Vimshottari code are
unchanged from backup/pre-html-chart-workspace-2026-10-16 (84dc301).

Changes:
- Explicit manual cusp input, validation, automatic reset and .lkp persistence.
- Chart Update / Cusp Setting Tool / Save controls and Ascendant/Moon transition list.
- Named navigation menu, chart typography and astrologer planet-colour controls.
- Bhav Phal and separate Bhavanusar Phal, using existing uploaded source text.
- Selected MD, AD or PD interpretations rather than combining every active lord.
- Transit interpretations count whole-sign houses from the natal Moon sign.
  Aries Moon + Saturn Pisces selects SaTransitH12. All 144 sign pairs checked.
- Current-DBA transit workflow; Sun tracks explicitly include MD, AD and PD.
  Entry/exit dates are transit conditions, not guaranteed life-event dates.
- Existing Vedic and KP gemstone rules displayed together; rules are unchanged.
- Duplicate South chart report tables removed. A4 margins, wrapping and flow retained.
- Editable astrologer name/address/contact printed separately from the fixed
  Software Developer Name: Nitin Rajendra Talegaonkar, Mob: +918412098690.
- 82 supplied event-rule documents, searchable Rules editor, Save, JSON backup
  import/export and A4 preview/print. Custom rules are included in .lkp backups.
  Rule text is reference data and is never evaluated as JavaScript.

Validation:
PASS: approved calculation reference across recalculation, UI changes and .lkp reload.
PASS: five chart/prediction workflow checks, including manual cusp reset/reload,
      current DBA, selected dasha, Moon-relative transit lookup and South A4 PDF.
PASS: all available report sections rendered to A4 PDF with text inside margins.
PASS: Rules add/save/chart-backup roundtrip and selected-rule one-page A4 PDF.
PASS: original script bytes preserved except the five documented interpretation
      and presentation adapters. No original calculation engine was changed.

Only the standalone HTML is released in this update. Installers and APKs are
not rebuilt. The application version numbers and activation code are unchanged.

Compact navigation and dark-mode follow-up:
- Eleven main entries: Home, View, Prediction, Tools, Basic Information,
  Western aspects, Reference, Print report, South Indian kundali,
  Astrologer settings and About. Related functions use dropdown menus.
- Small N / H / IP / Open / TC / EPh / Settings / Notepad / Tutorial shortcuts.
- Chart font, Update Chart, Cusp Setting Tool, Save and Ascendant/Moon controls
  appear below the kundali. The extra readable-list panel is removed.
- Dark-mode chart labels use transparent backgrounds and tables use matching
  dark surfaces with readable text. These rules apply only on screen.
- Original calculation scripts remain byte-identical to release 1173663.
- Transit Panchang keeps one daily summary; the repeated instant-summary grid
  is suppressed when the daily panel is available and removed from its report.

Gemstone purpose ranking follow-up:
- Rule dropdown retains KP event-based and the existing Vedic rule.
- KP recommends the planet(s) whose existing four-fold significators cover the
  greatest number of unique relevant event houses. Duplicate house references
  count once. All tied positive leaders are shown; no matches means no recommendation.
- The sixteen requested purposes and result labels appear in Marathi / English.
- Relevant houses are visible and editable, with their reference source shown.
- Controlling anger uses the owner's explicit 1,5,9 house group.
- All wishes uses house 11, the KP house of fulfilment of desires.
- Vedic Lagnesh/Panchamesh/Labhesh (1,5,11) remains unchanged.
- Gemstone selection changes are explicitly requested by the owner; natal,
  planetary, Raphael, ayanamsha, LMT, ST and Vimshottari formulas are untouched.

Startup and panel follow-up:
- The old full icon toolbar is hidden by a head stylesheet before first paint.
- The new menu starts without the previous 500 ms delay.
- The ◉ shortcut-row choice is saved and restored on reopening.
- A visible ☰ button restores access to the left navigation panel and uses the
  existing saved sidebar preference. Desktop content shifts when the panel opens.
- The live RP popup starts below the header and navigation menu, with correct
  stacking and viewport limits so the menu cannot cut through its content.
- No calculation scripts or source data are changed by these layout fixes.

- Compact Horary results controls: bounded desktop width, shorter side-by-side question/opinion fields, responsive mobile layout. Existing result calculations and A4 report output are unchanged.
