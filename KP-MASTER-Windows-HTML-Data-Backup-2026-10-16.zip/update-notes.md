Windows HTML update · 16 October 2026

The approved calculation engines, ephemeris tables, original KP ayanamsha,
Raphael interpolation/rounding, LMT, sidereal time and Vimshottari code are
unchanged from backup/pre-html-chart-workspace-2026-10-16 (84dc301).

Changes:
- Explicit manual cusp input, validation, automatic reset and .lkp persistence.
- Chart Update / Cusp Setting Tool / Save controls and Ascendant/Moon transition list.
- Named navigation menu, chart typography and astrologer planet-colour controls.
- Bhav Phal and separate Bhavanusar Phal, using existing uploaded source text.
- Selected MD, AD or PD interpretations rather than combining every active lord.
- Transit interpretations count whole-sign houses from the natal Moon sign.
  Aries Moon + Saturn Pisces selects SaTransitH12. All 144 sign pairs checked.
- Current-DBA transit workflow; Sun tracks explicitly include MD, AD and PD.
  Entry/exit dates are transit conditions, not guaranteed life-event dates.
- Existing Vedic and KP gemstone rules displayed together; rules are unchanged.
- Duplicate South chart report tables removed. A4 margins, wrapping and flow retained.
- Editable astrologer name/address/contact printed separately from the fixed
  Software Developer Name: Nitin Rajendra Talegaonkar, Mob: +918412098690.
- 82 supplied event-rule documents, searchable Rules editor, Save, JSON backup
  import/export and A4 preview/print. Custom rules are included in .lkp backups.
  Rule text is reference data and is never evaluated as JavaScript.

Validation:
PASS: approved calculation reference across recalculation, UI changes and .lkp reload.
PASS: five chart/prediction workflow checks, including manual cusp reset/reload,
      current DBA, selected dasha, Moon-relative transit lookup and South A4 PDF.
PASS: all available report sections rendered to A4 PDF with text inside margins.
PASS: Rules add/save/chart-backup roundtrip and selected-rule one-page A4 PDF.
PASS: original script bytes preserved except the five documented interpretation
      and presentation adapters. No original calculation engine was changed.

Only the standalone HTML is released in this update. Installers and APKs are
not rebuilt. The application version numbers and activation code are unchanged.
