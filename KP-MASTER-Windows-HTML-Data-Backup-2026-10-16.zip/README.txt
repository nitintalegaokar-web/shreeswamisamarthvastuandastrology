KP Master — Windows HTML update, 16 October 2026

Open KP-MASTER-Windows-Updated-2026-10-16.html in Chrome or Edge.
Use the existing Open chart action to load your .lkp chart backups.
Rules is available in the menu and Prediction tab. Use Export rules backup
for your added rules; they are also included when saving a chart.

This archive includes the updated HTML, the previous HTML as a backup,
all supplied prediction and rule source files, and their data catalogues.
Your existing personal charts/browser storage are not collected into this archive.
Use the application's existing Save/backup actions for your personal data.

Calculation engines and version numbers are unchanged. Explicit manual cusp
changes can be restored to automatic mode in Cusp Setting Tool.
See update-notes.md for validation and feature details.
