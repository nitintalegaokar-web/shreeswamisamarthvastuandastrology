window.KP_DEFAULT_LOGO="";
