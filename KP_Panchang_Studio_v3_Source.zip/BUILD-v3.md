# KP Panchang Studio 3.0 build

The app is payload/index.html, with every adjacent file and directory preserved.
The Windows launcher uses Edge's app window, with the default browser as fallback.
The packaged app does not require Python, Node.js, an account or a running server.

## Rebuild

Use Node.js 20+, Python 3, and NSIS 3.11. From this directory:

```
npm ci
npm run build:mdb
npm run build:assets
makensis launcher.nsi
makensis installer-v3.nsi
```

The output is dist/KP_Panchang_Studio_v3_Setup.exe. The script installs only
payload files and includes explicit uninstall entries, preserving unknown files.

## Logo and places

File > Choose logo accepts an exact PNG/JPG/WebP file locally. File > Import
places accepts MDB/ACCDB/CSV/JSON, previews and maps city and coordinate columns,
and stores all valid places in IndexedDB. Distinct places with the same city
name are retained; imports report invalid rows separately. The Places library
searches the complete saved catalog without rendering all rows at once.

To embed a default logo, put the original PNG at payload/assets/logo.png, then
run build-assets.py. Optionally provide payload/assets/logo.ico to brand the
Windows launcher and installer icons, then rebuild both executables.
To embed places, create payload/cities.js as window.KP_CITIES=[...]; each item
needs city, latitude and longitude and may include state and country. Only use
validated real source records. No AllPlaces records or exact logo are claimed
to be bundled in this build: the source MDB exceeded the chat's 32 MiB transfer
limit and the logo was supplied as an inline image without a readable file ID.

## Data generation and scientific provenance

The UI and printable reports use the user-requested KP EPHEMERIES branding.
Numerical generation uses the external pyswisseph 2.10.3.2 / Swiss Ephemeris
2.10.03 Moshier implementation. Its binary/library is not in the installed app;
only calculated data is shipped. Preserve this provenance in development records.
The horizon solution uses Greenwich apparent sidereal time, date-specific true
obliquity, nutation and Krishnamurti ayanamsa; the eastern horizon branch is
selected explicitly, including polar cases. Source-reference tests cover 75
selected-city cases over 1900–2500. Panchang remains Pune/IST; selected places
change the Kundali only, which the settings and About dialog make explicit.

```
python3 -m pip install --target python-tools -r requirements.txt
PYTHONPATH=python-tools python3 generate.py --start 1900 --end 2500
PYTHONPATH=python-tools python3 validate-data.py
PYTHONPATH=python-tools python3 check-city-geometry.py
```

Linux source builds may require CC=gcc CXX=g++. No verification is disabled.
All 601 year files must be shipped together. Generation stores additional
midnight/sidereal geometry and boundary days for cross-year Paksha reports.

## Tests

Start `npm start` in one terminal (local HTTP on port 8091). In another:

```
node validate-v3.cjs
node check-print-v3.cjs
node check-city-geometry.cjs
node check-independent.cjs
node check-sunrise.cjs
```

Chromium defaults to /usr/bin/chromium. Poppler pdfinfo/pdftotext are needed for
PDF page checks. The reference MDB fixture is from andipaetzold/mdb-reader,
commit 3dc637a9732db79a3bf67506b82a4f83cf07e6a9, test/data/V2000/test.mdb;
its MIT license is included in tests/fixtures/LICENSE.txt. This validates MDB
parsing/import, not the schema or contents of the inaccessible AllPlaces file.

Tests verify north chart fill and house geometry, Pisces-first south ordering,
file/menu actions, city import and persistence, a real MDB file, logo selection,
settings restore, self-contained HTML, SVG export, and mobile layout. All four
modern/traditional landscape/portrait leap-year books have 12 sheets; north and
south standalone Kundali reports each have one portrait sheet. A 219,511-day
coverage audit and 1,202 daily recomputations verify generated date completeness.

Linux Chromium blocks file URLs in this environment. Native Windows install,
shortcuts, uninstall and direct-file startup still require a Windows run. The
installer is unsigned. Browser/file-profile storage settings may affect saved
places and preferences; use File > Export places and Save settings for backups.
