
(()=>{'use strict';
function split(doc){
 const first=doc?.querySelector('.report-page[data-report-section="aspects"]:not([data-aspect-page])');if(!first)return;
 const second=first.cloneNode(true),firstTitle=first.querySelector('.report-page-title'),secondTitle=second.querySelector('.report-page-title');
 first.dataset.aspectPage='planet';second.dataset.aspectPage='cusp';
 if(firstTitle)firstTitle.textContent='13. Western Aspects · Planet to planet';if(secondTitle)secondTitle.textContent='14. Western Aspects · Planet to cusp';
 first.querySelector('[data-aspect-chart="cusp"]')?.remove();second.querySelector('[data-aspect-chart="planet"]')?.remove();
 first.after(second);
}
function install(){
 const render=window.renderReport;if(render)window.renderReport=function(...args){const result=render.apply(this,args);split(document);return result;};window.renderReport?.();
 const old=window.KPReportPreview;if(!old)return false;window.KPReportPreview=Object.freeze({...old,open(id){const win=old.open(id);if(win&&id==='aspects'){
  const sources=[...document.querySelectorAll('#printReport>[data-report-section="aspects"]')];
  if(sources.length>1&&win.document.querySelectorAll('[data-report-section="aspects"]').length===1)win.document.body.append(win.document.importNode(sources[1],true));
 }return win;}});return true;
}
let tries=0;const timer=setInterval(()=>{if(install()||++tries>50)clearInterval(timer);},25);
})();

