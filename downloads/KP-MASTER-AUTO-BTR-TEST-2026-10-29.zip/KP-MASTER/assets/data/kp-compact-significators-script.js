
(()=>{'use strict';
function init(){const tab=document.getElementById('karyesh'),page=tab.querySelector('.karyesh-page'),tools=page.querySelector('.kp-tab-tools'),method=document.getElementById('sig-method'),event=document.querySelector('#sig-nadi-significators .home-nadi-event');
 tools.id='sig-compact-toolbar';tools.querySelector('label[for="sig-method"]').textContent='Method';document.getElementById('significators-preview').textContent='Preview / PDF';tab.prepend(tools);tools.append(event);event.id='sig-event-tools';const status=document.getElementById('kp-status');tools.append(status);
 const options=document.createElement('details');options.id='sig-options';options.className='no-print';const summary=document.createElement('summary');summary.textContent='Details';const content=document.createElement('div');content.className='sig-options-content';const help=document.createElement('p');help.id='sig-method-help';content.append(help,page.querySelector('.kp-intro'),page.querySelector('.kp-settings'));options.append(summary,content);tools.append(options);
 for(const id of ['kp-fourfold','kp-sixfold']){const section=document.getElementById(id),headings=[...section.querySelectorAll('h4')],pair=document.createElement('div');pair.className='sig-table-pair';for(const heading of headings){const table=heading.nextElementSibling,article=document.createElement('article');article.append(heading,table);pair.append(article);}section.querySelector('.kp-key').after(pair);}
 function sync(){const isNadi=method.value==='nadi-astrology';event.hidden=!isNadi;const source=document.getElementById(method.value);help.textContent=isNadi?'Nadi: planet → star lord → sub lord. House colours and underlines indicate the selected event’s supporting and opposing houses.':source?.querySelector('.kp-key')?.textContent||'';}
 method.addEventListener('change',sync);const title=()=>{status.title=status.textContent;};new MutationObserver(title).observe(status,{childList:true,subtree:true});title();sync();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();})();

