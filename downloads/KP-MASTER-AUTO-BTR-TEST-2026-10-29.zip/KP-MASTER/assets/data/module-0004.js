
document.addEventListener("DOMContentLoaded",()=>{
  const buttons=document.querySelectorAll("nav button[data-tab]");
  const tabs=document.querySelectorAll("main > section.tab");
  buttons.forEach(btn=>{
    btn.addEventListener("click",()=>{
      const id=btn.dataset.tab;
      buttons.forEach(b=>b.classList.toggle("active",b===btn));
      tabs.forEach(t=>t.classList.toggle("active",t.id===id));
      if(id==="south9"){
        if(typeof calculateAll==="function") calculateAll();
        else if(typeof renderChart==="function") renderChart(false);
      }
      if(id==="report" && typeof renderReport==="function") renderReport();
    });
  });
  // Initial render so South Indian Kundali is never blank after loading the file.
  setTimeout(()=>{
    if(typeof calculateAll==="function") calculateAll();
    else if(typeof renderChart==="function") renderChart();
  },0);
});

