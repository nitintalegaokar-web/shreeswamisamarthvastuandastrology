
document.addEventListener("DOMContentLoaded",()=>{
  ["dayAyan","daySum"].forEach(id=>{
    const el=document.getElementById(id);
    if(el) el.addEventListener("input",()=>{updateTotalAyanamsha();updateLongitudeDifference();updateLMTCalculation();updateSiderealTimeCalculation(); updateSampattikTimeDifferences();calculateAll();});
  });
  updateTotalAyanamsha();
  updateLongitudeDifference();
});

