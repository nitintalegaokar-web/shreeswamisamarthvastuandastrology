
// FINAL FIX: Tab 6 दैनिक गती must always calculate directly from the two
// manually entered planetary positions, independent of the other calculations.
(function(){
  function parseDmsForDaily(v){
    if(v==null) return NaN;
    const a=String(v).trim().split(':').map(Number);
    if(a.length<2 || a.some(x=>!Number.isFinite(x))) return NaN;
    return a[0]*3600 + a[1]*60 + (a[2]||0);
  }
  function formatDaily(sec){
    const neg=sec<0;
    let x=Math.abs(Math.round(sec));
    const d=Math.floor(x/3600); x%=3600;
    const m=Math.floor(x/60); const s=x%60;
    return `${String(d).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}${neg?' R':''}`;
  }
  function updateDailyMotionDirect(){
    for(let i=0;i<9;i++){
      const a=document.getElementById('p6_d_'+i);
      const b=document.getElementById('p6_t_'+i);
      const out=document.getElementById('p6_motion_'+i);
      const totalOut=document.getElementById('p6_total_'+i);
      if(!a||!b||!out) continue;
      const av=parseDmsForDaily(a.value), bv=parseDmsForDaily(b.value);
      if(!Number.isFinite(av)||!Number.isFinite(bv)||!String(a.value).trim()||!String(b.value).trim()){
        out.value='';
        if(totalOut) totalOut.value='';
        continue;
      }
      // Exact requested rule: upper/first position minus lower/second position.
      const diff=av-bv;
      // Rahu and Ketu remain without an R marker even when negative.
      const isNode=(i===7||i===8);
      const text=formatDaily(diff);
      out.value=isNode ? text.replace(/\s*R$/,'') : text;

      // एकूण = तास + मिनिटे. दोन्ही values वेळेच्या स्वरूपात (HH:MM:SS) घेतल्या जातात.
      if(totalOut){
        const hp=document.getElementById('p6_hours_'+i);
        const mp=document.getElementById('p6_minutes_'+i);
        const hs=parseDmsForDaily(hp?.value||'');
        const ms=parseDmsForDaily(mp?.value||'');
        totalOut.value=(Number.isFinite(hs)&&Number.isFinite(ms)) ? formatDaily(hs+ms).replace(/\s*R$/,'') : '';
      }
    }
  }
  window.updateDailyMotionDirect=updateDailyMotionDirect;
  document.addEventListener('DOMContentLoaded',function(){
    updateDailyMotionDirect();
    for(let i=0;i<9;i++){
      ['p6_d_'+i,'p6_t_'+i].forEach(id=>{
        const e=document.getElementById(id);
        if(e){
          e.addEventListener('input',updateDailyMotionDirect);
          e.addEventListener('change',updateDailyMotionDirect);
          e.addEventListener('blur',updateDailyMotionDirect);
        }
      });
    }
    for(let i=0;i<9;i++){
      ['p6_hours_'+i,'p6_minutes_'+i].forEach(id=>{
        const e=document.getElementById(id);
        if(e){ e.addEventListener('input',updateDailyMotionDirect); e.addEventListener('change',updateDailyMotionDirect); e.addEventListener('blur',updateDailyMotionDirect); }
      });
    }
    ['p6_date_1','p6_date_2','p6_time_1','p6_time_2','p6_ampm_1','p6_ampm_2','planet6BirthAmPm'].forEach(id=>{
      const e=document.getElementById(id);
      if(e){ e.addEventListener('change',()=>{ try{ renderPlanets(window.lastPlanetPositions||{}, parseDmsForDaily(document.getElementById('ayanValue')?.value||'22:48:18')); }catch(_){ } }); }
    });
  });
})();

