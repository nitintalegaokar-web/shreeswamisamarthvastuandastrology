
(()=>{'use strict';const $=id=>document.getElementById(id);
function detail(node,label){if(!node||node.closest('.mm-simple-options'))return;const d=document.createElement('details');d.className='mm-simple-options';const h=document.createElement('summary');h.textContent=label;node.before(d);d.append(h,node);return d;}
function init(){
 const section=$('matchmaking');
 for(const kind of ['boy','girl']){
   const grid=$('mm-'+kind+'-name')?.closest('.mm-grid');if(!grid)continue;
   const d=document.createElement('details');d.className='mm-birth-advanced';const h=document.createElement('summary');h.textContent='Coordinates, UTC offset and DST';d.append(h);grid.after(d);
   for(const suffix of ['timezone','dst','latitude','longitude']){const n=$('mm-'+kind+'-'+suffix);if(n)d.append(n.parentElement);}
 }
 detail(section.querySelector('.mm-reference-main .mm-controls'),'Mangal Dosha settings');
 section.querySelector('.mm-reference-main>.mm-note')?.remove();section.querySelector('.mm-analysis-picker>p')?.remove();
 const footer=section.querySelector('.mm-reference-footer');if(footer){for(const button of footer.querySelectorAll('button'))if(!['mm-calculate','mm-save-memo','mm-close'].includes(button.id))button.hidden=true;const calculate=$('mm-calculate');if(calculate)calculate.textContent='Calculate / Preview';}
 const controls=section.querySelector('#mm-kp-panel>.kp-feature-actions');if(controls){
   const d=document.createElement('details');d.className='mm-marriage-options';d.innerHTML='<summary>Marriage search options</summary>';
   controls.after(d);for(const n of [...controls.children]){if(n.contains($('mm-kp-find'))||n.id==='mm-kp-find'||n.id==='mm-kp-cancel'||n.contains($('mm-kp-date')))continue;d.append(n);}
   const date=$('mm-kp-date');if(date)date.closest('label')?.removeAttribute('hidden');
 }
 section.querySelectorAll('details').forEach(d=>d.open=false);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(init,0));else init();})();

