
(() => {
  'use strict';
  const DAY=86400000, ORDER=['Ke','Ve','Su','Mo','Ma','Ra','Ju','Sa','Me'];
  const YEARS={Ke:7,Ve:20,Su:6,Mo:10,Ma:7,Ra:18,Ju:16,Sa:19,Me:17};
  const EVENTS={marriage:[2,7,11],career:[2,6,10,11],child:[2,5,11],education:[4,9,11],property:[4,11,12],foreign:[3,9,12],recovery:[1,5,11],legal:[6,10,11],wealth:[2,11]};
  const $=id=>document.getElementById(id), value=id=>$(id)?.value||'';
  const codes=()=>window.KPDisplay.ids, code=name=>window.KPDisplay.idByName[name]||name;
  const escape=text=>String(text??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const delta=(a,b)=>((b-a+540)%360)-180;
  let results=[], version=0, running=false, refreshTimer, natalSignature=null, periodSignature=null;
  function invalidateChangedNatalCalculations(){
    const model=window.currentKPModel;
    const signature=JSON.stringify({birth:value('dob'),birthTime:value('birthTime'),birthZone:value('stdLon'),ayanamsha:value('ayanValue'),ayanamshaSource:value('kp-ayanamsha-source'),ready:Boolean(model?.ready),
      planets:model?.planets?.map(planet=>[planet.id,planet.longitude]),houses:model?.houses?.map(house=>[house.id,house.longitude]),
      periods:(window.mdDashaPeriods||[]).map(period=>[period.lord,period.start,period.end,period.birthElapsedDays])});
    if(signature===natalSignature)return;
    const initialized=natalSignature!==null;natalSignature=signature;
    if(initialized)empty('Birth calculations changed. Run the search to update dates.');
  }
  function validDate(text){const d=new Date(text+'T00:00:00Z');return /^\d{4}-\d{2}-\d{2}$/.test(text)&&Number.isFinite(d.getTime())&&d.toISOString().slice(0,10)===text;}
  function status(text,state='idle'){$('tr-status').textContent=text;$('tr-status').dataset.state=state;}
  function empty(text='Settings or birth calculations changed. Run the search to update dates.'){
    version++;results=[];if(running){running=false;$('tr-run').disabled=false;$('tr-cancel').hidden=true;}
    $('tr-result-rows').innerHTML='<tr><td colspan="4">'+escape(text)+'</td></tr>';status(text);
  }
  function houses(){const text=value('tr-houses').trim();if(!/^\d+(?:\s*[,; ]\s*\d+)*$/.test(text))throw new Error('Enter relevant house numbers separated by commas, for example 2, 7, 11.');const list=[...new Set(text.split(/[,;\s]+/).map(Number))];if(!list.length||list.some(n=>n<1||n>12||!Number.isInteger(n)))throw new Error('Relevant houses must be between 1 and 12.');return list.sort((a,b)=>a-b);}
  function significators(){
    const model=window.currentKPModel;if(!model?.ready)throw new Error('Complete the twelve natal cusps and all natal planet positions to select event significators.');
    return window.KPTransitSignificators.select(model,houses(),document.getElementById('tr-significator-method')?.value);
  }
  // PD boundaries reuse cumulative worksheet offsets from the MD anchor, so a
  // partly elapsed birth MD cannot shift the AD or PD boundary at birth.
  function calculatePratyantardashas(md,ad){
    if(!md||!ad||!window.calculateAntardashas||!validDate(md.start)||!validDate(ad.start)||!validDate(ad.end))return [];
    const ads=window.calculateAntardashas(md),index=ads.findIndex(p=>p.lord===ad.lord&&p.start===ad.start&&p.end===ad.end);
    if(index<0)return [];
    const elapsed=md.isBirth?(md.birthElapsedDays||0):0,base=ads.slice(0,index).reduce((sum,p)=>sum+p.durationDays,0);
    const first=ORDER.indexOf(code(ad.lord));if(first<0)return [];
    let cumulative=0;
    return ORDER.map((_,i)=>{
      const id=ORDER[(first+i)%9],durationDays=ad.durationDays*YEARS[id]/120;
      const start=mdAddOffset(md.start,base+cumulative-elapsed);cumulative+=durationDays;
      const end=i===8?ad.end:mdAddOffset(md.start,base+cumulative-elapsed);
      return {lord:window.KPDisplay.names[id],mdLord:md.lord,adLord:ad.lord,start,end,durationDays,
        birthActive:Boolean(md.isBirth&&elapsed>=base+cumulative-durationDays&&elapsed<base+cumulative)};
    });
  }
  // Home periods store exact civil-clock boundaries in the native birth zone.
  // Resolve the three active periods independently of the Home reference picker.
  function currentPeriods(instant=Date.now()){
    window.KPHomeDasha?.refresh();
    const data=window.KPHomeDasha?.getData(),offset=Number(data?.timeZoneHours)*3600000;
    const utc=instant instanceof Date?instant.getTime():Number(instant),civil=utc+offset;
    if(!data?.ready||!Number.isFinite(civil))throw new Error('Calculate the native Moon, birth date and birth time to find the current MD / AD / PD.');
    const periods={};let rows=data.levels[0].rows,lower=-Infinity,upper=Infinity;
    for(const level of ['MD','AD','PD']){
      const row=rows.find(p=>p.startMs<=civil&&civil<p.endMs);
      if(!row)throw new Error('The present moment is outside the calculated native MD / AD / PD timeline. Check the birth details.');
      lower=Math.max(lower,row.startMs);upper=Math.min(upper,row.endMs);periods[level]={...row,id:code(row.lord),startMs:lower,endMs:upper,startUTC:new Date(lower-offset).toISOString(),endUTC:new Date(upper-offset).toISOString()};
      rows=window.KPHomeDasha.subdivide(row);
    }
    return {periods,timeZoneHours:data.timeZoneHours,instant:new Date(utc).toISOString()};
  }
  function searchPeriods(){return window.KPTransitSelection?.periods()||currentPeriods();}
  function currentRange(data=searchPeriods()){
    const custom=window.KPTransitSelection?.range(data);if(custom)return custom;
    const level=value('tr-period'),period=data.periods[level];
    if(!period)throw new Error('Select the current MD, AD or PD period.');
    const birthStart=window.KPHomeDasha.getData().levels[0].rows[0].startMs-data.timeZoneHours*3600000;const start=new Date(Math.max(Date.parse(period.startUTC),birthStart)),end=new Date(period.endUTC);
    if(start.getUTCFullYear()<1900||end.getUTCFullYear()>2100)throw new Error('The full selected period must be within the supported years 1900–2100. Select a shorter period.');
    return {level,lord:period.id,start,end};
  }
  function autoDasha(data=searchPeriods()){
    const {MD:md,AD:ad,PD:pd}=data.periods;
    return {MD:md.id,AD:ad.id,PD:pd.id,md,ad,pd};
  }
  function dashaLords(data){return window.KPTransitSelection?.isActive()||value('tr-dasha-source')==='auto'?autoDasha(data):{MD:value('tr-md'),AD:value('tr-ad'),PD:value('tr-pd')};}
  function renderPeriods(data){
    const range=currentRange(data),signature=JSON.stringify([range.level,range.start,range.end,data.timeZoneHours,Object.values(data.periods).map(p=>p.id)]);
    if(periodSignature!==null&&signature!==periodSignature)empty('Current period changed. Run the search to update dates.');
    periodSignature=signature;
    $('tr-current-periods').innerHTML=Object.entries(data.periods).map(([level,p])=>'<article data-current-period="'+level+'"'+(level===range.level?' aria-current="true"':'')+'><strong>'+level+' · '+escape(p.id)+'</strong><span>'+displayTime(p.startUTC)+' → '+displayTime(p.endUTC)+'</span></article>').join('');
    $('tr-period-summary').textContent=(range.level==='Dates'?'Selected ':data.selection==='selected'?'Selected ':'Current ')+range.level+' · '+range.lord+' · '+displayTime(range.start.toISOString())+' → '+displayTime(range.end.toISOString())+' (exclusive) · '+$('tr-timezone').selectedOptions[0].textContent;
    $('tr-period-summary').dataset.start=range.start.toISOString();$('tr-period-summary').dataset.end=range.end.toISOString();
    $('tr-start').value=range.start.toISOString();$('tr-end').value=range.end.toISOString();window.KPTransitSelection?.setDefaults(range);
    if(!running)$('tr-run').disabled=false;
    return range;
  }
  function refresh(){
    invalidateChangedNatalCalculations();
    const mode=value('tr-mode');$('tr-event-panel').hidden=mode!=='event';$('tr-dasha-panel').hidden=mode==='event';$('tr-mutual-note').hidden=mode!=='dasha';$('tr-mutual-controls').hidden=mode!=='dasha';$('tr-sun-note').hidden=mode!=='sun';
    const automatic=window.KPTransitSelection?.isActive()||value('tr-dasha-source')==='auto';['tr-md','tr-ad','tr-pd'].forEach(id=>$(id).disabled=automatic);
    let current;try{current=searchPeriods();renderPeriods(current);}catch(error){
      if(periodSignature!==null)empty('Current native periods are unavailable.');periodSignature=null;
      $('tr-current-periods').replaceChildren();$('tr-period-summary').textContent=error.message;
      delete $('tr-period-summary').dataset.start;delete $('tr-period-summary').dataset.end;
      $('tr-start').value='';$('tr-end').value='';$('tr-run').disabled=true;
    }
    if(mode==='event'){
      try{const selected=significators();$('tr-event-summary').textContent='Houses '+houses().join(', ')+' → '+selected.length+' automatically selected significators. Relevant-house membership uses any selected house.';$('tr-significator-list').innerHTML=selected.map(row=>'<span>'+escape(row.id)+' · houses '+row.houses.join(', ')+'</span>').join('');}
      catch(error){$('tr-event-summary').textContent=error.message;$('tr-significator-list').replaceChildren();}
    }else{
      try{const d=dashaLords(current);if(automatic){$('tr-md').value=d.MD;$('tr-ad').value=d.AD;$('tr-pd').value=d.PD;}
        $('tr-dasha-summary').textContent='Fixed lords: MD '+d.MD+' · AD '+d.AD+' · PD '+d.PD+(automatic?' · active now in the native birth time zone.':'. Manual selection; search boundaries still follow the current native period.');
      }catch(error){$('tr-dasha-summary').textContent=error.message;if(automatic)['tr-md','tr-ad','tr-pd'].forEach(id=>$(id).selectedIndex=-1);}
    }
  }
  function natalPredicate(target,level){
    const row=window.currentKPModel?.planets?.find(p=>p.id===target);
    if(!window.currentKPModel?.ready||!row)throw new Error('Complete natal cusps and planet positions before searching natal target sectors.');
    if(level==='sign')return d=>d.signIndex===row.signIndex;
    if(level==='star')return d=>d.nakIndex===row.nakIndex;
    return d=>d.nakIndex===row.nakIndex&&d.sl===row.sl;
  }
  function targetPredicate(target,level){return value('tr-zone')==='natal'?natalPredicate(target,level):d=>d[{sign:'sgl',star:'stl',sub:'sl'}[level]]===target;}
  function makeTracks(current){
    const mode=value('tr-mode');
    if(mode==='event'){
      return KPTransitEventDetail.tracks(significators().map(p=>p.id),[...document.querySelectorAll('#tr-planet-options input:checked')].map(el=>el.value));
    }
    const d=dashaLords(current);if(!codes().every(Boolean)||![d.MD,d.AD,d.PD].every(id=>codes().includes(id)))throw new Error('Choose valid MD, AD and PD lords.');
    const targetLabel=value('tr-zone')==='natal'?'natal sector':'ruled sector';
    if(mode==='sun'){
      const mdSign=targetPredicate(d.MD,'sign'),mdStar=targetPredicate(d.MD,'star'),adSign=targetPredicate(d.AD,'sign'),adStar=targetPredicate(d.AD,'star');
      return [{id:'sun:MD-sign-AD-star',planet:'Su',label:'Sun in MD '+d.MD+' Rashi + AD '+d.AD+' Nakshatra · '+targetLabel,levels:['sign','star'],test:p=>mdSign(p)&&adStar(p)},
        {id:'sun:MD-star-AD-sign',planet:'Su',label:'Sun in MD '+d.MD+' Nakshatra + AD '+d.AD+' Rashi · '+targetLabel,levels:['sign','star'],test:p=>mdStar(p)&&adSign(p)}];
    }
    const tracks=[];
    for(const [moving,planet]of Object.entries({MD:d.MD,AD:d.AD,PD:d.PD}))for(const [target,lord]of Object.entries({MD:d.MD,AD:d.AD,PD:d.PD}))if(moving!==target&&(value('tr-direction')==='all'||value('tr-direction')===moving+'>'+target))for(const [level,label]of [['sign','Rashi'],['star','Nakshatra'],['sub','Sub']].filter(([level])=>value('tr-level')==='all'||value('tr-level')===level))
      tracks.push({id:moving+'>'+target+':'+level,planet,label:moving+' '+planet+' through '+target+' '+lord+' '+label+' · '+targetLabel,levels:[level],test:targetPredicate(lord,level)});
    return tracks;
  }
  function boundaries(levels){
    const set=new Set([0]);
    if(levels.includes('sign'))for(let i=0;i<12;i++)set.add(i*30);
    if(levels.includes('star')||levels.includes('sub'))for(let i=0;i<27;i++)set.add(i*40/3);
    if(levels.includes('sub'))for(let n=0;n<27;n++){
      let lower=n*40/3;const first=n%9;
      for(let i=0;i<9;i++){set.add(lower);lower+=(40/3)*YEARS[ORDER[(first+i)%9]]/120;}
    }
    return [...set].sort((a,b)=>a-b);
  }
  // Scan monotone longitude pieces, enumerate EVERY relevant angular boundary,
  // and root-refine each crossing. A station splits the piece before checking
  // boundaries, retaining short exits and reentries around retrograde turns.
  async function scan(options){
    const start=window.KPEphemeris.dateValue(options.start).getTime(),end=window.KPEphemeris.dateValue(options.end).getTime();
    if(!Number.isFinite(start)||!Number.isFinite(end)||end<=start||end-start>DAY*7671)throw new Error('Choose a positive search range of at most twenty-one years.');
    const tracks=options.tracks;if(!Array.isArray(tracks)||!tracks.length)throw new Error('No transit criteria were selected.');
    window.KPEphemeris.ayanamsha(new Date(start));
    const groups=new Map();for(const track of tracks){if(![...codes(),'As'].includes(track.planet)||typeof track.test!=='function')throw new Error('Invalid transit criterion.');if(!groups.has(track.planet))groups.set(track.planet,[]);groups.get(track.planet).push(track);}
    if(groups.has('As')){if(end-start>2*DAY)throw new Error('Ascendant searches are limited to 48 hours.');window.KPTransitHouses.ascendant(new Date(start),options.location?.latitude,options.location?.longitude);}
    // Saturn sign searches may use a weekly bracket: every station is still
    // detected and refined, then every sign crossing is root-refined. Other
    // searches retain their existing half-day / Moon / Ascendant brackets.
    const stepFor=id=>id==='As'?(Math.abs(Number(options.location.latitude))>60?1000:30000):id==='Mo'?DAY/8:id==='Sa'&&Number.isFinite(options.signStepDays)&&groups.get(id).every(t=>t.levels?.length===1&&t.levels[0]==='sign')?DAY*Math.max(.5,Math.min(7,options.signStepDays)):DAY/2;
    const found=[],total=[...groups].reduce((sum,[id])=>sum+Math.ceil((end-start)/stepFor(id)),0);let completed=0;
    const cancelled=()=>Boolean(options.signal?.aborted||options.shouldCancel?.());
    const check=()=>{if(cancelled())throw new Error('Search cancelled.');};
    function record(track,a,b){if(b<=a)return;found.push({trackId:track.id,planet:track.planet,label:track.label,start:new Date(a).toISOString(),end:new Date(b).toISOString(),startClipped:a===start,endClipped:b===end});if(found.length>20000)throw new Error('More than 20,000 intervals match. Select AD or PD, or choose fewer criteria.');}
    for(const [planet,group]of groups){
      check();const points=boundaries([...new Set(group.flatMap(t=>t.levels||['sign','star','sub']))]);
      const lon=t=>planet==='As'?window.KPTransitHouses.ascendant(new Date(t),options.location.latitude,options.location.longitude):window.KPEphemeris.longitude(new Date(t),planet),details=t=>window.KPDisplay.longitudeDetails(lon(t)*3600);
      const active=new Map(),first=details(start);for(const track of group)if(track.test(first))active.set(track.id,start);
      const step=stepFor(planet);
      const velocity=t=>delta(lon(Math.max(start,t-600000)),lon(Math.min(end,t+600000)));
      let left=start,leftLon=lon(start),sampleIndex=0;
      const sampleTimes=Array.isArray(options.sampleTimes)?options.sampleTimes:[];
      while(left<end){
        check();const right=Math.min(end,left+step),rightLon=lon(right),cuts=[{t:left,lon:leftLon}];
        // Optional daily output shares this scan; it does not trigger a second search.
        while(sampleIndex<sampleTimes.length&&sampleTimes[sampleIndex]<right){const at=Number(sampleTimes[sampleIndex++]);if(at<start||at>=end)continue;const sample=details(at),lo=Math.max(Date.UTC(1900,0,1),at-21600000),hi=Math.min(Date.UTC(2101,0,1)-1,at+21600000);options.onSample?.({planet,at,details:sample,retrograde:delta(lon(lo),lon(hi))<0});}
        // Moon, Sun and mean nodes are monotonic; classical planets can station.
        if(!['As','Su','Mo','Ra','Ke'].includes(planet)){
          let a=left,b=right,va=velocity(a),vb=velocity(b);
          if(va*vb<0){while(b-a>1000){const m=(a+b)/2,vm=velocity(m);if(va*vm<=0){b=m;vb=vm;}else{a=m;va=vm;}}const t=(a+b)/2;cuts.push({t,lon:lon(t)});}
        }
        cuts.push({t:right,lon:rightLon});
        for(let piece=0;piece<cuts.length-1;piece++){
          const a=cuts[piece],b=cuts[piece+1],change=delta(a.lon,b.lon),target=b.lon===a.lon?a.lon:a.lon+change;
          const min=Math.min(a.lon,target),max=Math.max(a.lon,target),crossings=[];
          for(let cycle=Math.floor(min/360)-1;cycle<=Math.floor(max/360)+1;cycle++)for(const boundary of points){
            const angle=boundary+cycle*360;if(angle<=min+1e-10||angle>max+1e-10)continue;
            let lo=a.t,hi=b.t;
            while(hi-lo>1000){const mid=(lo+hi)/2,at=a.lon+delta(a.lon,lon(mid));if(change>0?at<angle:at>angle)lo=mid;else hi=mid;}
            crossings.push((lo+hi)/2);
          }
          crossings.sort((x,y)=>x-y);
          for(let i=0;i<crossings.length;i++){
            const time=crossings[i],next=crossings[i+1]||b.t;
            // Midpoint after the crossing avoids rounding to the outgoing side,
            // including retrograde entries at a half-open KP sector boundary.
            const after=details(time+Math.min(2000,Math.max(1,(next-time)/2)));
            for(const track of group){const yes=track.test(after),was=active.has(track.id);if(yes&&!was)active.set(track.id,time);else if(!yes&&was){record(track,active.get(track.id),time);active.delete(track.id);}}
          }
        }
        left=right;leftLon=rightLon;completed++;
        if(completed%40===0){options.onProgress?.(completed/total);await new Promise(resolve=>setTimeout(resolve,0));}
      }
      for(const track of group)if(active.has(track.id))record(track,active.get(track.id),end);
    }
    check();options.onProgress?.(1);return found.sort((a,b)=>a.start.localeCompare(b.start)||a.trackId.localeCompare(b.trackId));
  }
  function displayTime(text){const d=new Date(new Date(text).getTime()+Number(value('tr-timezone'))*60000);const iso=d.toISOString();return window.KPPreferences?.isConfigured()?window.KPPreferences.formatDate(iso.slice(0,10))+' '+window.KPPreferences.formatTime(iso.slice(11,19)):iso.slice(0,10)+' '+iso.slice(11,19);}
  function renderResults(){
    if(!results.length)return;
    $('tr-result-rows').innerHTML=results.map(row=>'<tr data-track="'+escape(row.trackId)+'" data-entry="'+row.start+'" data-exit="'+row.end+'"><th scope="row">'+escape(row.planet)+'</th><td>'+escape(row.label)+'</td><td>'+displayTime(row.start)+(row.startClipped?'<small>range limit</small>':'')+'</td><td>'+displayTime(row.end)+(row.endClipped?'<small>range limit</small>':'')+'</td></tr>').join('');
  }
  async function run(){
    empty('Preparing transit search…');let current=version;
    try{
      const data=searchPeriods(),{start,end,level,lord}=renderPeriods(data),tracks=makeTracks(data);current=version;
      const personal=window.KPSimpleTransits?.criteria(data);running=true;$('tr-run').disabled=true;$('tr-cancel').hidden=false;status('Searching offline… 0%','running');
      let found=await scan({start,end,tracks,shouldCancel:()=>current!==version,onProgress:p=>{if(current===version)status('Searching offline… '+Math.round(p*100)+'%','running');}});
      if(current!==version)return;if(personal)found=KPEventOutcome.intersect(found,personal.periods).map(row=>({...row,label:personal.event+' · '+row.label}));results=found;
      if(found.length)renderResults();else $('tr-result-rows').innerHTML='<tr><td colspan="4">No matching intervals in this date range.</td></tr>';
      status((level==='Dates'?'Selected ':data.selection==='selected'?'Selected ':'Current ')+level+' · '+lord+' · '+found.length+' matching transit interval'+(found.length===1?'':'s')+' · '+$('tr-timezone').selectedOptions[0].textContent+' · end times are exclusive.');
    }catch(error){if(current===version){results=[];$('tr-result-rows').innerHTML='<tr><td colspan="4">'+escape(error.message)+'</td></tr>';status(error.message,'error');}}
    finally{if(current===version){running=false;$('tr-run').disabled=false;$('tr-cancel').hidden=true;}}
  }
  function initialize(){
    for(const id of ['tr-md','tr-ad','tr-pd']){$(id).replaceChildren(...codes().map(code=>{const el=document.createElement('option');el.value=code;el.textContent=code+' · '+window.KPDisplay.names[code];return el;}));}
    $('tr-planet-options').innerHTML=codes().map(id=>'<label for="tr-planet-'+id+'"><input id="tr-planet-'+id+'" type="checkbox" value="'+id+'" '+(['Su','Ju','Sa'].includes(id)?'checked':'')+'>'+id+'</label>').join('');
    $('tr-run').addEventListener('click',run);$('tr-cancel').addEventListener('click',()=>empty('Search cancelled.'));
    $('transit').addEventListener('change',event=>{if(event.target.id==='tr-event'&&EVENTS[value('tr-event')])$('tr-houses').value=EVENTS[value('tr-event')].join(', ');empty();refresh();});
    $('transit').addEventListener('input',event=>{if(event.target.tagName==='INPUT'){empty();refresh();}});
    function natalChanged(){empty();clearTimeout(refreshTimer);refreshTimer=setTimeout(refresh,80);}
    document.addEventListener('input',event=>{if(event.target.closest('main')&&!event.target.closest('#transit,#transit-chart,#aspects,#astrosettings'))natalChanged();});
    document.addEventListener('change',event=>{if(event.target.closest('main')&&!event.target.closest('#transit,#transit-chart,#aspects,#astrosettings'))natalChanged();});
    const observer=new MutationObserver(()=>{invalidateChangedNatalCalculations();clearTimeout(refreshTimer);refreshTimer=setTimeout(refresh,80);});for(const id of ['kp-basic-planet','kp-basic-house','mdDashaRows'])if($(id))observer.observe($(id),{childList:true,subtree:true,characterData:true});
    document.querySelector('nav [data-tab="transit"]')?.addEventListener('click',()=>setTimeout(refresh,0));
    setInterval(()=>{if($('transit').classList.contains('active')&&!running)refresh();},30000);
    setTimeout(refresh,0);refresh();
  }
  window.KPTransit=Object.freeze({currentPeriods,selectedPeriods:searchPeriods,currentRange,scan,makeTracks,significators,calculatePratyantardashas,autoDasha,refresh,renderResults,run,getResults:()=>results.map(row=>({...row})),cancel:()=>empty('Search cancelled.')});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();


