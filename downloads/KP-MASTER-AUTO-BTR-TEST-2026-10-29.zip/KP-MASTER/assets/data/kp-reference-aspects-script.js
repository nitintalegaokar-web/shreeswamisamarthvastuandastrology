
(function () {
  'use strict';
  function prepareReferenceAspectTable() {
    const fieldset=document.querySelector('#aspects .western-angle-options');
    if (!fieldset || fieldset.dataset.referenceTable==='true') return;
    fieldset.dataset.referenceTable='true';
    const card=fieldset.closest('.western-aspect-card');
    const resultColumn=document.createElement('div');resultColumn.className='reference-aspect-results-column';
    [card.querySelector('.western-aspect-status'),card.querySelector('.western-results'),card.querySelector('.western-footnote')].filter(Boolean).forEach(node=>resultColumn.append(node));
    card.append(resultColumn);
    const header=document.createElement('div');
    header.className='reference-aspect-header no-print';
    header.setAttribute('aria-hidden','true');
    ['Angle','Name','Code','Orb','Color'].forEach(text=>{const cell=document.createElement('span');cell.textContent=text;header.append(cell);});
    fieldset.insertBefore(header,fieldset.querySelector('.western-angle-option'));
    const rows=[...fieldset.querySelectorAll('.western-angle-option')];
    rows.forEach((row,index)=>{
      const label=row.querySelector('.western-aspect-choice');
      const input=label?.querySelector('input[type="checkbox"]');
      const sourceName=label?.querySelector('.western-marathi-name');
      if (!label || !input || !sourceName) return;
      const originalText=label.textContent.trim();
      const englishText=[...label.childNodes].filter(node=>node.nodeType===Node.ELEMENT_NODE&&node.tagName==='SPAN')[0]?.firstChild?.textContent.trim() || '';
      const angle=input.id.replace('western-angle-','');
      const englishName=englishText.split(' · ')[0];
      const pieces=sourceName.textContent.split(' · ');
      const name=pieces[0].trim(), code=pieces.slice(1).join(' · ').trim();
      const angleCell=document.createElement('span');angleCell.className='reference-aspect-angle';angleCell.append(input,document.createTextNode(angle+'° '));
      const nameCell=document.createElement('span');nameCell.className='reference-aspect-name';nameCell.append(document.createTextNode(name+' '));
      const english=document.createElement('span');english.className='reference-aspect-english';english.textContent='('+englishName+') ';nameCell.append(english);
      const codeCell=document.createElement('span');codeCell.className='reference-aspect-code';codeCell.textContent=code;
      label.replaceChildren(angleCell,nameCell,codeCell);
      label.setAttribute('aria-label',originalText);
      label.title=englishText+' · '+name+' · '+code;
      if(index===0) row.classList.add('reference-selected');
      const selectRow=()=>{rows.forEach(item=>item.classList.toggle('reference-selected',item===row));};
      row.addEventListener('click',selectRow);row.addEventListener('focusin',selectRow);
    });
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',prepareReferenceAspectTable,{once:true});
  else prepareReferenceAspectTable();
})();

