
(() => {
  const selections = {'tp-print':'transit-panchang', 'eph-print':'ephemeris'};
  document.addEventListener('click', event => {
    const button = event.target.closest('button[id]');
    const section = button && selections[button.id];
    if (!section || button.disabled) return;
    window.renderReport?.();
    document.querySelector('.app-sidebar [data-tab="report"]')?.click();
    window.KPReportPages?.selectSections([section]);
    document.getElementById('report-page-options')?.focus();
  });
  function initialize() { setTimeout(() => { window.renderReport?.(); window.KPReportPages?.refresh(); }, 0); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize); else initialize();
})();

