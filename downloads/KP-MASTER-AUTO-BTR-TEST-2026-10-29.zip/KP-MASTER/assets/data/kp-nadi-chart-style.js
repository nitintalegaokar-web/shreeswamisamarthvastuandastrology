
(()=>{'use strict';const NS='http://www.w3.org/2000/svg';
function node(tag,attrs={},text){const n=document.createElementNS(NS,tag);Object.entries(attrs).forEach(([k,v])=>n.setAttribute(k,String(v)));if(text!==undefined)n.textContent=text;return n;}
const centers=[[240,120],[120,40],[40,120],[120,240],[40,360],[120,440],[240,360],[360,440],[440,360],[360,240],[440,120],[360,40]],roman=['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];
const polys=[[[240,0],[360,120],[240,240],[120,120]],[[0,0],[240,0],[120,120]],[[0,0],[120,120],[0,240]],[[0,240],[120,120],[240,240],[120,360]],[[0,240],[120,360],[0,480]],[[0,480],[120,360],[240,480]],[[240,240],[360,360],[240,480],[120,360]],[[240,480],[360,360],[480,480]],[[360,360],[480,240],[480,480]],[[240,240],[360,120],[480,240],[360,360]],[[480,0],[480,240],[360,120]],[[240,0],[480,0],[360,120]]];
function bounds(poly,y){const a=[];poly.forEach((p,i)=>{const q=poly[(i+1)%poly.length];if(p[1]!==q[1]&&y>=Math.min(p[1],q[1])&&y<=Math.max(p[1],q[1]))a.push(p[0]+(y-p[1])*(q[0]-p[0])/(q[1]-p[1]));});return [Math.min(...a),Math.max(...a)];}
function renderNorth(data,target){
 if(window.KPPairedNorth&&data?.model?.ready){window.KPPairedNorth.render(target,data.model,1);target.dataset.chartStyle='north';target.dataset.nadiNorthLayout='cusp-lagna';return;}
 const houses=data.model.houses,planets=data.model.planets,asc=Math.floor(houses[0].longitude/108000),sectors=Array.from({length:12},()=>[]);
 houses.forEach((p,i)=>sectors[(Math.floor(p.longitude/108000)-asc+12)%12].push({p,label:roman[i],cusp:i+1}));planets.forEach(p=>sectors[(Math.floor(p.longitude/108000)-asc+12)%12].push({p,label:p.id+(p.retrograde?'[R]':''),planet:p.id}));
 const svg=node('svg',{class:'na-north-chart',viewBox:'0 0 480 480',role:'img','aria-label':'North Indian kundali'});svg.append(node('title',{},'North Indian kundali'),node('rect',{x:1,y:1,width:478,height:478,fill:'#fff',stroke:'#64748b','stroke-width':2}),node('path',{d:'M0 0L480 480M480 0L0 480M240 0L480 240L240 480L0 240Z',fill:'none',stroke:'#94a3b8','stroke-width':1.4}));
 sectors.forEach((items,i)=>{const [x,y]=centers[i],g=node('g',{'data-sign-index':(asc+i)%12});g.append(node('text',{x,y:y-24,'text-anchor':'middle',fill:'#a2403c','font-size':13},String((asc+i)%12+1)));const spacing=Math.min(14,48/Math.max(1,items.length)),maxLength=Math.max(1,...items.map(({p,label})=>(label+' '+KPDisplay.longitudeDetails(p.longitude).degree).length)),font=Math.min(11,spacing*.78,(i%3===0?140:70)/(maxLength*.63));
 items.forEach(({p,label,cusp,planet},row)=>{const lineY=y+6+(row-(items.length-1)/2)*spacing,b=bounds(polys[i],lineY),size=Math.max(1,Math.min(font,(b[1]-b[0]-8)/(maxLength*.66)));const attrs={x:(b[0]+b[1])/2,y:lineY,'text-anchor':'middle','font-size':size,fill:cusp?'#3168ad':'#6b3fa0','data-longitude':p.longitude};if(cusp)attrs['data-nadi-cusp']=cusp;else {attrs['data-nadi-chart-planet']=planet;attrs['data-planet']=planet;}g.append(node('text',attrs,label+' '+KPDisplay.longitudeDetails(p.longitude).degree));});svg.append(g);});
 target.replaceChildren(svg);target.dataset.chartStyle='north';
}
window.KPNadiChartStyle=Object.freeze({renderNorth});
function initialize(){const chart=document.getElementById('na-native-chart');if(chart){chart.tabIndex=0;chart.setAttribute('aria-label','Native kundali');}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

