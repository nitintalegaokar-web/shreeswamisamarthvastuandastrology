

document.addEventListener("DOMContentLoaded",()=>{
  ["stdLon","placeStdLon","birthTime","lmtBirthClock"].forEach(id=>{
    const el=document.getElementById(id);
    if(el) el.addEventListener("input",()=>{ updateLongitudeDifference(); updateLMTCalculation(); });
  });
  updateLMTCalculation();
});


