

document.addEventListener("DOMContentLoaded",()=>{
  const syncPlanet6Dates=()=>{
    const dob=document.getElementById("dob")?.value || "";
    const bt=document.getElementById("birthTime")?.value || "05:30:00";
    const d1=document.getElementById("p6_date_1");
    const d2=document.getElementById("p6_date_2");
    if(!dob || !d1 || !d2) return;
    const parts=dob.split("-").map(Number);
    if(parts.length!==3 || parts.some(Number.isNaN)) return;
    const base=new Date(parts[0],parts[1]-1,parts[2]);
    const [hh,mm,ss]=(bt+":00").split(":").slice(0,3).map(Number);
    const birthSeconds=(hh||0)*3600+(mm||0)*60+(ss||0);
    const target=new Date(base);
    if(birthSeconds < 5.5*3600) target.setDate(target.getDate()-1);
    else target.setDate(target.getDate()+1);
    const iso=d=>{
      const y=d.getFullYear(), m=String(d.getMonth()+1).padStart(2,"0"), day=String(d.getDate()).padStart(2,"0");
      return `${y}-${m}-${day}`;
    };
    d1.value=dob;
    d2.value=iso(target);
    const t1=document.getElementById("p6_time_1"), t2=document.getElementById("p6_time_2");
    const a1=document.getElementById("p6_ampm_1"), a2=document.getElementById("p6_ampm_2");
    if(t1) t1.value="05:30:00"; if(t2) t2.value="05:30:00";
    if(a1) a1.value="AM"; if(a2) a2.value="AM";
  };
  ["dob","birthTime"].forEach(id=>{
    const e=document.getElementById(id);
    if(e){
      e.addEventListener("input",()=>{ syncPlanet6Dates(); if(typeof calculateAll==="function") calculateAll(); updateMDCalculation(); });
      e.addEventListener("change",()=>{ syncPlanet6Dates(); if(typeof calculateAll==="function") calculateAll(); updateMDCalculation(); });
    }
  });
  syncPlanet6Dates();
  updateMDCalculation();
});


document.addEventListener("input", function(e){
  if(e.target && ["stLargeTime","stSmallTime","birthPlaceSiderealTime"].includes(e.target.id)){
    updateSampattikTimeDifferences();
  }
});
document.addEventListener("change", function(e){
  if(e.target && ["stLargeTime","stSmallTime","birthPlaceSiderealTime"].includes(e.target.id)){
    updateSampattikTimeDifferences();
  }
});

document.addEventListener("input", function(e){
  if(e.target && (e.target.id==="stLargeTime" || e.target.id==="stSmallTime")){
    updateSampattikTimeDifferences();
  }
});
document.addEventListener("change", function(e){
  if(e.target && (e.target.id==="stLargeTime" || e.target.id==="stSmallTime")){
    updateSampattikTimeDifferences();
  }
});

// TAB 5 ONLY — फरक क्र. ३ and repeated छोटी सांपत्तिक वेळ.
// Tabs 1–4 calculation functions are intentionally untouched.
function updateRaphael5BasicRows(){
    if(window.KPBhavSadhan?.enabled())return;
  const houses = [10,11,12,1,2,3];

  houses.forEach(h => {
    const largeEl = document.getElementById(`r5_large_${h}`);
    const smallEl = document.getElementById(`r5_small_${h}`);
    const diffEl = document.getElementById(`r5_diff3_${h}`);
    const smallAgainEl = document.getElementById(`r5_small2_${h}`);

    if(!largeEl || !smallEl) return;

    const large = (largeEl.value || "").trim();
    const small = (smallEl.value || "").trim();

    // चौथ्या row मध्ये छोटी सां. वेळ पुन्हा automatic copy.
    if(smallAgainEl) smallAgainEl.value = small;

    // फरक क्र. ३ = मोठी सांपत्तिक वेळ − छोटी सांपत्तिक वेळ
    if(large && small){
      let diff = hmsToSeconds(large) - hmsToSeconds(small);
      if(diff < 0) diff += 86400;
      if(diffEl) diffEl.value = secondsToHMS(diff);
    }else{
      if(diffEl) diffEl.value = "";
    }
  });
}

document.addEventListener("input", function(e){
  if(e.target && /^r5_(large|small)_(10|11|12|1|2|3)$/.test(e.target.id)){
    updateRaphael5BasicRows();
  }
});
document.addEventListener("change", function(e){
  if(e.target && /^r5_(large|small)_(10|11|12|1|2|3)$/.test(e.target.id)){
    updateRaphael5BasicRows();
  }
});

document.addEventListener("DOMContentLoaded", function(){
  updateRaphael5BasicRows();
});

// TAB 5 — tabular Ishta Bhava calculation.
// Source: Tab 4 (Sampattik Kaal) for Farak 1 & Farak 2,
// and current Raphael table for Farak 3.
function updateRaphael5FormulaTable(){
    if(window.KPBhavSadhan?.enabled())return;
  const houses=[1,2,3,10,11,12];

  const d1=(document.getElementById("stDiffSeconds")?.value||"").trim();
  const d2=(document.getElementById("stDiff2Seconds")?.value||"").trim();
  const diff1Text=(document.getElementById("stDiff1")?.value||"").trim();
  const diff2Text=(document.getElementById("stDiff2")?.value||"").trim();

  houses.forEach(h=>{
    const out1=document.getElementById(`r5_calc_diff1_${h}`);
    const out2=document.getElementById(`r5_calc_diff2_${h}`);
    const out3=document.getElementById(`r5_calc_diff3_${h}`);
    const result=document.getElementById(`r5_calc_ishta_${h}`);

    if(!out1 || !out2 || !out3 || !result) return;

    out1.value=diff1Text || "";
    out2.value=diff2Text || "";

    const diff3Text=(document.getElementById(`r5_diff3_${h}`)?.value||"").trim();
    out3.value=diff3Text;

    const sec1=Number(d1);
    const sec2=Number(d2);
    const sec3=parseTimeToSeconds(diff3Text||"00:00:00");

    if(Number.isFinite(sec1) && sec1!==0 && Number.isFinite(sec2) && diff3Text){
      // Formula exactly as requested:
      // (Farak No.2 × Farak No.3) ÷ Farak No.1
      // Convert resulting seconds to whole minutes for "इष्टभाव फरक".
      const ishtaMinutes=KPIshtaFarak.roundArcseconds(sec2*sec3/sec1);
      result.value=String(ishtaMinutes);
    }else{
      result.value="";
    }
  });
}

// Keep the existing Tab-5 Farak-3 / repeated-small-time behavior,
// then refresh the new calculation table.
const _oldUpdateRaphaelTable5 = updateRaphaelTable5;
updateRaphaelTable5 = function(){
  _oldUpdateRaphaelTable5();
  updateRaphael5FormulaTable();
};

document.addEventListener("input", function(e){
  if(e.target && (
    e.target.id==="stLargeTime" ||
    e.target.id==="stSmallTime" ||
    e.target.id==="r5_large_10" || e.target.id==="r5_large_11" ||
    e.target.id==="r5_large_12" || e.target.id==="r5_large_1" ||
    e.target.id==="r5_large_2" || e.target.id==="r5_large_3" ||
    e.target.id==="r5_small_10" || e.target.id==="r5_small_11" ||
    e.target.id==="r5_small_12" || e.target.id==="r5_small_1" ||
    e.target.id==="r5_small_2" || e.target.id==="r5_small_3"
  )){
    setTimeout(updateRaphael5FormulaTable,0);
  }
});
document.addEventListener("change", function(e){
  if(e.target && (e.target.id==="stLargeTime" || e.target.id==="stSmallTime")){
    setTimeout(updateRaphael5FormulaTable,0);
  }
});
document.addEventListener("DOMContentLoaded", function(){
  setTimeout(updateRaphael5FormulaTable,50);
});


// TAB 5 EXTENSION — automatic Ishta Bhava, KP Ayanamsha and Nirayan Bhava.
// Tabs 1–4 calculation logic is not modified.
(function(){
  const H=[10,11,12,1,2,3];
  const RASHI=["मेष","वृषभ","मिथुन","कर्क","सिंह","कन्या","तुळ","वृश्चिक","धनु","मकर","कुंभ","मीन"];

  function sec(v){
    if(!v) return NaN;
    const p=String(v).trim().split(':').map(Number);
    if(p.length<2 || p.some(x=>!Number.isFinite(x))) return NaN;
    return (p[0]||0)*3600+(p[1]||0)*60+(p[2]||0);
  }
  function hms(s){
    if(!Number.isFinite(s)) return '';
    s=Math.round(s);
    s=((s%86400)+86400)%86400;
    const hh=Math.floor(s/3600), mm=Math.floor((s%3600)/60), ss=s%60;
    return String(hh).padStart(2,'0')+':'+String(mm).padStart(2,'0')+':'+String(ss).padStart(2,'0');
  }
  // For the Raphael row 'छो. सां. वेळ + इष्टभाव फरक', keep the
  // arithmetic result as-is (do NOT wrap at 24 hours). Example: 54:00:00 +
  // 00:39:00 = 54:39:00.
  function hmsUnwrapped(s){
    if(!Number.isFinite(s)) return '';
    s=Math.round(s);
    if(s<0) return '';
    const hh=Math.floor(s/3600), mm=Math.floor((s%3600)/60), ss=s%60;
    return String(hh).padStart(2,'0')+':'+String(mm).padStart(2,'0')+':'+String(ss).padStart(2,'0');
  }
  function dms(s){
    if(!Number.isFinite(s)) return '';
    s=Math.round(s);
    s=((s%1296000)+1296000)%1296000;
    const d=Math.floor(s/3600), m=Math.floor((s%3600)/60), x=s%60;
    return `${String(d).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(x).padStart(2,'0')}`;
  }
  function set(id,v){ const e=document.getElementById(id); if(e) e.value=(v==null?'':v); }
  function get(id){ return (document.getElementById(id)?.value||'').trim(); }

  function updateTab5FullAuto(){
    if(window.KPBhavSadhan?.enabled())return;
    const diff1Text=get('stDiff1');
    const diff2Text=get('stDiff2');
    const diff1=sec(diff1Text);
    const invalidAutomaticST=document.getElementById('st-ephemeris-source')?.value==='automatic' && !get('birthPlaceSiderealTime');
    const diff2=invalidAutomaticST?NaN:sec(diff2Text);
    const ayan=sec(get('ayanValue'));

    H.forEach(function(h){
      const d3Text=get(`r5_diff3_${h}`);
      const d3=sec(d3Text);
      const small=get(`r5_small_${h}`);

      // 1) Automatic Farak 1, 2, 3 in the calculation table.
      set(`r5_calc_diff1_${h}`, diff1Text);
      set(`r5_calc_diff2_${h}`, diff2Text);
      set(`r5_calc_diff3_${h}`, d3Text);

      // 2) Ishta Bhava = (Farak 2 × Farak 3) ÷ Farak 1; advance at 50 arcseconds.
      let ishtaMin='';
      if(Number.isFinite(diff1) && diff1!==0 && Number.isFinite(diff2) && Number.isFinite(d3)){
        ishtaMin=KPIshtaFarak.roundArcseconds(diff2*d3/diff1);
      }
      set(`r5_calc_ishta_${h}`, ishtaMin);
      set(`r5_ishta_${h}`, ishtaMin===''?'':hms(Number(ishtaMin)*60));

      // 3) छोटी सां. वेळ + इष्टभाव फरक.
      const smallSec=sec(small);
      let plus=NaN;
      if(Number.isFinite(smallSec) && ishtaMin!=='') plus=smallSec+Number(ishtaMin)*60;
      set(`r5_smallplus_${h}`, Number.isFinite(plus)?hmsUnwrapped(plus):'');

      // 4) KP Ayanamsha from Tab 1 — same value in every cell.
      set(`r5_geoayan_${h}`, get('ayanValue'));

      // 5) एकूण निरयन = 'छो. सां. वेळ + इष्टभाव फरक' मधून KP अयनांश वजा करणे.
      //    येथे दोन्ही values DMS स्वरूपात थेट वजा केल्या जातात.
      //    उदाहरण: 54:39:00 - 23:45:39 = 30:53:21.
      let nir=NaN;
      if(Number.isFinite(plus) && Number.isFinite(ayan)){
        nir=plus-ayan;
        // Keep the result positive in DMS range without converting time to degrees.
        nir=((nir%1296000)+1296000)%1296000;
      }
      set(`r5_nirayan_${h}`, Number.isFinite(nir)?dms(nir):'');

      // 6) Subtract the completed 30° Rashi blocks: 0°, 30°, 60° ...
      if(Number.isFinite(nir)){
        const rashiIndex=Math.floor(nir/108000); // 30° = 108000 arc-seconds
        const base=rashiIndex*108000;
        const remaining=nir-base;
        set(`r5_minus_${h}`, dms(base));
        set(`r5_bhava_${h}`, dms(remaining));
        set(`r5_rashi_${h}`, RASHI[rashiIndex%12]);
        set(`r5_opposite_${h}`, RASHI[(rashiIndex+6)%12]);
      }else{
        set(`r5_minus_${h}`,''); set(`r5_bhava_${h}`,'');
        set(`r5_rashi_${h}`,''); set(`r5_opposite_${h}`,'');
      }
    });
  }

  // Run after the existing Tab-5 calculation so Farak 3 and small time are current.
  const old=window.updateRaphaelTable5;
  window.updateRaphaelTable5=function(){
    if(typeof old==='function') old();
    updateTab5FullAuto();
  };

  document.addEventListener('input',function(e){
    if(e.target && (
      e.target.id==='stDiff1' || e.target.id==='stDiff2' || e.target.id==='ayanValue' ||
      /^r5_(large|small)_/.test(e.target.id)
    )) setTimeout(updateTab5FullAuto,0);
  });
  document.addEventListener('change',function(e){
    if(e.target && (
      e.target.id==='stDiff1' || e.target.id==='stDiff2' || e.target.id==='ayanValue' ||
      /^r5_(large|small)_/.test(e.target.id)
    )) setTimeout(updateTab5FullAuto,0);
  });
  document.addEventListener('DOMContentLoaded',function(){ setTimeout(updateTab5FullAuto,80); });
})();


// Tab 5: direct result only in the "छो. सां. वेळ + इष्टभाव फरक" row.
// The calculation remains unchanged; only the display is simplified to the final value.


