
(function(){
  const P=["रवी","चंद्र","मंगळ","बुध","गुरु","शुक्र","शनि","राहू","केतू"];
  const SIGNS=["मेष","वृषभ","मिथुन","कर्क","सिंह","कन्या","तुळ","वृश्चिक","धनु","मकर","कुंभ","मीन"];
  const ROM=["I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII"];
  const norm=x=>((Number(x)||0)%1296000+1296000)%1296000;
  const signIndex=x=>Math.min(11,Math.floor(norm(x)/108000));
  const localSec=x=>norm(x)%108000;
  function dms(sec){sec=Math.round(localSec(sec));const d=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;return d+'°'+String(m).padStart(2,'0')+'′'+String(s).padStart(2,'0')+'″';}
  function parseAny(v){
    if(typeof window.parseDmsAny==='function') return window.parseDmsAny(v);
    const a=String(v||'').replace(/[^0-9:.-]/g,'').split(':').map(Number);return (a[0]||0)*3600+(a[1]||0)*60+(a[2]||0);
  }
  // Fixed South Indian placement: Pisces at top-left, then Aries...Aquarius clockwise.
  const POS={11:[1,1],0:[1,2],1:[1,3],2:[1,4],3:[2,4],4:[3,4],5:[4,4],6:[4,3],7:[4,2],8:[4,1],9:[3,1],10:[2,1]};
  function yPercent(si,lon){
    const deg=localSec(lon)/3600; // 0..30
    // User rule: Aries through Virgo = degree top -> bottom.
    // Libra through Pisces = degree bottom -> top.
    const pct=(si>=0 && si<=5) ? (deg/30)*100 : (100-(deg/30)*100);
    return Math.max(3,Math.min(92,pct));
  }
  function getPlanets(){
    const lp=window.lastPlanetPositions||{}, out=[];
    P.forEach((p,i)=>{
      let n=lp[p]!=null&&lp[p]!==''?Number(lp[p]):NaN;
      if(!Number.isFinite(n)){
        const e=document.getElementById('p6_final_'+i);
        const si=SIGNS.indexOf(String(document.getElementById('p6_rashi_'+i)?.value||'').trim().replace(/^तुला$/,'तुळ'));
        if(e&&e.value.trim()&&si>=0){
          const degree=parseAny(e.value.replace(/\s*R\s*$/i,''));
          if(Number.isFinite(degree)&&degree>=0&&degree<108000)n=si*108000+degree;
        }
      }
      if(Number.isFinite(n)){
        const retro=(document.getElementById('p6_motion_'+i)?.value||'').includes('R');
        out.push({id:window.KPDisplay?.idByName[p]||'',name:p,lon:n,retro});
      }
    });
    const fortuna=window.KPFortuna?.getNatal();
    if(fortuna)out.push({id:'Fo',name:'Fo',lon:fortuna.longitude,retro:false});
    return out;
  }
  function renderLane(si,entries,kind,minSlots=5){
    entries.sort((a,b)=>yPercent(si,a.lon)-yPercent(si,b.lon));
    // Pack each column independently. Every label receives a complete slot,
    // including clusters at 0°/30°, so the last labels cannot spill out.
    const slot=100/Math.max(minSlots,entries.length);
    const tops=entries.map(it=>Math.max(0,Math.min(100-slot,yPercent(si,it.lon))));
    for(let i=1;i<tops.length;i++)tops[i]=Math.max(tops[i],tops[i-1]+slot);
    if(tops.length&&tops[tops.length-1]>100-slot){
      tops[tops.length-1]=100-slot;
      for(let i=tops.length-2;i>=0;i--)tops[i]=Math.min(tops[i],tops[i+1]-slot);
    }
    const laneScale=Math.min(1,6/Math.max(1,entries.length));
    let html='<div class="v38-lane v38-'+kind+'-lane'+(entries.length>5?' is-dense':'')+'" style="--v38-lane-scale:'+laneScale+'">';
    entries.forEach((it,i)=>{
      const details=window.KPDisplay?.longitudeDetails(it.lon);
      const lords=details?'<span class="v38-lords" data-sgl="'+details.sgl+'" data-stl="'+details.stl+'" data-sbl="'+details.sl+'">('+details.sgl+'-'+details.stl+'-'+details.sl+')</span>':'';
      const id=kind==='cusp'?ROM.indexOf(it.name)+1:(it.id||window.KPDisplay?.idByName[it.name]);
      html+='<div class="v38-item v38-'+kind+'" data-kind="'+kind+'" data-'+(kind==='cusp'?'cusp':'planet')+'="'+id+'" data-longitude="'+it.lon+'" data-original-name="'+it.name+'" data-original-degree="'+it.degree+'" style="top:'+Math.max(0,tops[i])+'%;height:'+slot+'%"><span class="v38-position"><span class="v38-name">'+it.name+'</span><span class="v38-degree">'+it.degree+'</span></span>'+lords+'</div>';
    });
    return html+'</div>';
  }
  // Render an independent model with the same lanes and lord labels as Home.
  // Nadi selected moments must never borrow the native chart's positions.
  function modelChart(data){
    const chart=document.createElement('div');chart.className='v38-chart kp-nadi-home-chart';chart.dataset.homeChart='true';chart.dataset.nadiSource=data.source;chart.dataset.chartStyle='south';
    const items=Array.from({length:12},()=>[]);
    data.model.houses.forEach((h,i)=>items[signIndex(h.longitude)].push({kind:'cusp',name:ROM[i],degree:dms(h.longitude),lon:h.longitude}));
    data.model.planets.forEach(p=>items[signIndex(p.longitude)].push({kind:'planet',id:p.id,name:KPDisplay.names[p.id]||p.id,degree:dms(p.longitude)+(p.retrograde&&!['Ra','Ke'].includes(p.id)?' R':''),lon:p.longitude}));
    for(let si=0;si<12;si++){const cell=document.createElement('div');cell.className='v38-cell';cell.dataset.signIndex=String(si);cell.style.gridRow=String(POS[si][0]);cell.style.gridColumn=String(POS[si][1]);cell.innerHTML=renderLane(si,items[si].filter(i=>i.kind==='cusp'),'cusp',2.5)+renderLane(si,items[si].filter(i=>i.kind==='planet'),'planet',2.5);chart.append(cell);}
    chart.querySelectorAll('.v38-lane').forEach(n=>n.style.setProperty('--v38-lane-scale',String(Math.min(1,3/Math.max(1,n.children.length)))));
    chart.querySelectorAll('[data-cusp]').forEach(n=>n.dataset.nadiCusp=n.dataset.cusp);chart.querySelectorAll('[data-planet]').forEach(n=>n.dataset.nadiChartPlanet=n.dataset.planet);
    const center=document.createElement('div');center.className='v38-center';const content=document.createElement('div');content.style.width='100%';const title=document.createElement('div');title.className='v38-title';title.textContent='कृष्णमूर्ती पद्धतीची लग्न व भावचलित कुंडली';const info=document.createElement('div');info.className='v38-data';
    const val=id=>document.getElementById(id)?.value||'',moment=data.moment||{},native=data.source!=='moment',fmtDate=x=>window.KPPreferences?.isConfigured()?KPPreferences.formatDate(x):x,fmtTime=x=>window.KPPreferences?.isConfigured()?KPPreferences.formatTime(x):x;
    const coordinate=x=>{const sign=Number(x)<0?'-':'';let sec=Math.round(Math.abs(Number(x)||0)*3600);return sign+Math.floor(sec/3600)+':'+String(Math.floor(sec%3600/60)).padStart(2,'0')+':'+String(sec%60).padStart(2,'0');};
    const rows=[['नाव:',val('name')],[native?'जन्मतारीख:':'दिनांक:',fmtDate(moment.date||val('dob'))],[native?'जन्मवेळ:':'वेळ:',fmtTime(moment.time||val('birthTime'))],['अक्षांश:',native?val('lat'):coordinate(moment.latitude)],['रेखांश:',native?val('lon'):coordinate(moment.longitude)],['लग्न अंश:',dms(data.model.houses[0].longitude)]];
    if(!native&&moment.place)rows.splice(3,0,['स्थळ:',moment.place]);
    rows.forEach(([label,value],i)=>{if(i)info.append(document.createElement('br'));const b=document.createElement('b');b.textContent=label;info.append(b,document.createTextNode(' '+value));});content.append(title,info);center.append(content);chart.append(center);window.KPPreferences?.decorate(chart);return chart;
  }
  window.KPSouthChart=Object.freeze({fromModel:modelChart});
  window.renderChart=function(force=false){
    if(window.kundaliManual)return;
    const chart=document.getElementById('kundali');if(!chart)return;
    chart.className='south9-chart v38-chart';
    const items=Array.from({length:12},()=>[]);
    const cr=Array.isArray(window.cuspResults)?window.cuspResults:[];
    cr.forEach((c,i)=>{const n=c&&c.nir!=null&&c.nir!==""?Number(c.nir):NaN;if(Number.isFinite(n)){const si=signIndex(n);items[si].push({kind:'cusp',name:ROM[(Number(c.i)||i+1)-1],degree:dms(n),lon:n});}});
    getPlanets().forEach(p=>{const si=signIndex(p.lon);items[si].push({kind:'planet',id:p.id,name:p.name,degree:dms(p.lon)+(p.retro?' R':''),lon:p.lon});});
    let html='';
    for(let si=0;si<12;si++){
      const rc=POS[si];
      html+='<div class="v38-cell" data-sign-index="'+si+'" style="grid-row:'+rc[0]+';grid-column:'+rc[1]+'">';
      html+=renderLane(si,items[si].filter(it=>it.kind==='cusp'),'cusp');
      html+=renderLane(si,items[si].filter(it=>it.kind==='planet'),'planet');
      html+='</div>';
    }
    const val=id=>{
      let value=String(document.getElementById(id)?.value||'');
      if(window.KPPreferences?.isConfigured()&&id==='dob')value=window.KPPreferences.formatDate(value);
      if(window.KPPreferences?.isConfigured()&&id==='birthTime')value=window.KPPreferences.formatTime(value);
      return value.replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
    };
    const lag=cr.find(x=>Number(x.i)===1);const lagText=lag&&lag.nir!=null&&lag.nir!==""&&Number.isFinite(Number(lag.nir))?dms(lag.nir):'';
    html+='<div class="v38-center"><div style="width:100%"><div class="v38-title">कृष्णमूर्ती पद्धतीची लग्न व भावचलित कुंडली</div><div class="v38-data"><b>नाव:</b> '+val('name')+'<br><b>जन्मतारीख:</b> '+val('dob')+'<br><b>जन्मवेळ:</b> '+val('birthTime')+'<br><b>अक्षांश:</b> '+val('lat')+'<br><b>रेखांश:</b> '+val('lon')+(lagText?'<br><b>लग्न अंश:</b> '+lagText:'')+'</div></div></div>';
    chart.innerHTML=html;
    window.KPFortuna?.updateInfo('kundali-fortuna-info',window.KPFortuna.getNatal());
    const msg=document.getElementById('chartAscValidation');if(msg)msg.innerHTML=lagText?'<b>लग्न अंश:</b> '+lagText:'Tab 5 मधील भाव व Tab 6 मधील ग्रहस्थिती पूर्ण झाल्यावर कुंडली automatic भरेल.';
    window.KPPreferences?.decorate(chart);
  };
  function refresh(){try{window.renderChart(true)}catch(e){console.error('v38 chart',e)}}
  document.addEventListener('DOMContentLoaded',()=>{setTimeout(refresh,200);setTimeout(refresh,800);document.querySelectorAll('nav button[data-tab="south9"]').forEach(b=>b.addEventListener('click',()=>setTimeout(refresh,80)));document.querySelectorAll('#planet input,#raphael5 input,#raphael5 select').forEach(e=>e.addEventListener('input',()=>setTimeout(refresh,60)));});
})();

