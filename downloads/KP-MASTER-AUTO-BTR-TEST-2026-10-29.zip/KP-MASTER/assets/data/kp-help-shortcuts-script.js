
(()=>{'use strict';
const codes={home:'H',basic:'BD',ayan:'L',lmt:'LMT',stcalc:'ST',raphael5:'RH',planet:'PP',mdcalc:'MD',karyesh:'S','education-profession':'ED','disease':'D','dasha-promise':'DP','event-promise':'EP','horary-results':'HR','nadi-astrology':'NA','ruling-planets':'RP',matchmaking:'MM',aspects:'WA',transit:'T','transit-chart':'TC','transit-panchang':'TP',ephemeris:'E',south9:'SK',resources:'KR',report:'PR',astrosettings:'AS',about:'AB'};
function initialize(){
 const dialog=document.getElementById('workspace-help'),heading=document.createElement('h3');heading.textContent='Go to a tab';const note=document.createElement('p');note.textContent='Click a shortcut below, or press G followed by its initials. For example: G then NA opens Nadi Astrology. For one-letter shortcuts, briefly pause after the letter. Shortcuts are paused while you type in a field.';
 const grid=document.createElement('div');grid.className='help-shortcut-grid';grid.setAttribute('role','group');grid.setAttribute('aria-label','Tab shortcuts');
 for(const nav of document.querySelectorAll('.app-sidebar nav [data-tab]')){const tab=nav.dataset.tab,code=tab==='muhurta'?'MUH':codes[tab];if(nav.dataset.hiddenRoute==='true'||!code)continue;const button=document.createElement('button');button.type='button';button.id='help-go-'+tab;button.className='help-shortcut-button';button.dataset.helpTab=tab;button.dataset.helpKey=code;button.title='G then '+code;const key=document.createElement('kbd');key.textContent=code;key.dataset.noLocalize='true';const text=document.createElement('span');text.textContent=nav.querySelector('span:not(.nav-index)')?.firstChild?.textContent.trim()||tab;button.append(key,text);if(window.KPClientPresentation?.privateTabs.includes(tab))button.dataset.privateCalculation='true';button.addEventListener('click',()=>{dialog.close();nav.click();document.getElementById('workspace-main').focus({preventScroll:true});});grid.append(button);}
 dialog.querySelector('h3').before(heading,note,grid);
 const intro=dialog.querySelector(':scope>p');intro.textContent='Open or create a kundali in Birth details, review the chart and significators, then use the preview and print controls for your report.';
 const hint=document.createElement('div');hint.id='shortcut-hint';hint.hidden=true;hint.setAttribute('role','status');hint.setAttribute('aria-live','polite');document.body.append(hint);
 installKeys();
}
function installKeys(){let prefix=null,timer;const clear=()=>{prefix=null;clearTimeout(timer);const h=document.getElementById('shortcut-hint');if(h)h.hidden=true;};function go(tab){clear();const help=document.getElementById('workspace-help');if(help.open){document.getElementById('help-go-'+tab)?.click();return;}const quick=document.getElementById('quick-'+tab);if(quick)quick.click();else document.querySelector('.app-sidebar [data-tab="'+tab+'"]')?.click();}
 document.addEventListener('keydown',event=>{if(event.ctrlKey||event.metaKey||event.altKey||event.target.isContentEditable||event.target.closest('input,textarea,select')){clear();return;}if(event.key==='Escape'){clear();return;}if(prefix===null){if(event.key.toLowerCase()!=='g')return;prefix='';}else{if(!/^[a-z]$/i.test(event.key)){clear();return;}prefix+=event.key.toUpperCase();}
 event.preventDefault();clearTimeout(timer);const buttons=[...document.querySelectorAll('.help-shortcut-button')].filter(b=>!b.matches('[data-private-calculation]')||!document.body.classList.contains('kp-client-mode')),matches=buttons.filter(b=>b.dataset.helpKey.startsWith(prefix)),exact=matches.find(b=>b.dataset.helpKey===prefix);if(!matches.length){clear();return;}const hint=document.getElementById('shortcut-hint');hint.hidden=false;hint.textContent='Go to tab: G → '+(prefix||'initials');if(exact&&matches.length===1){go(exact.dataset.helpTab);return;}timer=setTimeout(()=>exact?go(exact.dataset.helpTab):clear(),prefix?800:2500);
 });
}
window.KPHelpShortcuts=Object.freeze({installKeys});
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

