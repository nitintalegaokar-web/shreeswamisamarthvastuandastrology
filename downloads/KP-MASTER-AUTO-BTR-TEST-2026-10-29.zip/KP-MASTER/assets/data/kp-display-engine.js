
/*
 * KP table models. Longitudes are absolute zodiac arcseconds, not degrees.
 * Fourfold: star occupancy, own occupancy, star ownership, own ownership.
 * Sixfold: sub occupancy, star occupancy, own occupancy, sub ownership,
 *          star ownership, own ownership.
 * Rahu and Ketu do not own signs. Ketu is always derived opposite Rahu.
 * Four-step strength follows the reference's empty-star / own-star rule.
 * The basic aspect columns use whole-sign Vedic aspects, with a configurable
 * cusp-conjunction orb; this convention is separate from KP star/sub levels.
 */
(function () {
  'use strict';

  const CIRCLE = 1296000, SIGN = 108000, NAK = 48000;
  const IDS = ['Su', 'Mo', 'Ma', 'Me', 'Ju', 'Ve', 'Sa', 'Ra', 'Ke'];
  const NAMES = ['रवी', 'चंद्र', 'मंगळ', 'बुध', 'गुरु', 'शुक्र', 'शनि', 'राहू', 'केतू'];
  const SIGNS = ['मेष', 'वृषभ', 'मिथुन', 'कर्क', 'सिंह', 'कन्या', 'तुळ', 'वृश्चिक', 'धनु', 'मकर', 'कुंभ', 'मीन'];
  const SIGN_CODES = ['Ar', 'Ta', 'Ge', 'Ca', 'Le', 'Vi', 'Li', 'Sc', 'Sg', 'Cp', 'Aq', 'Pi'];
  const SIGN_LORDS = ['Ma', 'Ve', 'Me', 'Mo', 'Su', 'Me', 'Ve', 'Ma', 'Ju', 'Sa', 'Sa', 'Ju'];
  const ORDER = ['Ke', 'Ve', 'Su', 'Mo', 'Ma', 'Ra', 'Ju', 'Sa', 'Me'];
  const YEARS = {Ke: 7, Ve: 20, Su: 6, Mo: 10, Ma: 7, Ra: 18, Ju: 16, Sa: 19, Me: 17};
  const NAK_NAMES = ['Ashwini', 'Bharani', 'Krittika', 'Rohini', 'Mrigashira', 'Ardra', 'Punarvasu', 'Pushya', 'Ashlesha', 'Magha', 'Purva Phalguni', 'Uttara Phalguni', 'Hasta', 'Chitra', 'Swati', 'Vishakha', 'Anuradha', 'Jyeshtha', 'Mula', 'Purva Ashadha', 'Uttara Ashadha', 'Shravana', 'Dhanishta', 'Shatabhisha', 'Purva Bhadrapada', 'Uttara Bhadrapada', 'Revati'];
  const NAK_CODES = ['Asw', 'Bha', 'Kri', 'Roh', 'Mri', 'Ard', 'Pun', 'Pus', 'Asl', 'Mag', 'Pph', 'Uph', 'Has', 'Cht', 'Swa', 'Vis', 'Anu', 'Jye', 'Mul', 'Psh', 'Ush', 'Shr', 'Dha', 'Sat', 'Pbh', 'Ubh', 'Rev'];
  const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
  const NAME_BY_ID = Object.fromEntries(IDS.map((id, i) => [id, NAMES[i]]));
  const ID_BY_NAME = Object.fromEntries(IDS.map((id, i) => [NAMES[i], id]));
  ID_BY_NAME['राहु'] = 'Ra'; ID_BY_NAME['केतु'] = 'Ke';
  const norm = value => ((value % CIRCLE) + CIRCLE) % CIRCLE;
  const validNumber = value => (typeof value === 'number' || typeof value === 'string' && value.trim() !== '') && Number.isFinite(Number(value));
  const sorted = values => [...new Set(values)].sort((a, b) => a - b);

  function formatDegree(longitude) {
    const value = Math.round(norm(longitude) % SIGN);
    return Math.floor(value / 3600) + '°' + String(Math.floor(value % 3600 / 60)).padStart(2, '0') + '′' + String(value % 60).padStart(2, '0') + '″';
  }

  // Half-open intervals assign an exact sub/sub-sub boundary to its new lord.
  function divideVimshottari(offset, total, startLord) {
    const start = ORDER.indexOf(startLord);
    let lower = 0;
    for (let i = 0; i < 9; i++) {
      const lord = ORDER[(start + i) % 9], span = total * YEARS[lord] / 120;
      if (offset < lower + span - 1e-7 || i === 8) return {lord, lower, span};
      lower += span;
    }
    return null;
  }

  function longitudeDetails(longitude) {
    const value = norm(longitude), si = Math.floor(value / SIGN), ni = Math.floor(value / NAK);
    const withinNak = value - ni * NAK, stl = ORDER[ni % 9];
    const sub = divideVimshottari(withinNak, NAK, stl);
    const subsub = divideVimshottari(withinNak - sub.lower, sub.span, sub.lord);
    return {
      longitude: value, signIndex: si, sign: SIGNS[si], signCode: SIGN_CODES[si],
      degree: formatDegree(value), nakshatra: NAK_NAMES[ni], nakCode: NAK_CODES[ni],
      nakIndex: ni, pada: Math.floor(withinNak / 12000) + 1,
      sgl: SIGN_LORDS[si], stl, sl: sub.lord, ssl: subsub.lord,
    };
  }

  function occupiedHouse(cusps, longitude) {
    for (let i = 0; i < 12; i++) {
      if (norm(longitude - cusps[i]) < norm(cusps[(i + 1) % 12] - cusps[i])) return i + 1;
    }
    return null;
  }

  const NOTATION_LABELS = Object.freeze({
    '[+]': 'No planet occupies this planet’s star',
    '[#]': 'In its own star', '[*]': 'In its own sub',
    '[R]': 'Retrograde', '[C]': 'Combust', '[e]': 'Empty house',
  });
  // The user supplied these limits. Mercury and Venus use smaller retrograde
  // limits; they are deliberately not the conventional combustion orbs.
  const COMBUSTION_ORBS = Object.freeze({Mo:4, Ma:8, Me:5, Ju:5, Ve:6, Sa:8});
  function isRetrograde(id, planet, configuration = {}) {
    const override = configuration.retrograde;
    if (override !== undefined) {
      if (override instanceof Set) return override.has(id);
      if (Array.isArray(override)) return override.includes(id);
      if (override && typeof override === 'object') return Boolean(override[id]);
      return Boolean(override);
    }
    if (typeof planet?.retrograde === 'boolean') return planet.retrograde;
    const index = IDS.indexOf(id), motion = String(document.getElementById('p6_motion_' + index)?.value || '').replace('−', '-');
    const final = String(document.getElementById('p6_final_' + index)?.value || '');
    return /\bR\b/i.test(motion + ' ' + final) || /^\s*-/.test(motion);
  }
  function getNotations(planetId, model = window.currentKPModel, configuration = {}) {
    const id = ID_BY_NAME[planetId] || planetId;
    if (!model?.ready || !IDS.includes(id)) return [];
    const planets = model.planets.filter(planet => IDS.includes(planet.id));
    const planet = planets.find(point => point.id === id);
    if (!planet) return [];
    const markers = [];
    // The planet itself counts as an occupant of its star. Consequently own
    // star [#] and an unoccupied star [+] are mutually exclusive.
    if (!planets.some(point => point.stl === id)) markers.push('[+]');
    if (planet.stl === id) markers.push('[#]');
    if (planet.sl === id) markers.push('[*]');
    const retrograde = isRetrograde(id, planet, configuration);
    if (retrograde && !['Ra','Ke'].includes(id)) markers.push('[R]');
    const sun = planets.find(point => point.id === 'Su');
    if (Object.hasOwn(COMBUSTION_ORBS, id) && validNumber(planet.longitude) && validNumber(sun?.longitude)) {
      const rule = configuration.combustionRule || window.KPPreferences?.get().combustionRule || 'planet-specific';
      const orb = rule === 'uniform' ? 8.5 : id === 'Me' && retrograde ? 3 : id === 'Ve' && retrograde ? 4 : COMBUSTION_ORBS[id];
      const distance = norm(Number(planet.longitude) - Number(sun.longitude));
      if (Math.min(distance, CIRCLE - distance) <= orb * 3600 + 1e-6) markers.push('[C]');
    }
    return markers;
  }
  function notationText(planetId, model, configuration) {
    return getNotations(planetId, model, configuration).join('');
  }
  function getHouseNotations(houseId, model = window.currentKPModel) {
    if (!model?.ready) return [];
    const house = model.houses.find(point => point.id === Number(houseId));
    return house && Array.isArray(house.occ) && !house.occ.some(id => IDS.includes(id)) ? ['[e]'] : [];
  }
  function legendHTML() {
    const rule = window.KPPreferences?.get().combustionRule || 'planet-specific';
    const labels = {...NOTATION_LABELS, '[+]':'No planet in its star', '[C]':rule === 'uniform' ? 'Combust (8.5°)' : 'Combust (specified planet limits)'};
    return Object.entries(labels).map(([marker, label]) => '<span><b>' + marker + '</b> ' + label + '</span>').join('');
  }

  function build(cuspValues, positions, configuration) {
    const rawOrb = configuration?.conjunctionOrb;
    const options = {
      conjunctionOrb: validNumber(rawOrb) ? Math.max(0, Math.min(15, Number(rawOrb))) : 3,
      aspectMode: 'vedic-whole-sign', ketuAspects: Boolean(configuration?.ketuAspects),
    };
    const empty = reason => ({ready: false, reason, planets: [], houses: [], fourfold: {planets: [], houses: []}, sixfold: {planets: [], houses: []}, fourstep: [], options});
    if (!Array.isArray(cuspValues) || cuspValues.length !== 12 || cuspValues.some(v => !validNumber(v))) return empty('Complete all twelve cusp longitudes.');
    const cusps = cuspValues.map(v => norm(Number(v)));
    const gaps = cusps.map((v, i) => norm(cusps[(i + 1) % 12] - v));
    if (gaps.some(g => g === 0) || Math.abs(gaps.reduce((a, b) => a + b, 0) - CIRCLE) > 1e-6) return empty('Cusps must form one ordered zodiac cycle.');
    const lp = {};
    for (let i = 0; i < 8; i++) {
      const id = IDS[i], value = positions?.[id] ?? positions?.[NAMES[i]] ?? (id === 'Ra' ? positions?.['राहु'] : undefined);
      if (!validNumber(value)) return empty('Complete all seven classical planets and Rahu.');
      lp[id] = norm(Number(value));
    }
    lp.Ke = norm(lp.Ra + CIRCLE / 2);

    const houses = cusps.map((lon, i) => ({id: i + 1, index: i, name: ROMAN[i], ...longitudeDetails(lon), occ: [], aspd: [], conj: []}));
    const planets = IDS.map((id, i) => ({id, index: i, name: NAMES[i], ...longitudeDetails(lp[id]), occ: occupiedHouse(cusps, lp[id]), own: [], csl: [], cstl: [], aspd: [], aspg: {planets: [], houses: []}, conj: [], planetConj: []}));
    const byId = Object.fromEntries(planets.map(p => [p.id, p]));
    for (const house of houses) {
      byId[house.sgl].own.push(house.id);
      byId[house.sl].csl.push(house.id);
      byId[house.stl].cstl.push(house.id);
      house.occ = planets.filter(p => p.occ === house.id).map(p => p.id);
    }

    const aspects = {Su: [7], Mo: [7], Ma: [4, 7, 8], Me: [7], Ju: [5, 7, 9], Ve: [7], Sa: [3, 7, 10], Ra: [5, 7, 9], Ke: options.ketuAspects ? [5, 7, 9] : []};
    const orb = options.conjunctionOrb * 3600;
    for (const p of planets) {
      const targetSigns = new Set(aspects[p.id].map(step => (p.signIndex + step - 1) % 12));
      p.aspg.planets = planets.filter(q => q.id !== p.id && (q.id !== 'Ke' || options.ketuAspects) && targetSigns.has(q.signIndex)).map(q => q.id);
      p.aspg.houses = houses.filter(h => targetSigns.has(h.signIndex)).map(h => h.id);
      for (const q of p.aspg.planets) byId[q].aspd.push(p.id);
      for (const h of p.aspg.houses) houses[h - 1].aspd.push(p.id);
      p.planetConj = planets.filter(q => q.id !== p.id && Math.min(norm(p.longitude - q.longitude), norm(q.longitude - p.longitude)) <= orb + 1e-6).map(q => q.id);
      for (const house of houses) {
        const separation = norm(p.longitude - house.longitude);
        if (Math.min(separation, CIRCLE - separation) <= orb + 1e-6) {
          p.conj.push(house.id);
          house.conj.push(p.id);
        }
      }
    }

    const fourPlanets = planets.map(p => ({
      id: p.id, index: p.index, name: p.name,
      A: [byId[p.stl].occ], B: [p.occ], C: [...byId[p.stl].own], D: [...p.own],
      CSL: [...p.csl], Aspd: [...p.aspd], Aspg: p.aspg, Conj: [...p.conj],
    }));
    const sixPlanets = planets.map(p => ({
      id: p.id, index: p.index, name: p.name,
      A: [byId[p.sl].occ], B: [byId[p.stl].occ], C: [p.occ],
      D: [...byId[p.sl].own], E: [...byId[p.stl].own], F: [...p.own], CSL: [...p.csl],
    }));
    function applyNodeSignificatorRules(rows, fields) {
      const rowById=Object.fromEntries(rows.map(row=>[row.id,row])),union=row=>sorted(fields.flatMap(field=>row[field]||[]));
      const evidence=Object.fromEntries(rows.map(row=>[row.id,[]]));
      // Rules 8(a)/(b): nodes inherit the complete significator houses of
      // planets aspecting or conjoining them. Contributions are non-recursive.
      for(const nodeId of ['Ra','Ke']){
        const node=byId[nodeId],sources=[...new Set([...node.aspd,...node.planetConj])],row=rowById[nodeId];
        for(const sourceId of sources){const inherited=union(rowById[sourceId]);row[fields[1]]=sorted([...(row[fields[1]]||[]),...inherited]);evidence[nodeId].push({rule:node.aspd.includes(sourceId)?'node-aspected-by':'node-conjunction',source:sourceId,houses:inherited});}
      }
      // Rule 9: a planet in Rahu/Ketu's star inherits that node's complete
      // significator houses after the node aspect/conjunction rules above.
      for(const planet of planets){if(!['Ra','Ke'].includes(planet.stl))continue;const inherited=union(rowById[planet.stl]),row=rowById[planet.id];row[fields[0]]=sorted([...(row[fields[0]]||[]),...inherited]);evidence[planet.id].push({rule:'node-star-inheritance',source:planet.stl,houses:inherited});}
      // Exceptional rule: when a house has exactly one significator, planets
      // placed in that significator's sub become principal significators.
      const before=Object.fromEntries(rows.map(row=>[row.id,union(row)]));
      for(const house of houses){const sole=rows.filter(row=>before[row.id].includes(house.id));if(sole.length!==1)continue;for(const planet of planets.filter(p=>p.sl===sole[0].id)){const row=rowById[planet.id];row[fields[1]]=sorted([...(row[fields[1]]||[]),house.id]);evidence[planet.id].push({rule:'unique-significator-sub',source:sole[0].id,houses:[house.id]});}}
      for(const row of rows)row.KPNodeRules=evidence[row.id];
    }
    applyNodeSignificatorRules(fourPlanets,['A','B','C','D']);
    applyNodeSignificatorRules(sixPlanets,['A','B','C','D','E','F']);
    function houseLevels(rows, fields) {
      return houses.map(h => {
        const row = {id: h.id, index: h.index, name: h.name, CSL: h.sl, Aspd: [...h.aspd], Conj: [...h.conj]};
        for (const field of fields) row[field] = rows.filter(p => p[field].includes(h.id)).map(p => p.id);
        return row;
      });
    }

    function step(planetId, label, forceStarLevel) {
      const p = byId[planetId], ownStar = p.stl === p.id;
      const hasStarOccupants = planets.some(q => q.stl === p.id);
      const active = Boolean(forceStarLevel || ownStar || !hasStarOccupants);
      const emptyOwned = p.own.filter(h => houses[h - 1].occ.length === 0);
      const baseHouses = active ? sorted([p.occ, ...emptyOwned]) : [];
      // Incoming whole-sign aspects supply the aspecting planet's direct
      // occupation and empty-house ownership, without recursively inheriting aspects.
      const aspectContributions = active ? p.aspd.map(id => {
        const source = byId[id];
        return {planet: id, houses: sorted([source.occ, ...source.own.filter(h => houses[h - 1].occ.length === 0)])};
      }) : [];
      return {label, planet: planetId, name: p.name, baseHouses,
        houses: sorted([...baseHouses, ...aspectContributions.flatMap(source => source.houses)]),
        aspectContributions, csl: active && !forceStarLevel ? [...p.csl] : [], ownStar: active && ownStar && !forceStarLevel, nil: !active};
    }
    const fourstep = planets.map(p => ({id: p.id, index: p.index, name: p.name, steps: [
      step(p.id, 'Planet', false),
      step(p.stl, 'Star lord', true),
      step(p.sl, 'Sub lord', false),
      step(byId[p.sl].stl, 'Star lord of sub lord', true),
    ]}));
    return {
      ready: true, planets, houses,
      fourfold: {planets: fourPlanets, houses: houseLevels(fourPlanets, ['A', 'B', 'C', 'D'])},
      sixfold: {planets: sixPlanets, houses: houseLevels(sixPlanets, ['A', 'B', 'C', 'D', 'E', 'F'])},
      fourstep, options,
      definitions: {
        fourfold: {A: 'Star lord occupied house', B: 'Planet occupied house', C: 'Star lord owned houses', D: 'Planet owned houses'},
        sixfold: {A: 'Sub lord occupied house', B: 'Star lord occupied house', C: 'Planet occupied house', D: 'Sub lord owned houses', E: 'Star lord owned houses', F: 'Planet owned houses'},
        fourstep: 'Planet → star lord → sub lord → sub lord’s star lord. Planet/sub levels are active for own-star planets or planets with no graha in their star. Ownership contributes only empty houses. Incoming whole-sign aspects add the aspecting planet’s occupied and empty owned houses, once, with source evidence.',
        aspects: 'Whole-sign Vedic aspects: all planets 7th; Mars 4/7/8, Jupiter and Rahu 5/7/9, Saturn 3/7/10. Ketu aspects are omitted unless enabled.',
        nodeSignificators: 'Rahu/Ketu inherit houses from planets aspecting or conjoining them. Planets in a node star inherit that node’s houses. If a house has only one significator, planets in that significator’s sub become principal significators. Houses are deduplicated and evidence is stored in KPNodeRules.',
      },
    };
  }

  window.KPDisplay = Object.freeze({build, ids: Object.freeze([...IDS]), names: Object.freeze({...NAME_BY_ID}), idByName: Object.freeze({...ID_BY_NAME}), longitudeDetails, formatDegree, getNotations, notationText, getHouseNotations, notationLabels:NOTATION_LABELS, legendHTML});
})();

