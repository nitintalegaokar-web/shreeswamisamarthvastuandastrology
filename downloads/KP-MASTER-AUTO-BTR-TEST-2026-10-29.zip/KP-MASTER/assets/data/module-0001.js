
document.addEventListener("DOMContentLoaded",()=>{
  const ids=["stdLon","placeStdLon","birthTime","dayAyan","daySum"];
  ids.forEach(id=>{
    const el=document.getElementById(id);
    if(el) el.addEventListener("input",()=>{
      updateTotalAyanamsha();
      updateLongitudeDifference();
      updateLMTCalculation();
      updateSiderealTimeCalculation(); updateSampattikTimeDifferences();
    });
  });
  updateTotalAyanamsha();
  syncPlaceLongitudeFromBasic();
  updateLongitudeDifference();
  updateLMTCalculation();
  updateSiderealTimeCalculation(); updateSampattikTimeDifferences();
});

