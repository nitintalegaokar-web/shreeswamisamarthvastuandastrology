
/* Placidus divides each zodiac point's diurnal/nocturnal semi-arc into thirds.
 * Solve right ascension minus local sidereal time against that semi-arc;
 * opposite cusps differ by 180°. Positions share the ephemeris ayanamsha.
 */
(() => {
  'use strict';
  const RAD = Math.PI / 180;
  const norm = value => ((value % 360) + 360) % 360;
  function calculate(value, latitude, longitudeEast) {
    const date = window.KPEphemeris.dateValue(value);
    const lat = Number(latitude), lon = Number(longitudeEast);
    if (latitude === null || longitudeEast === null || String(latitude).trim() === '' || String(longitudeEast).trim() === '' || !Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lon) > 180 || Math.abs(lat) >= 90) throw new Error('Enter a valid latitude and longitude for transit cusps.');
    const obliquity = Astronomy.e_tilt(Astronomy.MakeTime(date)).tobl;
    if (Math.abs(lat) >= 90 - obliquity) throw new Error('Placidus transit cusps are unavailable within the polar circles. Use natal cusps or choose a location below ' + (90 - obliquity).toFixed(2) + '° latitude.');
    const theta = norm(Astronomy.SiderealTime(date) * 15 + lon);
    const eps = obliquity * RAD, tanLat = Math.tan(lat * RAD);
    const mc = norm(Math.atan2(Math.sin(theta * RAD) / Math.cos(eps), Math.cos(theta * RAD)) / RAD);
    const ascendant = norm(Math.atan2(Math.cos(theta * RAD), -Math.sin(theta * RAD) * Math.cos(eps) - tanLat * Math.sin(eps)) / RAD);
    const ascOffset = norm(ascendant - mc);
    function point(offset) {
      const lambda = (mc + offset) * RAD;
      const declination = Math.asin(Math.sin(eps) * Math.sin(lambda));
      const argument = -tanLat * Math.tan(declination);
      if (Math.abs(argument) > 1 + 1e-12) throw new Error('Placidus transit cusps cannot be calculated where a zodiac point does not rise or set.');
      const semiArc = Math.acos(Math.max(-1, Math.min(1, argument))) / RAD;
      const rightAscension = norm(Math.atan2(Math.cos(eps) * Math.sin(lambda), Math.cos(lambda)) / RAD);
      return {rightAscension: norm(rightAscension - theta), semiArc};
    }
    function solve(lower, upper, target) {
      let left = lower, right = upper;
      for (let iteration = 0; iteration < 60 && right - left > 1e-10; iteration++) {
        const middle = (left + right) / 2, coordinates = point(middle);
        if (coordinates.rightAscension < target(coordinates.semiArc)) left = middle;
        else right = middle;
      }
      return norm(mc + (left + right) / 2);
    }
    const cusp11 = solve(0, ascOffset, arc => arc / 3);
    const cusp12 = solve(0, ascOffset, arc => arc * 2 / 3);
    const cusp2 = solve(ascOffset, 180, arc => 60 + arc * 2 / 3);
    const cusp3 = solve(ascOffset, 180, arc => 120 + arc / 3);
    const tropicalCusps = [ascendant, cusp2, cusp3, norm(mc + 180), norm(cusp11 + 180), norm(cusp12 + 180), norm(ascendant + 180), norm(cusp2 + 180), norm(cusp3 + 180), mc, cusp11, cusp12];
    const ayanamsha = window.KPEphemeris.ayanamsha(date);
    const cusps = tropicalCusps.map(cusp => norm(cusp - ayanamsha));
    return {cusps, ascendant:cusps[0], mc:cusps[9], system:'Placidus', units:'degrees'};
  }
  function ascendant(value,latitude,longitudeEast){
    const date=window.KPEphemeris.dateValue(value),lat=Number(latitude),lon=Number(longitudeEast);
    if(latitude===null||longitudeEast===null||String(latitude).trim()===''||String(longitudeEast).trim()===''||!Number.isFinite(lat)||!Number.isFinite(lon)||Math.abs(lon)>180||Math.abs(lat)>=66.5)throw new Error('Ascendant timing requires valid coordinates below 66.5° latitude.');
    const eps=Astronomy.e_tilt(Astronomy.MakeTime(date)).tobl*RAD,theta=norm(Astronomy.SiderealTime(date)*15+lon)*RAD;
    return norm(Math.atan2(Math.cos(theta),-Math.sin(theta)*Math.cos(eps)-Math.tan(lat*RAD)*Math.sin(eps))/RAD-window.KPEphemeris.ayanamsha(date));
  }
  window.KPTransitHouses = Object.freeze({calculate,ascendant, system:'Placidus', units:'degrees'});
  window.dispatchEvent(new CustomEvent('kp-transit-houses-ready'));
})();

