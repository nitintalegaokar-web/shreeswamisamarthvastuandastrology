
/* Automatic 05:30 standard-time rows for the existing daily interpolation.
 * Rows are sidereal: Tab 6 removes whole signs, not another ayanamsha.
 * Manual source values and Raphael house-table brackets remain editable.
 */
(() => {
  'use strict';
  const DAY=86400000, PLANETS=['Su','Mo','Ma','Me','Ju','Ve','Sa','Ra','Ke'];
  const byId=id=>document.getElementById(id), value=id=>String(byId(id)?.value||'').trim();
  const enabled=id=>value(id)==='automatic';
  const set=(id,text)=>{const field=byId(id);if(field)field.value=text;};
  const normalize=(number,total)=>((number%total)+total)%total;
  let rowCache=new Map(), cacheContext='', planetData=null, siderealData=null, timer;
  function status(id,text,ready=null){
    const output=byId(id);if(!output)return;
    output.textContent=text;
    if(ready===null)delete output.dataset.ready;else output.dataset.ready=String(ready);
  }
  function calendarDate(text){
    if(!/^\d{4}-\d{2}-\d{2}$/.test(text))throw new Error('Enter a valid birth date and two ephemeris dates.');
    const date=new Date(text+'T00:00:00Z');
    if(!Number.isFinite(date.getTime())||date.toISOString().slice(0,10)!==text)throw new Error('Enter valid calendar dates.');
    return date;
  }
  function birthSeconds(){
    const match=/^(\d{1,2}):([0-5]\d)(?::([0-5]\d))?$/.exec(value('birthTime'));
    if(!match||Number(match[1])>23)throw new Error('Enter a valid birth time.');
    return Number(match[1])*3600+Number(match[2])*60+Number(match[3]||0);
  }
  function standardOffset(){
    const text=value('stdLon'),match=/^([+-]?)(\d+(?:\.\d+)?)(?::(\d+(?:\.\d+)?))?(?::(\d+(?:\.\d+)?))?$/.exec(text);
    if(!match||Number(match[3]||0)>=60||Number(match[4]||0)>=60)throw new Error('Enter a valid standard meridian in the longitude worksheet.');
    const degrees=(match[1]==='-'?-1:1)*(Number(match[2])+Number(match[3]||0)/60+Number(match[4]||0)/3600);
    if(Math.abs(degrees)>210)throw new Error('The standard time offset must be between UTC−14 and UTC+14.');
    return degrees/15;
  }
  function instant(dateText,offset){
    const date=new Date(calendarDate(dateText).getTime()+(5.5-offset)*3600000);
    return window.KPEphemeris.dateValue(date);
  }
  function dms(degrees){
    const total=normalize(Math.round(degrees*3600),1296000);
    return Math.floor(total/3600)+':'+String(Math.floor(total%3600/60)).padStart(2,'0')+':'+String(total%60).padStart(2,'0');
  }
  function hms(hours){
    const total=normalize(Math.round(hours*3600),86400);
    return String(Math.floor(total/3600)).padStart(2,'0')+':'+String(Math.floor(total%3600/60)).padStart(2,'0')+':'+String(total%60).padStart(2,'0');
  }
  function offsetLabel(offset){return 'UTC'+(offset>=0?'+':'−')+Math.abs(offset)+(offset===5.5?' (IST)':'');}
  function row(dateText){
    const offset=standardOffset(),dob=value('dob');calendarDate(dob);
    const context=JSON.stringify([dob,value('ayanValue'),value('kp-ayanamsha-source'),offset]);
    if(context!==cacheContext){cacheContext=context;rowCache.clear();}
    if(rowCache.has(dateText))return rowCache.get(dateText);
    const uploaded=offset===5.5?window.KPUploadedEphemeris?.get(dateText):null;
    const utc=uploaded?new Date(dateText+'T00:00:00Z'):instant(dateText,offset),positions=uploaded?.positions||window.KPEphemeris.positions(utc);
    if(PLANETS.some(id=>!Number.isFinite(positions[id])))throw new Error('The ephemeris could not calculate all planets.');
    const result={date:dateText,utc:utc.toISOString(),positions,source:uploaded?'Adjusted uploaded Excel':'Calculated ephemeris'};
    // Date edits must not leave an unbounded ephemeris cache in this single file.
    if(rowCache.size>=8)rowCache.clear();
    rowCache.set(dateText,result);return result;
  }
  function syncDates(force=false){
    const dob=value('dob'),birth=calendarDate(dob),before=birthSeconds()<19800;
    const dates=[new Date(birth.getTime()+(before?-1:0)*DAY).toISOString().slice(0,10),new Date(birth.getTime()+(before?0:1)*DAY).toISOString().slice(0,10)];
    dates.forEach((date,index)=>{
      const field=byId('p6_row_date_'+(index+1));
      if(field&&(force||!field.value||field.dataset.auto!=='0')){field.value=date;field.dataset.auto='1';}
    });
  }
  function preparePositions(){
    if(!enabled('p6-ephemeris-source')){
      planetData=null;
      status('p6-ephemeris-status','Manual ephemeris entry. Choose Automatic KP ephemeris to fill both dated rows and the 05:30 AM sidereal time.');
      return null;
    }
    try{
      syncDates(true);
      const dates=[value('p6_row_date_1'),value('p6_row_date_2')],dob=value('dob');
      dates.forEach(calendarDate);
      if(dates[0]===dates[1]||!dates.includes(dob))throw new Error('Use two different ephemeris dates, including the birth date.');
      // The existing interpolation takes the shortest angular difference.
      // Keep even edited endpoints close enough to avoid aliasing lunar motion.
      if(Math.abs(calendarDate(dates[1])-calendarDate(dates[0]))>7*DAY)throw new Error('Keep automatic ephemeris dates within seven days of each other.');
      // Calculate both endpoints before changing any worksheet source value.
      const rows=dates.map(row),offset=standardOffset();
      rows.forEach((result,index)=>{
        PLANETS.forEach((id,planet)=>set('p6_'+(index===0?'d':'t')+'_'+planet,dms(result.positions[id])));
        set('p6_date_'+(index+1),result.date);set('p6_time_'+(index+1),'05:30:00');set('p6_ampm_'+(index+1),'AM');
      });
      planetData={ready:true,dates,offset,time:'05:30:00',rows};
      status('p6-ephemeris-status',dates.join(' → ')+' · '+rows.map(r=>r.source).filter((v,i,a)=>a.indexOf(v)===i).join(' / ')+' · 05:30 AM '+offsetLabel(offset)+' · Positions are already nirayan; uploaded values are used without subtracting ayanamsha again. Birth positions use the worksheet’s daily interpolation. Editing a position switches to Manual.',true);
      return planetData;
    }catch(error){
      planetData=null;
      for(let index=0;index<9;index++){set('p6_d_'+index,'');set('p6_t_'+index,'');}
      status('p6-ephemeris-status','Automatic ephemeris unavailable: '+error.message+' Choose Manual to enter printed ephemeris values.',false);
      return null;
    }
  }
  function prepareSidereal(){
    if(!enabled('st-ephemeris-source')){
      siderealData=null;status('st-ephemeris-status','Manual 05:30 AM sidereal time. Editing this value keeps manual entry active.');return null;
    }
    try{
      const reference=getLMTSiderealReference();
      const date=reference?.date||value('dob'),offset=standardOffset(),uploaded=offset===5.5?window.KPUploadedEphemeris?.get(date):null,utc=uploaded?new Date(date+'T00:00:00Z'):instant(date,offset);
      const hours=uploaded?uploaded.st/3600:normalize(Astronomy.SiderealTime(utc)+offset,24);
      set('baseSidereal0530',hms(hours));
      siderealData={ready:true,date,utc:utc.toISOString(),offset,hours,source:uploaded?'Adjusted uploaded Excel':'Calculated ephemeris'};
      status('st-ephemeris-status',date+' · '+(uploaded?'Adjusted uploaded Excel · ST +1 second':'Calculated ephemeris')+' · 05:30 AM '+offsetLabel(offset)+' · Local sidereal time at the standard meridian: '+hms(hours)+'. Traditional 10/6 correction is used for both this worksheet and Bhavsadhan; longitude is applied once.',true);
      return siderealData;
    }catch(error){
      siderealData=null;set('baseSidereal0530','');
      status('st-ephemeris-status','Automatic sidereal time unavailable: '+error.message,false);return null;
    }
  }
  function siderealCalculation(moment){
    try{
    moment=moment||window.KPHorary.nativeMoment();
    if(!enabled('st-ephemeris-source')||!siderealData?.ready)return null;
    const anchor=new Date(siderealData.utc),utElapsed=(moment.date-anchor)/1000;
    // Match the visible worksheet's whole-second inputs. The traditional KP
    // correction uses complete hours × 10 seconds plus remaining minutes ÷ 6,
    // with one final half-up rounding inside the shared helper.
    const base=Math.round(siderealData.hours*3600);
    const elapsed=Math.round(utElapsed+(moment.longitude-siderealData.offset*15)*240);
    const correction=calculateTenSixCorrectionSeconds(elapsed),total=base+elapsed+correction;
    return {base,elapsed,correction,total,seconds:normalize(total,86400)};
    }catch(_){return null;}
  }
  function prepare(){prepareSidereal();return preparePositions();}
  // All legacy dated-row loaders use the same generated source while enabled.
  const manualFind=window.findEph;
  window.findEph=function(date){
    if(!enabled('p6-ephemeris-source'))return undefined;
    try{const result=row(date);return [date,...PLANETS.map(id=>dms(result.positions[id]))];}catch(error){return undefined;}
  };
  window.KPWorksheetEphemeris=Object.freeze({prepare,preparePositions,prepareSidereal,siderealCalculation,getData:()=>planetData?JSON.parse(JSON.stringify(planetData)):null,getSidereal:()=>siderealData?{...siderealData}:null});
  function capture(event){
    const id=event.target?.id||'';
    if(/^p6_row_date_[12]$/.test(id))event.target.dataset.auto='0';
    if(/^p6_[dt]_\d$/.test(id)&&enabled('p6-ephemeris-source')){set('p6-ephemeris-source','manual');planetData=null;}
    if(id==='baseSidereal0530'&&enabled('st-ephemeris-source')){set('st-ephemeris-source','manual');siderealData=null;}
    if(id==='p6-ephemeris-source'&&enabled(id)){
      set('st-ephemeris-source','automatic');
      try{syncDates(true);}catch(error){/* Preparation displays invalid inputs. */}
    }
  }
  document.addEventListener('input',capture,true);document.addEventListener('change',capture,true);
  document.addEventListener('DOMContentLoaded',()=>{
    prepare();
 const changed=event=>{
  if(document.readyState!=='complete'&&!event.isTrusted)return;
      const id=event.target?.id||'';
      if(!['dob','birthTime','dayAyan','daySum','kp-ayanamsha-source','stdLon','p6-ephemeris-source','st-ephemeris-source','baseSidereal0530','p6_row_date_1','p6_row_date_2'].includes(id)&&!/^p6_[dt]_\d$/.test(id))return;
      prepare();
      // Earlier worksheet listeners may queue their own dated-row pass.
      // Recalculate the complete native model after those listeners settle.
      clearTimeout(timer);timer=setTimeout(()=>window.calculateAll(),90);
    };
    document.addEventListener('input',changed);document.addEventListener('change',changed);
  });
})();

