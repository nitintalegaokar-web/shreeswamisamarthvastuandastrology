
(function () {
  'use strict';
  const codes = ['Su', 'Mo', 'Ma', 'Me', 'Ju', 'Ve', 'Sa', 'Ra', 'Ke'];
  const names = ['रवी', 'चंद्र', 'मंगळ', 'बुध', 'गुरु', 'शुक्र', 'शनि', 'राहू', 'केतू'];
  const roman = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
  const escape = value => String(value ?? '').replace(/[&<>"']/g, character => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[character]));
  const cell = value => Array.isArray(value) ? (value.length ? value.join(', ') : '—') : (value === null || value === undefined || value === '' ? '—' : String(value));
  const aspect = value => value ? cell([...(value.planets || []), ...(value.houses || [])]) : '—';
  const placeholderPlanets = codes.map((id, index) => ({id, index, name: names[index]}));
  const placeholderHouses = roman.map((name, index) => ({id: index + 1, index, name}));
  const columns = {
    basicPlanet: [['signCode', 'Sign', 'राशी'], ['degree', 'Deg', 'राशीतील अंश'], ['nak', 'Nak', 'नक्षत्र व चरण'], ['occ', 'Occ', 'ग्रहाचा भाव'], ['own', 'Own', 'स्वामित्वाचे भाव'], ['sgl', 'SgL', 'राशीस्वामी'], ['stl', 'StL', 'नक्षत्रस्वामी'], ['sl', 'SL', 'उपनक्षत्रस्वामी'], ['ssl', 'SSL', 'उप-उपनक्षत्रस्वामी'], ['csl', 'CSL', 'हा ग्रह उपनक्षत्रस्वामी असलेले भाव'], ['cstl', 'CStL', 'हा ग्रह नक्षत्रस्वामी असलेले भाव'], ['aspd', 'Aspd', 'या ग्रहावर दृष्टी असणारे ग्रह'], ['aspg', 'Aspg', 'या ग्रहाची दृष्टी असलेले ग्रह व भाव'], ['conj', 'Conj', 'भावमध्याशी युती']],
    basicHouse: [['signCode', 'Sign', 'राशी'], ['degree', 'Deg', 'भावमध्य अंश'], ['nak', 'Nak', 'नक्षत्र व चरण'], ['occ', 'Occ', 'भावातील ग्रह'], ['sgl', 'SgL', 'राशीस्वामी'], ['stl', 'StL', 'नक्षत्रस्वामी'], ['sl', 'SL', 'उपनक्षत्रस्वामी'], ['ssl', 'SSL', 'उप-उपनक्षत्रस्वामी'], ['aspd', 'Aspd', 'भावावर दृष्टी असणारे ग्रह'], ['conj', 'Conj', 'भावमध्याशी युतीतील ग्रह']],
    fourPlanet: [['A', 'A', 'नक्षत्रस्वामीचा भाव'], ['B', 'B', 'ग्रहाचा भाव'], ['C', 'C', 'नक्षत्रस्वामीचे स्वामित्व'], ['D', 'D', 'ग्रहाचे स्वामित्व'], ['CSL', 'CSL', 'भाव उपनक्षत्रस्वामी'], ['Aspd', 'Aspd', 'ग्रहावर दृष्टी'], ['Aspg', 'Aspg', 'ग्रहाची दृष्टी'], ['Conj', 'Conj', 'भावमध्याशी युती']],
    fourHouse: [['A', 'A', 'भावातील ग्रहांच्या नक्षत्रातील ग्रह'], ['B', 'B', 'भावातील ग्रह'], ['C', 'C', 'भावस्वामीच्या नक्षत्रातील ग्रह'], ['D', 'D', 'भावस्वामी'], ['CSL', 'CSL', 'भाव उपनक्षत्रस्वामी'], ['Aspd', 'Aspd', 'भावावर दृष्टी'], ['Conj', 'Conj', 'भावमध्याशी युती']],
    sixPlanet: ['A', 'B', 'C', 'D', 'E', 'F', 'CSL'].map(key => [key, key, key === 'CSL' ? 'भाव उपनक्षत्रस्वामी' : 'Six-fold ' + key]),
    sixHouse: ['A', 'B', 'C', 'D', 'E', 'F', 'CSL'].map(key => [key, key, key === 'CSL' ? 'भाव उपनक्षत्रस्वामी' : 'Six-fold ' + key])
  };
  function valueFor(row, key) {
    if (key === 'nak') return row.nakCode ? row.nakCode + ' (' + row.pada + ')' : '—';
    if (key.toLowerCase() === 'aspg') return aspect(row[key]);
    return cell(row[key]);
  }
  const showNotationMarkers = () => window.KPPreferences?.get().notationMarkers !== false;
  function notationHTML(markers) {
    if (!showNotationMarkers() || !markers.length) return '';
    const tooltips = window.KPPreferences?.get().tooltips !== false;
    return '<span class="kp-notations">' + markers.map(marker => '<span class="kp-notation-marker" data-marker="' + escape(marker) + '"' + (tooltips ? ' title="' + escape(window.KPDisplay.notationLabels[marker]) + '"' : '') + '>' + escape(marker) + '</span>').join('') + '</span>';
  }
  function planetHTML(id, marked = true) {
    return '<span class="kp-planet-reference" data-planet-ref="' + escape(id) + '"><span class="kp-planet-label">' + escape(id) + '</span>' + (marked ? notationHTML(window.KPDisplay.getNotations(id)) : '') + '</span>';
  }
  function referenceHTML(value) {
    if (Array.isArray(value)) return value.length ? value.map(referenceHTML).join(', ') : '—';
    return codes.includes(value) ? planetHTML(value, false) : escape(cell(value));
  }
  function renderedValue(row, key) {
    if (key === 'nak') return escape(valueFor(row, key));
    if (key.toLowerCase() === 'aspg') return row[key] ? referenceHTML([...(row[key].planets || []), ...(row[key].houses || [])]) : '—';
    return referenceHTML(row[key]);
  }
  function renderNotationLegends() {
    document.querySelectorAll('#kp-basic-calculations,#kp-fourfold,#kp-sixfold,#kp-fourstep-section').forEach(section => {
      let legend = section.querySelector(':scope>.kp-notation-legend');
      if (!legend) {
        legend = document.createElement('p');
        legend.className = 'kp-notation-legend';
        legend.dataset.notationsLegend = '';
        legend.setAttribute('aria-label', 'Planet and house notation key');
        section.querySelector('h3')?.after(legend);
      }
      legend.hidden = !showNotationMarkers();
      legend.innerHTML = window.KPDisplay.legendHTML();
    });
  }
  function table(id, rows, fields, houses, ready) {
    const table = document.getElementById(id);
    if (!table) return;
    table.innerHTML = '<thead><tr><th scope="col">' + (houses ? 'Hou' : 'Pln') + '</th>' + fields.map(([key, title, description]) => '<th scope="col" title="' + escape(description) + '">' + title + '</th>').join('') + '</tr></thead><tbody>' + rows.map(row => '<tr data-' + (houses ? 'house' : 'planet') + '="' + escape(row.id) + '"><th scope="row" title="' + escape(row.name) + '">' + (houses ? escape(row.name) + (ready ? notationHTML(window.KPDisplay.getHouseNotations(row.id)) : '') : ready ? planetHTML(row.id) : '<span class="kp-planet-label">' + escape(row.id) + '</span>') + '</th>' + fields.map(([key]) => '<td data-field="' + key + '">' + (ready ? renderedValue(row, key) : '—') + '</td>').join('') + '</tr>').join('') + '</tbody>';
  }
  function renderSteps(cards, ready) {
    const target = document.getElementById('kp-fourstep');
    if (!target) return;
    const stepKeys = ['planet', 'star', 'sub', 'sub-star'];
    const stepLabels = ['Planet', 'Star lord', 'Sub lord', 'Star lord of sub'];
    target.innerHTML = cards.map(card => '<article class="kp-step-card" data-planet="' + card.id + '"><h4>' + (ready ? planetHTML(card.id) : '<span class="kp-planet-label">' + escape(card.id) + '</span>') + '</h4>' + stepKeys.map((key, index) => {
      const step = card.steps?.[index];
      let result = '—';
      if (ready && step) {
        result = planetHTML(step.planet, false) + ': ' + (step.nil ? '<span class="kp-nil">Nil</span>' : escape(cell(step.baseHouses || step.houses)));
        if (step.aspectContributions?.length) result += ' <span class="kp-step-aspects" title="Incoming whole-sign aspect contributions">Aspd: [' + step.aspectContributions.map(source => planetHTML(source.planet, false) + ': ' + escape(cell(source.houses))).join('; ') + ']</span>';
        if (step.ownStar) result += ' <span class="kp-own-star">Own Star</span>';
        if (step.csl?.length) result += ' <span class="kp-csl">CSL (' + escape(cell(step.csl)) + ')</span>';
      }
      return '<div class="kp-step" data-step="' + key + '"><span class="kp-step-label">' + stepLabels[index] + '</span><strong>' + result + '</strong></div>';
    }).join('') + '</article>').join('');
  }
  window.updateKaryeshTables = function () {
    if (!window.KPDisplay || !window.syncKPWorksheetPositions) return;
    const positions = window.syncKPWorksheetPositions();
    const enteredOrb = Number(document.getElementById('kp-conjunction-orb')?.value);
    const conjunctionOrb = Number.isFinite(enteredOrb) && enteredOrb >= 0 && enteredOrb <= 10 ? enteredOrb : 3;
    const model = window.KPDisplay.build(positions.cusps, positions.lp, {conjunctionOrb,ketuAspects:Boolean(window.KPPreferences?.get().ketuAspects)});
    window.currentKPModel = model;
    const ready = model.ready;
    const status = document.getElementById('kp-status');
    if (status) {
      status.dataset.ready = String(ready);
      status.hidden = ready;
      status.textContent = ready ? '' : 'Complete the house cusps in Tab 5 and planet positions in Tab 6. Rahu supplies Ketu automatically.';
    }
    table('kp-basic-planet', ready ? model.planets : placeholderPlanets, columns.basicPlanet, false, ready);
    table('kp-basic-house', ready ? model.houses : placeholderHouses, columns.basicHouse, true, ready);
    table('kp-fourfold-planet', ready ? model.fourfold.planets : placeholderPlanets, columns.fourPlanet, false, ready);
    table('kp-fourfold-house', ready ? model.fourfold.houses : placeholderHouses, columns.fourHouse, true, ready);
    table('kp-sixfold-planet', ready ? model.sixfold.planets : placeholderPlanets, columns.sixPlanet, false, ready);
    table('kp-sixfold-house', ready ? model.sixfold.houses : placeholderHouses, columns.sixHouse, true, ready);
    renderSteps(ready ? model.fourstep : placeholderPlanets, ready);
    renderNotationLegends();
      document.querySelectorAll('.kp-aspect-rule').forEach(element => {
      element.textContent = 'Vedic sign aspects · Conj: house cusps within ' + conjunctionOrb + '° · Rahu and Ketu are exactly 180° apart.';
    });
  };
  window.renderReportCover = function () {
    const page = document.createElement('div');
    page.className = 'report-page report-front-page';
    page.dataset.reportSection = 'cover';
    page.innerHTML = `
      <div class="report-front-surface">
        <header class="report-front-heading">
          <p class="report-front-kicker">कृष्णमूर्ती पद्धती · जन्मकुंडली अहवाल</p>
          <h1>श्री उच्छिष्ट महागणपती</h1>
          <p class="report-front-deity-name">Ucchishta Mahaganpati</p>
          <p class="report-front-document-title">Personal Astrology Report · वैयक्तिक ज्योतिष अहवाल</p>
        </header>
        <figure class="report-front-photo">
          <img class="report-cover-image" data-report-image="ganpati" alt="Ucchishta Mahaganpati — the supplied devotional photograph" hidden>
          <div class="report-cover-image-placeholder">Ucchishta Mahaganpati</div>
        </figure>
        <div class="report-front-details">
          <section class="report-front-panel report-front-native" aria-label="Native basic data">
            <h2>जातकाची माहिती <span>Native basic data</span></h2>
            <dl class="report-front-fields">
              <div class="report-front-field"><dt>नाव / Name</dt><dd data-cover-field="name"></dd></div>
              <div class="report-front-field"><dt>जन्मतारीख / Date</dt><dd data-cover-field="dob"></dd></div>
              <div class="report-front-field"><dt>जन्मवेळ / Time</dt><dd data-cover-field="birthTime"></dd></div>
              <div class="report-front-field"><dt>जन्मस्थळ / Place</dt><dd data-cover-field="birthPlace"></dd></div>
              <div class="report-front-field"><dt>अक्षांश / Latitude</dt><dd data-cover-field="lat"></dd></div>
              <div class="report-front-field"><dt>रेखांश / Longitude</dt><dd data-cover-field="lon"></dd></div>
            </dl>
          </section>
          <section class="report-front-panel report-front-astrologer" aria-label="Astrologer basic information">
            <h2>ज्योतिषीची माहिती <span>Astrologer basic information</span></h2>
            <dl class="report-front-fields">
              <div class="report-front-field"><dt>नाव / Name</dt><dd data-cover-field="astroName"></dd></div>
              <div class="report-front-field"><dt>मोबाईल / Mobile</dt><dd data-cover-field="astroMobile"></dd></div>
              <div class="report-front-field"><dt>पत्ता / Address</dt><dd data-cover-field="astroAddress"></dd></div>
            </dl>
          </section>
        </div>
        <footer class="report-front-footnote">Krishnamurti Paddhati · South Indian Kundali</footer>
      </div>`;
    page.querySelectorAll('[data-cover-field]').forEach(element => {
      const value = document.getElementById(element.dataset.coverField)?.value;
      const field=element.dataset.coverField;
      element.textContent = typeof value === 'string' && value.trim() ? window.KPPreferences?.isConfigured()&&field==='dob'?window.KPPreferences.formatDate(value):window.KPPreferences?.isConfigured()&&field==='birthTime'?window.KPPreferences.formatTime(value):value.trim() : '—';
    });
    page.querySelector('.report-front-footnote').textContent='Krishnamurti Paddhati · '+(window.KPChartStyle?.getStyle()==='north'?'North Indian Kundali':'South Indian Kundali');
    const source = window.KPReportPhoto?.get() || window.KP_REPORT_COVER_IMAGE;
    if (window.KPReportPhoto?.isValid(source) && source) {
      const image = page.querySelector('.report-cover-image');
      image.src = source;
      image.hidden = false;
      page.querySelector('.report-cover-image-placeholder').hidden = true;
    }
    return page;
  };
  function computedReportSnapshot(id) {
    if (id === 'transit-chart') return window.KPTransitChart?.snapshot() || '<p>Calculate the Transit Chart to include its current tables and charts.</p>';
    if (id === 'aspects') window.KPWesternAspects?.render();
    if (id === 'aspects' && window.KPAspectMatrix) { window.KPAspectMatrix.render(); return window.KPAspectMatrix.snapshot(); }
    if (id === 'transit') window.KPTransit?.refresh();
    const snapshot = document.createElement('div');
    snapshot.innerHTML = snapshotSection(id);
    const output = document.createElement('div');
    output.className = 'computed-report ' + id + '-report';
    const value = field => document.getElementById(field)?.value || '—';
    const choice = field => document.getElementById(field)?.selectedOptions[0]?.textContent || '—';
    function note(text, className = 'computed-report-summary') {
      const paragraph = document.createElement('p');
      paragraph.className = className;
      paragraph.textContent = text;
      output.append(paragraph);
    }
    function append(selector) {
      const content = snapshot.querySelector(selector);
      if (content) output.append(content);
    }
    note('Native: ' + value('name') + ' · Birth date: ' + value('dob'));
    if (id === 'aspects') {
      const angles = [...document.querySelectorAll('#aspects .western-angle-options input[type="checkbox"]:checked')].map(input => {
        const angle = input.id.replace('western-angle-', '');
        const label = input.labels[0];
        return (label.getAttribute('aria-label') || label.textContent.trim()) + ' (orb ' + value('western-orb-' + angle) + '°)';
      });
      note('Selected aspects: ' + (angles.join(' · ') || 'None'));
      append('.western-color-legend');
      append('[data-report-id="western-aspect-status"]');
      append('.western-results');
      append('.western-footnote');
    } else {
      note(choice('tr-mode') + ' · ' + document.getElementById('tr-period-summary').textContent);
      if (value('tr-mode') === 'event') {
        note(choice('tr-event') + ' · Houses: ' + value('tr-houses') + ' · ' + choice('tr-significator-method') + ' · ' + choice('tr-match'));
        const planets = [...document.querySelectorAll('#tr-planet-options input:checked')].map(input => input.value);
        note('Transiting planets: ' + (planets.join(', ') || 'None'));
        append('[data-report-id="tr-event-summary"]');
        append('[data-report-id="tr-significator-list"]');
      } else {
        note(choice('tr-dasha-source') + ' · ' + choice('tr-zone'));
        append('[data-report-id="tr-dasha-summary"]');
        if (value('tr-mode') === 'dasha') note(choice('tr-direction') + ' · ' + choice('tr-level'));
        append('[data-report-id="' + (value('tr-mode') === 'sun' ? 'tr-sun-note' : 'tr-mutual-note') + '"]');
      }
      append('[data-report-id="tr-status"]');
      append('.tr-result-mount');
      note('Exit times are exclusive. “Range limit” marks an interval clipped by the selected date range.', 'computed-report-footnote');
    }
    return output.outerHTML;
  }
  // Print each significator method on its own page. The basic calculations
  // stay directly below the kundali on the final page, as on screen.
  window.renderReport = function () {
    window.KPPreferences?.decorate(document);
    const pages = [
      ['1. मूलभूत माहिती', 'basic'], ['2. स्थळ रेखांश गणना', 'ayan'],
      ['3. स्थानिक जन्मवेळ (L.M.T.) गणना', 'lmt'], ['4. सांपत्तिक काळ गणना', 'stcalc'],
      ['5. रॅफेल टेबल ऑफ हाऊसेस', 'raphael5'], ['6. ग्रहस्थिती गणना', 'planet'],
      ['7. Mahadasha (MD)', 'mdcalc'], ['8. Antardasha (AD)', 'adcalc'],
      ['9. Four-fold significators', 'kp-fourfold'], ['10. Six-fold significators', 'kp-sixfold'],
      ['11. Four-step theory', 'kp-fourstep-section'],
      ['Prediction', 'prediction'], ['Dasha Fal', 'dasha-fal'],
      ['Gemstone guidance', 'gemstones'], ['Muhurta', 'muhurta'],
      ['13. Western Aspects', 'aspects'], ['14. Transit', 'transit'],
      ['15. Transit Chart', 'transit-chart'],
      ['16. Transit Panchang', 'transit-panchang'], ['17. Daily Ephemeris', 'ephemeris'],
      ['Education & Profession', 'education-profession'],
      ['Disease · Sixth Bhava', 'disease'],
      ['Dasha Promise', 'dasha-promise'],
      ['18. Event Promise', 'event-promise'],
      ['19. Nadi Astrology', 'nadi-astrology'],
      ['21. Matchmaking', 'matchmaking'],
      ['22. South Indian kundali and basic calculations', 'south9']
    ];
    const target = document.getElementById('printReport');
    if (!target) return;
    target.innerHTML = '';
    target.appendChild(window.renderReportCover());
    if(window.KPSinglePageReport?.render)target.appendChild(window.KPSinglePageReport.render());
    for (const [title, id] of pages) {
      if (!document.getElementById(id)) continue;
      const page = document.createElement('div');
      page.className = 'report-page' + (id === 'south9' ? ' kp-kundali-report' : '') + (['prediction', 'dasha-fal', 'gemstones', 'muhurta', 'time-slices', 'aspects', 'transit', 'transit-chart', 'transit-panchang', 'ephemeris', 'disease', 'education-profession', 'dasha-promise', 'event-promise', 'nadi-astrology', 'matchmaking'].includes(id) ? ' report-flow-page' : '');
      page.dataset.reportSection = id;
      const heading = document.createElement('div');
      heading.className = 'report-page-title';
      heading.textContent = title;
      const cover = document.createElement('div');
      cover.className = 'report-cover' + (id === 'adcalc' ? ' ad-sheet' : '');
      cover.innerHTML = id === 'prediction' ? (window.KPPersonalPredictions?.isActive() ? window.KPPersonalPredictions.snapshot() : window.KPPrediction?.snapshot() || '') : id === 'dasha-fal' ? (window.KPDashaFal?.snapshot() || '') : id === 'gemstones' ? (window.KPGemstones?.snapshot() || '') : id === 'muhurta' ? (window.KPMuhurta?.snapshot() || '') : id === 'time-slices' ? (window.KPTimeSlices?.snapshot() || '') : id === 'dasha-promise' ? (window.KPDashaPromise?.snapshot() || '') : id === 'disease' ? (window.KPDisease?.snapshot() || '') : id === 'education-profession' ? (window.KPEducationProfession?.snapshot() || '') : id === 'event-promise' ? (window.KPEventOutcome?.snapshot() || window.KPEventPromise?.snapshot() || '') : id === 'nadi-astrology' ? (window.KPNadiAstrology?.snapshot() || '') : id === 'matchmaking' ? (window.KPMatchmaking?.snapshot() || '') : id === 'transit-panchang' ? (window.KPTransitPanchang?.snapshot() || '') : id === 'ephemeris' ? (window.KPDailyEphemeris?.snapshot() || '') : ['aspects', 'transit', 'transit-chart'].includes(id) ? computedReportSnapshot(id) : snapshotSection(id);
      let southFollowup = null;
      if (id === 'south9') {
        cover.querySelectorAll('[data-kundali-alternate="true"]').forEach(chart => chart.remove());
        const styleName = window.KPChartStyle?.getStyle() === 'north' ? 'North Indian' : 'South Indian';
        heading.textContent = '22. ' + styleName + ' kundali';
        page.dataset.southPage = 'kundali';
        const calculations = cover.querySelector('[data-report-id="south-position-tables"],#south-position-tables,.south-calculations');
        if (calculations) {
          southFollowup = document.createElement('div');
          southFollowup.className = 'report-page kp-kundali-report kp-south-calculation-report';
          southFollowup.dataset.reportSection = 'south9';
          southFollowup.dataset.southPage = 'calculations';
          const secondHeading = document.createElement('div');secondHeading.className = 'report-page-title';secondHeading.textContent = '23. ' + styleName + ' kundali · calculation charts and significators';
          const secondCover = document.createElement('div');secondCover.className = 'report-cover';secondCover.append(calculations);
          southFollowup.append(secondHeading, secondCover);
        }
      }
      if (id === 'mdcalc') cover.querySelector('[data-report-id="adcalc"]')?.remove();
      const footer = document.createElement('div');
      footer.className = 'report-developer-footer';
      footer.textContent = 'Software developer Name: ' + (document.getElementById('astroName')?.value || 'Astro.Nitin Talegaonkar') + ' | Mob: ' + (document.getElementById('astroMobile')?.value || '8412098690');
      page.append(heading, cover, footer);
      target.appendChild(page);
      if (southFollowup) { const secondFooter=footer.cloneNode(true);southFollowup.append(secondFooter);target.appendChild(southFollowup); }
    }
  };
  document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('kp-conjunction-orb')?.addEventListener('input', window.updateKaryeshTables);
    setTimeout(window.updateKaryeshTables, 250);
  });
})();

