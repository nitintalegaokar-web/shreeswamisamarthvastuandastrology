
/* v15 FINAL TAB-6 FIXES
   - Birth time in Tab 6 always mirrors Basic Data birth time + AM/PM.
   - Row 6 (एकूण) = hours + minutes.
   - Row 8 (बेरीज) = जन्मवेळची स्थिती + एकूण.
   - Row 9 (वजा राशी अंश) = completed 30° rashi blocks from row 8.
   - Row 10 (पत्रिकेतील स्थिती) = row 8 minus row 9, normalized to 0°..30°.
   - Row 11 = current rashi name; for the opposite/next side the existing layout remains available.
   - Does not modify Tabs 1–5 calculations.
*/
(function(){
  const P6=9, FULL=1296000, R30=108000;
  const pad=n=>String(Math.abs(Math.trunc(n))).padStart(2,'0');
  function dms(v){
    if(v==null || String(v).trim()==='') return NaN;
    const a=String(v).trim().replace(/\s*R\s*$/i,'').split(':').map(Number);
    if(a.length<2 || a.some(x=>!Number.isFinite(x))) return NaN;
    return a[0]*3600+a[1]*60+(a[2]||0);
  }
  function fmtDms(s, allowNegative=false){
    if(!Number.isFinite(s)) return '';
    let neg=s<0; s=Math.abs(Math.round(s));
    if(!allowNegative) s=((s%FULL)+FULL)%FULL;
    const D=Math.floor(s/3600); s%=3600;
    const M=Math.floor(s/60), S=s%60;
    return (allowNegative&&neg?'-':'')+D+':'+pad(M)+':'+pad(S);
  }
  function fmtDaily(s){
    if(!Number.isFinite(s)) return '';
    const neg=s<0; s=Math.abs(Math.round(s));
    const H=Math.floor(s/3600); s%=3600;
    const M=Math.floor(s/60), S=s%60;
    return pad(H)+':'+pad(M)+':'+pad(S)+(neg?' R':'');
  }
  function syncBirthTimeDisplay(){
    const src=document.getElementById('birthTime');
    const out=document.getElementById('planet6BirthTime');
    const ap=document.getElementById('planet6BirthAmPm');
    if(!src||!out) return;
    const v=(src.value||'').trim();
    if(!v){out.value=''; if(ap) ap.value='AM'; return;}
    const a=v.split(':').map(Number);
    if(a.length<2 || !Number.isFinite(a[0])) return;
    const h24=a[0], m=a[1]||0, sec=a[2]||0;
    const ampm=h24>=12?'PM':'AM';
    let h12=h24%12; if(h12===0) h12=12;
    out.value=pad(h12)+':'+pad(m)+':'+pad(sec);
    if(ap) ap.value=ampm;
  }

  function syncDatesFromBasic(){
    if(document.getElementById('p6-ephemeris-source')?.value==='manual')return;
    const dob=document.getElementById('dob')?.value||'';
    const bt=document.getElementById('birthTime')?.value||'';
    const d1=document.getElementById('p6_date_1'), d2=document.getElementById('p6_date_2');
    if(!dob||!d1||!d2) return;
    const [Y,M,D]=dob.split('-').map(Number);
    if(!Y||!M||!D) return;
    const base=new Date(Y,M-1,D);
    const [h,mi,se]=(bt||'05:30:00').split(':').map(Number);
    const bsec=(h||0)*3600+(mi||0)*60+(se||0);
    const target=new Date(base);
    if(bsec<19800) target.setDate(target.getDate()-1); else target.setDate(target.getDate()+1);
    const iso=x=>x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+'-'+String(x.getDate()).padStart(2,'0');
    d1.value=dob; d2.value=iso(target);
    const t1=document.getElementById('p6_time_1'), t2=document.getElementById('p6_time_2');
    const a1=document.getElementById('p6_ampm_1'), a2=document.getElementById('p6_ampm_2');
    if(t1)t1.value='05:30:00'; if(t2)t2.value='05:30:00';
    if(a1)a1.value='AM'; if(a2)a2.value='AM';
  }

  function recalcRows(){
    syncBirthTimeDisplay();
    syncDatesFromBasic();
    for(let i=0;i<P6;i++){
      const a=dms(document.getElementById('p6_d_'+i)?.value);
      const b=dms(document.getElementById('p6_t_'+i)?.value);
      const motionOut=document.getElementById('p6_motion_'+i);
      if(motionOut){
        if(Number.isFinite(a)&&Number.isFinite(b)){
          // Keep the established Tab-6 rule: subtract the second entered position from the first.
          const diff=a-b;
          const isNode=(i===7||i===8);
          motionOut.value=isNode?fmtDaily(diff).replace(/\s*R$/,''):fmtDaily(diff);
        } else motionOut.value='';
      }

      const hs=dms(document.getElementById('p6_hours_'+i)?.value);
      const ms=dms(document.getElementById('p6_minutes_'+i)?.value);
      const total=(Number.isFinite(hs)&&Number.isFinite(ms))?hs+ms:NaN;
      const totalOut=document.getElementById('p6_total_'+i);
      if(totalOut) totalOut.value=Number.isFinite(total)?fmtDaily(total).replace(/\s*R$/,''):'';

      // Birth-time position: use the appropriate base 05:30 position and the daily motion,
      // with the 05:30-to-birth-time fraction. The daily motion displayed above is preserved.
      const birthTime=document.getElementById('birthTime')?.value||'05:30:00';
      const bs=secSafe(birthTime), before=bs<19800;
      const elapsed=before?(bs+86400-19800):(bs-19800);
      const fraction=Math.max(0,Math.min(1,elapsed/86400));
      const motion=(Number.isFinite(a)&&Number.isFinite(b))?(a-b):NaN;
      let birthPos=NaN;
      if(Number.isFinite(motion)){
        // For pre-05:30 births, the previous-day row is the starting position.
        // For 05:30+ births, the birth-date row is the starting position.
        const base=before?b:a;
        if(Number.isFinite(base)) birthPos=norm(base+motion*fraction);
      }
      const birthOut=document.getElementById('p6_birth_'+i);
      if(birthOut) birthOut.value=Number.isFinite(birthPos)?fmtDms(birthPos):'';

      // Row 8: जन्मवेळची स्थिती + एकूण.
      const sum=Number.isFinite(birthPos)&&Number.isFinite(total)?norm(birthPos+total):NaN;
      const sumOut=document.getElementById('p6_add_'+i);
      if(sumOut) sumOut.value=Number.isFinite(sum)?fmtDms(sum):'';

      // Row 9: completed 30° blocks; Row 10: remaining DMS inside that rashi.
      if(Number.isFinite(sum)){
        const idx=Math.floor(sum/R30);
        const subtract=idx*R30;
        const remaining=sum-subtract;
        const ay=document.getElementById('p6_ayan_'+i);
        const fin=document.getElementById('p6_final_'+i);
        const rn=document.getElementById('p6_rashi_'+i);
        if(ay) ay.value=fmtDms(subtract);
        if(fin) fin.value=fmtDms(remaining)+(Number.isFinite(motion)&&motion<0&&i<7?' R':'');
        if(rn) rn.value=rashi[idx%12]||'';
        const fe=document.getElementById('p6_final_'+i); if(fe) fe.dataset.rashi=rashi[idx%12]||'';
        window.lastPlanetPositions[planets[i]]=norm(sum-(dms(document.getElementById('ayanValue')?.value||'22:48:18')||0));
      }else{
        ['p6_ayan_'+i,'p6_final_'+i,'p6_rashi_'+i].forEach(id=>{const e=document.getElementById(id);if(e)e.value='';});
      }
    }
  }
  function secSafe(v){
    const a=String(v||'').split(':').map(Number); return (a[0]||0)*3600+(a[1]||0)*60+(a[2]||0);
  }
  function norm(s){return ((s%FULL)+FULL)%FULL;}

  window.syncPlanet6BirthTimeFromBasic=syncBirthTimeDisplay;
  window.syncPlanet6DatesFromBasic=syncDatesFromBasic;
  window.recalculatePlanet6Rows=recalcRows;

  document.addEventListener('DOMContentLoaded',()=>{
    syncBirthTimeDisplay(); syncDatesFromBasic();
    // Wire Basic Data -> Tab 6 directly, so the display never depends on tab switching.
    ['birthTime','dob'].forEach(id=>{
      const e=document.getElementById(id);
      if(e){
        e.addEventListener('input',()=>{syncBirthTimeDisplay();syncDatesFromBasic();setTimeout(recalcRows,0);});
        e.addEventListener('change',()=>{syncBirthTimeDisplay();syncDatesFromBasic();setTimeout(recalcRows,0);});
      }
    });
    for(let i=0;i<P6;i++){
      ['p6_d_'+i,'p6_t_'+i,'p6_hours_'+i,'p6_minutes_'+i].forEach(id=>{
        const e=document.getElementById(id); if(e){e.addEventListener('input',recalcRows);e.addEventListener('change',recalcRows);}
      });
    }
    setTimeout(recalcRows,100);
  });
})();

