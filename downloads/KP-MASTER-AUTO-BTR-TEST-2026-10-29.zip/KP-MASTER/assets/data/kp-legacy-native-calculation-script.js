
const planets=["रवी","चंद्र","मंगळ","बुध","गुरु","शुक्र","शनि","राहू","केतू"];
const rashi=["मेष","वृषभ","मिथुन","कर्क","सिंह","कन्या","तुळ","वृश्चिक","धनु","मकर","कुंभ","मीन"];
const defaultRaph=[
["1","मकर","14:14:44","14:10:51","296:37:00","295:39:00"],
["2","कुंभ","14:14:44","14:10:51","330:00:00","329:00:00"],
["3","मेष","14:14:44","14:10:51","364:00:00","363:00:00"],
["4","वृषभ","14:14:44","14:10:51","396:00:00","395:00:00"],
["5","मिथुन","14:14:44","14:10:51","424:00:00","423:00:00"],
["6","कर्क","14:14:44","14:10:51","450:00:00","449:00:00"],
["7","कर्क","14:14:44","14:10:51","476:00:00","475:00:00"],
["8","सिंह","14:14:44","14:10:51","510:00:00","509:00:00"],
["9","कन्या","14:14:44","14:10:51","540:00:00","539:00:00"],
["10","वृश्चिक","14:14:44","14:10:51","216:00:00","215:00:00"],
["11","धनु","14:14:44","14:10:51","244:00:00","243:00:00"],
["12","धनु","14:14:44","14:10:51","270:00:00","269:00:00"]
];
const sampleEph=[
["1931-10-09","195:14:00","166:18:00","225:08:00","188:25:00","137:13:00","203:35:00","286:54:00","364:42:00","4:42:00"],
["1931-10-10","196:13:00","181:22:00","225:50:00","190:11:00","137:22:00","204:50:00","286:56:00","364:39:00","4:39:00"],
["1931-10-11","197:12:00","196:26:00","226:32:00","191:57:00","137:31:00","206:05:00","286:58:00","364:36:00","4:36:00"]
];

function sec(t){let p=String(t).split(":").map(Number);return (p[0]||0)*3600+(p[1]||0)*60+(p[2]||0)}
function hms(s){s=Math.round(s);s=((s%86400)+86400)%86400;let h=Math.floor(s/3600);s%=3600;let m=Math.floor(s/60),x=s%60;return [h,m,x].map((v,i)=>String(v).padStart(2,"0")).join(":")}
function degsec(v){let s=sec(v); return s}
function dmsToDegSec(v){return sec(v)}
function normDegSec(s){let m=1296000;return ((s%m)+m)%m}
function addD(t,a){return hms(sec(t)+a)}
function fmtLong(s){s=normDegSec(s);let d=Math.floor(s/3600),m=Math.floor((s%3600)/60),x=s%60;return `${d}:${String(m).padStart(2,"0")}:${String(x).padStart(2,"0")}`}
function dateAdd(d,n){let x=new Date(d+"T00:00:00");x.setDate(x.getDate()+n);return x.toISOString().slice(0,10)}
function fmt(v){return v==null?"":v}

function init(){
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));document.getElementById(b.dataset.tab).classList.add("active");document.querySelectorAll("nav button").forEach(x=>x.classList.remove("active"));b.classList.add("active");if(b.dataset.tab==="karyesh"){ calculateAll(); updateKaryeshTables(); }});
// Later scripts provide the current worksheet calculators and chart renderer.
// Initialize only after those scripts have registered their input/date handlers.
document.addEventListener("DOMContentLoaded",()=>setTimeout(()=>{
  renderAyan();renderRaph();renderEph();calculateAll();
},0),{once:true});
}
function renderAyan(){const target=document.getElementById("ayanRows");if(target)target.innerHTML=`<tr><td>1931</td><td>22:48:18</td><td><button onclick="document.getElementById('ayanYear').value=1931;document.getElementById('ayanValue').value='22:48:18'">Use</button></td></tr>`}
function setAyan(){alert("Manual Ayanamsha applied: "+document.getElementById("ayanValue").value);calculateAll()}
function degreeRashiName(v){
  let d=((parseDmsAny(v)/3600)%360+360)%360;
  return rashi[Math.floor(d/30)];
}
function renderRaph(){
  const target=document.getElementById("raphRows");
  if(!target) return;
  target.innerHTML=defaultRaph.map((r,i)=>{
    let autoR=degreeRashiName(r[5] || r[4]);
    return `<tr>
      <td>${r[0]}</td>
      <td><select data-rr="${i}" style="min-width:110px">${rashi.map(x=>`<option ${x===autoR?"selected":""}>${x}</option>`).join("")}</select></td>
      <td><input value="${r[2]}" data-r="${i}" data-c="2" style="min-width:105px"></td>
      <td><input value="${r[3]}" data-r="${i}" data-c="3" style="min-width:105px"></td>
      <td><input value="${r[4]}" data-r="${i}" data-c="4" style="min-width:105px"></td>
      <td><input value="${r[5]}" data-r="${i}" data-c="5" style="min-width:105px"></td>
    </tr>`;
  }).join("");
  document.querySelectorAll("#raphRows input").forEach(inp=>{
    inp.addEventListener("input",()=>{
      const tr=inp.closest("tr"), inputs=[...tr.querySelectorAll("input")];
      const small=inputs.find(x=>x.dataset.c==="5")?.value||"";
      const sel=tr.querySelector("select");
      if(sel && small) sel.value=degreeRashiName(small);
    });
  });
}
function loadExampleRaph(){renderRaph();calculateAll()}
function renderEph(){const target=document.getElementById("ephRows");if(!target)return;target.replaceChildren();(window.savedEphemeris||sampleEph).forEach(row=>{const tr=document.createElement("tr");row.forEach((value,i)=>{const td=document.createElement("td"),input=document.createElement("input");input.value=value;input.dataset.e=i;input.style.minWidth="90px";td.appendChild(input);tr.appendChild(td)});target.appendChild(tr)})}
function addEphRow(){const target=document.getElementById("ephRows");if(!target)return;let tr=document.createElement("tr");for(let i=0;i<10;i++){let td=document.createElement("td"),inp=document.createElement("input");inp.value=i===0?document.getElementById("dob").value:"0:00:00";td.appendChild(inp);tr.appendChild(td)}target.appendChild(tr)}
function loadExampleEph(){renderEph();calculateAll()}

function readEph(){
const target=document.getElementById("ephRows");
return target?[...target.querySelectorAll("tr")].map(tr=>[...tr.querySelectorAll("input")].map(x=>x.value)).filter(r=>r.length===10):(window.savedEphemeris||sampleEph).map(row=>row.slice());
}
function findEph(date){return readEph().find(r=>r[0]===date)}
function planetBirthPositions(){
  const dob=document.getElementById("dob").value;
  const bt=document.getElementById("birthTime").value||"13:11:00";
  if(!dob) return null;
  const prev=dateAdd(dob,-1), next=dateAdd(dob,1);
  const birthSec=sec(bt), before0530=birthSec<19800;
  // Chronological daily motion is ALWAYS: next day's 05:30 position minus previous day's 05:30 position.
  // For a birth before 05:30, the adjacent pair is previous day -> birth day.
  // For a birth at/after 05:30, the adjacent pair is birth day -> next day.
  const prevDate=before0530?prev:dob;
  const nextDate=before0530?dob:next;
  const a=findEph(prevDate), b=findEph(nextDate);
  if(!a||!b)return null;
  const elapsed=before0530 ? (birthSec+86400-19800) : (birthSec-19800);
  const ratio=Math.max(0,Math.min(1,elapsed/86400));
  const vals={};
  for(let i=1;i<=9;i++){
    const prevPos=sec(a[i]), nextPos=sec(b[i]);
    const daily=normDegSec(nextPos-prevPos);
    vals[planets[i-1]]=normDegSec((before0530?prevPos:prevPos)+daily*ratio);
  }
  return {prevDate,nextDate,elapsed,vals};
}

function hmsToSeconds(v){
  if(!v) return 0;
  const p=v.split(":").map(Number);
  return (p[0]||0)*3600+(p[1]||0)*60+(p[2]||0);
}
function secondsToHMS(total){
  total=Math.round(total);
  total=((total%86400)+86400)%86400;
  const h=Math.floor(total/3600);
  const m=Math.floor((total%3600)/60);
  const sec=total%60;
  return String(h).padStart(2,"0")+":"+String(m).padStart(2,"0")+":"+String(sec).padStart(2,"0");
}

function dmsTextToSeconds(text){
  if(!text) return 0;
  const a=String(text).trim().split(":").map(Number);
  return (a[0]||0)*3600+(a[1]||0)*60+(a[2]||0);
}
function secondsToHMS(total){
  total=Math.round(total);
  total=((total%86400)+86400)%86400;
  const h=Math.floor(total/3600);
  const m=Math.floor((total%3600)/60);
  const ss=total%60;
  return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(ss).padStart(2,"0")}`;
}
function syncPlaceLongitudeFromBasic(){
  const basicLon=document.getElementById("lon");
  const placeLon=document.getElementById("placeStdLon");
  if(!basicLon || !placeLon) return;
  placeLon.value=(basicLon.value||"").trim();
}

function updateLongitudeDifference(){
  syncPlaceLongitudeFromBasic();
  const stdEl=document.getElementById("stdLon");
  const placeEl=document.getElementById("placeStdLon");
  const diffEl=document.getElementById("lonDifference");
  if(!stdEl||!placeEl||!diffEl) return;

  const std=dmsTextToSeconds(stdEl.value);
  const place=dmsTextToSeconds(placeEl.value);
  const diff=Math.abs(std-place);

  diffEl.value=secondsToHMS(diff);
}
function updateLMTCalculation(){
  syncPlaceLongitudeFromBasic();
  const stdEl=document.getElementById("stdLon");
  const placeEl=document.getElementById("placeStdLon");
  const degEl=document.getElementById("lmtDeg");
  const kalaEl=document.getElementById("lmtKala");
  const degMinEl=document.getElementById("lmtDegMin");
  const kalaSecEl=document.getElementById("lmtKalaSec");
  const secMinEl=document.getElementById("lmtSecToMin");
  const totalEl=document.getElementById("lmtTotalTime");
  const clockEl=document.getElementById("lmtClockTime");
  const signedEl=document.getElementById("lmtSignedDifference");
  const finalEl=document.getElementById("lmtFinal");
  if(!stdEl||!placeEl||!clockEl||!signedEl||!finalEl) return;

  // Tab 2 longitude difference, directly from the two editable longitudes.
  const std=dmsTextToSeconds(stdEl.value);
  const place=dmsTextToSeconds(placeEl.value);
  const angularDiff=Math.abs(std-place);

  // Convert longitude degrees/minutes/seconds to time:
  // degrees × 4 = minutes; minutes × 4 = seconds; seconds × 4 = fractional seconds.
  const deg=Math.floor(angularDiff/3600);
  const kala=Math.floor((angularDiff%3600)/60);
  const arcSec=Math.round(angularDiff%60);

  const degreeMinutes=deg*4;
  const kalaTimeSeconds=kala*4;
  const arcTimeSeconds=arcSec*4;

  const totalTimeSeconds=degreeMinutes*60+kalaTimeSeconds+arcTimeSeconds;
  const extraMin=Math.floor(kalaTimeSeconds/60);
  const extraSec=kalaTimeSeconds%60;

  if(degEl) degEl.value=deg;
  if(kalaEl) kalaEl.value=kala;
  if(degMinEl) degMinEl.value=degreeMinutes;
  if(kalaSecEl) kalaSecEl.value=kalaTimeSeconds;
  if(secMinEl) secMinEl.value=`${Math.floor((kalaTimeSeconds+arcTimeSeconds)/60)} मिनिटे ${((kalaTimeSeconds+arcTimeSeconds)%60)} सेकंद`;
  if(totalEl) totalEl.value=secondsToHMS(totalTimeSeconds);

  // Row 1: exactly the Basic Data birth time.
  const basicBirthTime=(document.getElementById("birthTime")?.value||"").trim();
  clockEl.value=basicBirthTime;

  // Row 2: exactly the total longitude time difference from Tab 2.
  const west=place<std;
  const signed=west ? -totalTimeSeconds : totalTimeSeconds;
  signedEl.value=(signed<0?"-":"")+secondsToHMS(Math.abs(signed));

  // Row 3: Row 1 minus/plus Row 2.
  if(!basicBirthTime){
    finalEl.value="";
    return;
  }
  const birthSec=dmsTextToSeconds(basicBirthTime);
  finalEl.value=secondsToHMS(birthSec+signed);
}

function updateTotalAyanamsha(){
  if(window.KPAnnualAyanamsha?.prepare())return;
  const dayEl=document.getElementById("dayAyan");
  const sumEl=document.getElementById("daySum");
  const totalEl=document.getElementById("ayanValue");
  if(!dayEl || !sumEl || !totalEl) return;

  const angle=text=>{
    if(!String(text).trim())return 0;
    const match=/^([+-]?)(\d+):([0-5]?\d):([0-5]?\d)$/.exec(String(text).trim());
    if(!match)return NaN;
    return (match[1]==='-'?-1:1)*(Number(match[2])*3600+Number(match[3])*60+Number(match[4]));
  };
  const day=angle(dayEl.value);
  const sum=angle(sumEl.value);
  const total=day+sum;
  if(!Number.isFinite(total)||total<0||total>=1296000){totalEl.value='';return;}
  // Ayanamsha is an angle. A clock formatter would wrap 24° back to 0°.
  const rounded=Math.round(Math.abs(total));
  totalEl.value=(total<0?'-':'')+String(Math.floor(rounded/3600)).padStart(2,'0')+':'+String(Math.floor(rounded%3600/60)).padStart(2,'0')+':'+String(rounded%60).padStart(2,'0');
}


function getLMTSiderealReference(){
  try{
    // Derive LMT from the native UTC instant, including timezone and DST.
    // Reading the last displayed LMT here could use the previous chart's value.
    const moment=KPHorary.nativeMoment(),local=new Date(moment.date.getTime()+moment.longitude*240000);
    const clock=local.getUTCHours()*3600+local.getUTCMinutes()*60+local.getUTCSeconds()+local.getUTCMilliseconds()/1000;
    const dayShift=Math.round((Date.parse(local.toISOString().slice(0,10)+'T00:00:00Z')-Date.parse(moment.localDate+'T00:00:00Z'))/86400000);
    const referenceShift=dayShift+(clock<19800?-1:0),date=new Date(local);
    if(clock<19800)date.setUTCDate(date.getUTCDate()-1);
    return {date:date.toISOString().slice(0,10),elapsed:clock<19800?clock+86400-19800:clock-19800,dayShift,referenceShift};
  }catch(_){return null;}
}

// Traditional KP 10/6 correction. The worksheet works at whole-second
// resolution: keep the minutes/6 half until one final half-up rounding.
function calculateTenSixCorrectionSeconds(elapsedSeconds){
  const sign=elapsedSeconds<0 ? -1 : 1;
  const elapsed=Math.round(Math.abs(elapsedSeconds));
  const fullHours=Math.floor(elapsed/3600);
  const remainingMinutes=Math.floor((elapsed%3600)/60);
  const quotient=Math.floor(remainingMinutes/6);
  const remainder=remainingMinutes%6;
  const correction=fullHours*10+quotient+(remainder>=3?1:0);
  return correction===0 ? 0 : sign*correction;
}

function updateSiderealTimeCalculation(){
  window.KPWorksheetEphemeris?.prepareSidereal();
  const baseEl=document.getElementById("baseSidereal0530");
  const lmtDiffEl=document.getElementById("stLmtDifference");
  const tenSixEl=document.getElementById("stTenSixCorrection");
  const totalEl=document.getElementById("stGrandTotal");
  const adjEl=document.getElementById("st24Adjustment");
  const finalEl=document.getElementById("birthPlaceSiderealTime");

  if(!baseEl||!lmtDiffEl||!tenSixEl||!totalEl||!adjEl||!finalEl) return;
  const correctionLabel=tenSixEl.closest('tr')?.firstElementChild;
  if(correctionLabel){if(!correctionLabel.dataset.manualLabel)correctionLabel.dataset.manualLabel=correctionLabel.innerHTML;
    if(correctionLabel.innerHTML!==correctionLabel.dataset.manualLabel)correctionLabel.innerHTML=correctionLabel.dataset.manualLabel;
  }


  if(document.getElementById('st-ephemeris-source')?.value==='automatic'){
    const result=window.KPWorksheetEphemeris?.siderealCalculation();
    const duration=n=>{const rounded=Math.round(Math.abs(n));return (n<0?'-':'')+String(Math.floor(rounded/3600)).padStart(2,'0')+':'+String(Math.floor(rounded%3600/60)).padStart(2,'0')+':'+String(rounded%60).padStart(2,'0');};
    if(!result){for(const field of [lmtDiffEl,tenSixEl,totalEl,adjEl,finalEl])field.value='';return;}
    lmtDiffEl.value=duration(result.elapsed);
    // Allocate the final rounding remainder to the correction, so the displayed
    // components add to the rounded total and normalization subtracts whole days.
    const grand=Math.round(result.total);
    tenSixEl.value=duration(grand-Math.round(result.base)-Math.round(result.elapsed));
    totalEl.value=duration(grand);
    const rounded=Math.round(result.seconds)%86400,adjustment=rounded-grand;
    adjEl.value=adjustment?duration(adjustment):'';
    finalEl.value=secondsToHMS(rounded);
    return;
  }

  // IMPORTANT: Tab 3 L.M.T. is the only source for this value.
  const lmtText=(document.getElementById("lmtFinal")?.value||"").trim();

  if(!lmtText || (document.getElementById('st-ephemeris-source')?.value==='automatic' && !baseEl.value.trim())){
    lmtDiffEl.value="";
    tenSixEl.value="";
    totalEl.value="";
    adjEl.value="";
    finalEl.value="";
    return;
  }

  // L.M.T. − 05:30:00
  const lmtSec=dmsTextToSeconds(lmtText);
  const fiveThirtySec=(5*3600)+(30*60);
  const reference=getLMTSiderealReference();
  const diffSec=reference?.elapsed ?? ((lmtSec-fiveThirtySec+86400)%86400);

  // Use positive elapsed time from the preceding 05:30 reference, preserving LMT date rollover.
  const diffSign=diffSec<0 ? "-" : "";
  lmtDiffEl.value=diffSign+secondsToHMS(Math.abs(diffSec));

  // One shared traditional 10/6 rule is used by manual and automatic ST.
  const signedCorrection=calculateTenSixCorrectionSeconds(diffSec);
  tenSixEl.value=(signedCorrection<0?"-":"")+secondsToHMS(Math.abs(signedCorrection));

  // First value + L.M.T. difference + 10/6 correction.
  const baseSec=dmsTextToSeconds(baseEl.value);
  let grandTotal=baseSec+diffSec+signedCorrection;
  totalEl.value=(grandTotal<0?"-":"")+String(Math.floor(Math.abs(grandTotal)/3600)).padStart(2,"0")+":"+String(Math.floor(Math.abs(grandTotal)%3600/60)).padStart(2,"0")+":"+String(Math.round(Math.abs(grandTotal))%60).padStart(2,"0");

  // If total is 24 hours or more, subtract 24 hours.
  let adjustment="";
  while(grandTotal>=86400){
    grandTotal-=86400;
    adjustment="- 24:00:00";
  }
  // Keep negative totals normalized to a clock value if needed.
  while(grandTotal<0){
    grandTotal+=86400;
    adjustment="+ 24:00:00";
  }

  adjEl.value=adjustment;
  finalEl.value=secondsToHMS(grandTotal);
}
function updateSampattikTimeDifferences(){
  const largeEl=document.getElementById("stLargeTime");
  const smallEl=document.getElementById("stSmallTime");
  const diff1El=document.getElementById("stDiff1");
  const diff1SecEl=document.getElementById("stDiffSeconds");

  const birthEl=document.getElementById("birthPlaceSiderealTime");
  const birthAgainEl=document.getElementById("stBirthTimeAgain");
  const smallAgainEl=document.getElementById("stSmallTimeAgain");
  const diff2El=document.getElementById("stDiff2");
  const diff2SecEl=document.getElementById("stDiff2Seconds");

  const large=(largeEl?.value||"").trim();
  const small=(smallEl?.value||"").trim();
  const birth=(birthEl?.value||"").trim();

  if(birthAgainEl) birthAgainEl.value=(document.getElementById("birthPlaceSiderealTime")?.value||"").trim();
  if(smallAgainEl) smallAgainEl.value=small;

  // फरक क्र. १ = मोठी सांपत्तिक वेळ − छोटी सांपत्तिक वेळ
  if(large && small){
    let diff=hmsToSeconds(large)-hmsToSeconds(small);
    if(diff<0) diff+=86400;
    if(diff1El) diff1El.value=secondsToHMS(diff);
    if(diff1SecEl) diff1SecEl.value=String(diff);
  }else{
    if(diff1El) diff1El.value="";
    if(diff1SecEl) diff1SecEl.value="";
  }

  // फरक क्र. २ = जन्मस्थळाची सांपत्तिक वेळ − छोटी सांपत्तिक वेळ
  if(birth && small){
    let diff=hmsToSeconds(birth)-hmsToSeconds(small);
    if(diff<0) diff+=86400;
    if(diff2El) diff2El.value=secondsToHMS(diff);
    if(diff2SecEl) diff2SecEl.value=String(diff);
  }else{
    if(diff2El) diff2El.value="";
    if(diff2SecEl) diff2SecEl.value="";
  }
}


function updateTab4SampattikKaal(){
  // Tab 4 uses the actual Tab 3 L.M.T. calculation and its own field IDs.
  // This wrapper keeps existing event hooks compatible.
  if (typeof updateSiderealTimeCalculation === "function") {
    updateSiderealTimeCalculation(); updateSampattikTimeDifferences();
  }
}

function formatSignedHMS(sec){
  const sign = sec < 0 ? "-" : "";
  return sign + secondsToHms(Math.abs(sec));
}



function updateRaphaelTable5(){const hs=[10,11,12,1,2,3];hs.forEach(h=>{const a=document.getElementById("r5_large_"+h),b=document.getElementById("r5_small_"+h),d=document.getElementById("r5_diff3_"+h),sp=document.getElementById("r5_small2_"+h),i=document.getElementById("r5_ishta_"+h),p=document.getElementById("r5_smallplus_"+h);if(d){if(a&&b&&a.value&&b.value){let x=parseTimeToSeconds(a.value)-parseTimeToSeconds(b.value);if(x<0)x+=86400;d.value=secondsToHMS(x)}else d.value=""}if(sp&&b)sp.value=b.value||"";if(p&&b&&i)p.value=secondsToHMS(parseTimeToSeconds(b.value||"00:00:00")+parseTimeToSeconds(i.value||"00:00:00"))});}

const mdNakshatras=[
  ["अश्विनी","केतू",7],["भरणी","शुक्र",20],["कृत्तिका","रवी",6],
  ["रोहिणी","चंद्र",10],["मृगशीर्ष","मंगळ",7],["आर्द्रा","राहू",18],
  ["पुनर्वसू","गुरु",16],["पुष्य","शनि",19],["आश्लेषा","बुध",17],
  ["मघा","केतू",7],["पूर्वाफाल्गुनी","शुक्र",20],["उत्तराफाल्गुनी","रवी",6],
  ["हस्त","चंद्र",10],["चित्रा","मंगळ",7],["स्वाती","राहू",18],
  ["विशाखा","गुरु",16],["अनुराधा","शनि",19],["ज्येष्ठा","बुध",17],
  ["मूळ","केतू",7],["पूर्वाषाढा","शुक्र",20],["उत्तराषाढा","रवी",6],
  ["श्रवण","चंद्र",10],["धनिष्ठा","मंगळ",7],["शततारका","राहू",18],
  ["पूर्वाभाद्रपदा","गुरु",16],["उत्तराभाद्रपदा","शनि",19],["रेवती","बुध",17]
];
const mdLordYears={"केतू":7,"शुक्र":20,"रवी":6,"चंद्र":10,"मंगळ":7,"राहू":18,"गुरु":16,"शनि":19,"बुध":17};
const mdSeq=["केतू","शुक्र","रवी","चंद्र","मंगळ","राहू","गुरु","शनि","बुध"];
const mdNextLord={};
mdSeq.forEach((x,i)=>mdNextLord[x]=mdSeq[(i+1)%9]);

function mdFormatDuration(totalDays){
  let years=Math.floor(totalDays/365);
  let rem=totalDays-years*365;
  let months=Math.floor(rem/30);
  let days=rem-months*30;
  if(days>=15){months++;days=0}
  if(months>=12){years++;months-=12}
  return {years,months,days};
}
function mdAddYMD(dateStr,years,months,days){
  if(!mdValidDate(dateStr)) return "";
  const d=new Date(dateStr+"T00:00:00Z");
  const originalDay=d.getUTCDate();
  d.setUTCDate(1);
  d.setUTCFullYear(d.getUTCFullYear()+years);
  d.setUTCMonth(d.getUTCMonth()+months);
  const lastDay=new Date(d.getTime());
  lastDay.setUTCMonth(lastDay.getUTCMonth()+1,0);
  d.setUTCDate(Math.min(originalDay,lastDay.getUTCDate()));
  d.setUTCDate(d.getUTCDate()+days);
  if(!Number.isFinite(d.getTime()) || d.getUTCFullYear()<1 || d.getUTCFullYear()>9999) return "";
  return d.toISOString().slice(0,10);
}
function mdValidDate(dateStr){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(String(dateStr||""))) return false;
  const d=new Date(dateStr+"T00:00:00Z");
  return Number.isFinite(d.getTime()) && d.getUTCFullYear()>0 && d.toISOString().slice(0,10)===dateStr;
}
function mdDuration360(totalDays){
  const days=Math.max(0,Math.round(totalDays));
  return {years:Math.floor(days/360),months:Math.floor((days%360)/30),days:days%30};
}
function mdAddOffset(dateStr,totalDays){
  const sign=totalDays<0?-1:1;
  const duration=mdDuration360(Math.abs(totalDays));
  return mdAddYMD(dateStr,sign*duration.years,sign*duration.months,sign*duration.days);
}
function mdFmtDate(v){
  if(window.KPPreferences?.isConfigured())return window.KPPreferences.formatDate(v);
  if(!v) return "";
  const a=v.split("-");
  return a.length===3?`${a[2]}/${a[1]}/${a[0]}`:v;
}
function mdFindPeriodAtDate(periods,reference){
  if(!mdValidDate(reference)) return undefined;
  // A date-only reference on DOB denotes the birth moment. Keep the actual
  // birth lord even when its small remaining balance displays as zero days.
  if(reference===document.getElementById("dob")?.value){
    const birth=periods.find(period=>period.isBirth||period.birthActive);
    if(birth) return birth;
  }
  return periods.find(period=>period.start<=reference&&reference<period.end);
}

// Worksheet durations use 12 months of 30 days. Calendar boundaries are
// cumulative offsets from the MD start, or from birth for the partly elapsed MD.
// Anchoring the birth MD at DOB retains its elapsed ADs and its exact MD balance.
window.mdDashaPeriods=[];
function calculateAntardashas(period){
  if(!period || !mdLordYears[period.lord] || !mdValidDate(period.start) || !mdValidDate(period.end)) return [];
  const mdYears=mdLordYears[period.lord];
  const totalDays=mdYears*360;
  const elapsedDays=period.isBirth?Math.max(0,Math.min(totalDays,period.birthElapsedDays||0)):0;
  const anchor=period.start;
  let cumulativeDays=0;
  const first=mdSeq.indexOf(period.lord);
  const periods=[];
  for(let i=0;i<9;i++){
    const lord=mdSeq[(first+i)%9];
    const durationDays=mdYears*mdLordYears[lord]*3;
    const duration=mdDuration360(durationDays);
    const start=mdAddOffset(anchor,cumulativeDays-elapsedDays);
    cumulativeDays+=durationDays;
    const end=i===8?period.end:mdAddOffset(anchor,cumulativeDays-elapsedDays);
    // A final fraction of a day can round the MD balance to zero. The natal
    // Moon still belongs to this MD, so its final AD remains the birth AD.
    const activeElapsed=Math.min(elapsedDays,totalDays-1e-7);
    const birthActive=Boolean(period.isBirth && activeElapsed>=cumulativeDays-durationDays && activeElapsed<cumulativeDays);
    periods.push({lord,mdLord:period.lord,...duration,durationDays,start,end,birthActive,
      birthBalanceDays:birthActive?Math.max(0,cumulativeDays-elapsedDays):0});
  }
  return periods;
}
window.calculateAntardashas=calculateAntardashas;
let pendingAntardashaSelection=null;
window.requestAntardashaSelection=key=>{pendingAntardashaSelection=String(key||"");};

function updateAntardashaCalculation(message){
  const select=document.getElementById("adMDSelect");
  const body=document.getElementById("adDashaRows");
  const status=document.getElementById("ad-status");
  const set=(id,value)=>{const el=document.getElementById(id);if(el)el.value=value;};
  if(!select || !body || !status) return;
  const periods=window.mdDashaPeriods;
  if(!periods.length){
    select.disabled=true;
    select.innerHTML='<option value="">Complete the Moon position and birth date</option>';
    body.innerHTML='<tr><td colspan="6">डेटा अपूर्ण / Data incomplete</td></tr>';
    ["adMDRange","adBirthLord","adBirthBalance"].forEach(id=>set(id,""));
    status.dataset.ready="false";
    status.textContent=message||"Complete the calculated Moon position in Tab 6 and the birth date to calculate Antardasha.";
    return;
  }
  const previous=pendingAntardashaSelection??select.value;
  pendingAntardashaSelection=null;
  select.replaceChildren(...periods.map((period,index)=>{
    const option=document.createElement("option");
    option.value=period.key;
    option.textContent=`${period.lord} · ${mdFmtDate(period.start)} – ${mdFmtDate(period.end)}${index===0?" · जन्मतः / At birth":""}`;
    return option;
  }));
  if(periods.some(period=>period.key===previous)) select.value=previous;
  select.disabled=false;
  const selected=periods.find(period=>period.key===select.value)||periods[0];
  const adPeriods=calculateAntardashas(selected);
  const birthPeriod=calculateAntardashas(periods[0]).find(period=>period.birthActive);
  set("adMDRange",`${selected.lord} · ${mdFmtDate(adPeriods[0]?.start)} – ${mdFmtDate(selected.end)}`);
  set("adBirthLord",birthPeriod?.lord||"");
  const balance=mdDuration360(birthPeriod?.birthBalanceDays||0);
  set("adBirthBalance",`${balance.years} वर्ष ${balance.months} महिने ${balance.days} दिवस`);
  body.innerHTML=adPeriods.map(period=>`<tr data-ad-lord="${period.lord}" data-birth-active="${period.birthActive}" data-period-start="${period.start}" data-period-end="${period.end}"><td>${period.lord}${period.birthActive?'<span class="ad-birth-marker">जन्मतः / At birth</span>':""}</td><td>${period.years}</td><td>${period.months}</td><td>${period.days}</td><td>${mdFmtDate(period.start)}</td><td>${mdFmtDate(period.end)}</td></tr>`).join("");
  status.dataset.ready="true";
  status.textContent=selected.isBirth
    ? `${selected.lord} MD: all nine AD periods are shown, including those before birth. The AD at birth is highlighted.`
    : `${selected.lord} MD: all nine AD periods are shown in Vimshottari order. The birth AD and its balance are shown above.`;
}
document.addEventListener("change",event=>{
  if(event.target?.id!=="adMDSelect") return;
  updateAntardashaCalculation();
  if(typeof renderReport==="function") renderReport();
});

function updateMDCalculation(){
  const moonEl=document.getElementById("p6_final_1");
  // Tab 6 stores the sign and the degree within that sign separately.
  // Rebuild the absolute sidereal longitude from the current worksheet,
  // rather than a chart cache that may belong to an earlier calculation.
  const moonText=(moonEl?.value||"").trim().replace(/\s+R$/i,"");
  const moonSign=(document.getElementById("p6_rashi_1")?.value||"").trim().replace(/^तुला$/,"तुळ");
  const moonSignIndex=rashi.indexOf(moonSign);
  const moonParts=moonText.split(":").map(Number);
  const validMoon=/^\d+(?:\.\d+)?(?::\d+(?:\.\d+)?){0,2}$/.test(moonText)
    && moonSignIndex>=0 && moonParts.every(Number.isFinite) && moonParts[0]<30
    && moonParts.slice(1).every(part=>part>=0 && part<60)
    && parseDmsAny(moonText)<108000;
  window.mdDashaPeriods=[];
  if(!validMoon){
    document.querySelectorAll("#mdcalc input[readonly]").forEach(el=>el.value=el.id==="mdFormulaDenominator"?"800":"");
    const body=document.getElementById("mdDashaRows");
    if(body)body.innerHTML='<tr><td colspan="6">डेटा अपूर्ण / Data incomplete</td></tr>';
    updateAntardashaCalculation();
    return;
  }
  const moonSec=moonSignIndex*108000+parseDmsAny(moonText);
  const nakIndex=Math.min(26,Math.floor(moonSec/48000));
  const withinArc=moonSec-nakIndex*48000;
  const remainingArc=48000-withinArc;
  const withinDeg=withinArc/3600;
  const remainDeg=remainingArc/3600;
  const remainKala=remainingArc/60;
  const n=mdNakshatras[nakIndex];
  const rashiName=rashi[moonSignIndex];
  const lord=n[1], mdYears=n[2];

  const set=(id,v)=>{const e=document.getElementById(id);if(e)e.value=v==null?"":v};
  set("mdMoonInfo",`${rashiName} — ${n[0]} — ${lord}`);
  set("mdMoonPosition",moonText);
  set("mdSubtraction",degToDms(Math.round(withinDeg*3600)));
  set("mdNakshatraArc",degToDms(Math.round(remainDeg*3600)));
  set("mdRemaining",degToDms(Math.round(remainDeg*3600)));

  const wholeDeg=Math.floor(remainDeg);
  const remMin=(remainDeg-wholeDeg)*60;
  const arcMinutes=wholeDeg*60;
  const extraKala=remMin;
  set("mdArcMinutes",String(arcMinutes));
  const formatKala=value=>value.toFixed(8).replace(/\.?0+$/,"");
  set("mdArcRemainder",formatKala(arcMinutes + extraKala));

  const totalKala=remainKala;
  // Exact worksheet sequence: years first -> use ONLY year decimal for months ->
  // use ONLY month decimal for days. The denominator is the full Nakshatra = 800 kala.
  const yearFraction=remainingArc*mdYears/48000;
  const remainingDays=remainingArc*mdYears*360/48000;
  const yearsWhole=Math.floor(yearFraction+1e-10);
  const yearDecimalRemainder=Math.max(0,yearFraction-yearsWhole);
  const monthFraction=yearDecimalRemainder*12;
  let monthsWhole=Math.floor(monthFraction+1e-10);
  const monthDecimalRemainder=Math.max(0,monthFraction-monthsWhole);
  const dayFraction=monthDecimalRemainder*30;
  // Round only the displayed duration. AD/PD selection must retain the
  // Moon's exact elapsed fraction, including just before a lord boundary.
  const duration=mdDuration360(remainingDays);
  const finalYears=duration.years,finalMonths=duration.months,daysWhole=duration.days;

  set("mdFormulaKala",formatKala(totalKala));
  set("mdFormulaYears",mdYears);
  set("mdFormulaDenominator",800);
  set("mdFormulaYearResult",yearFraction.toFixed(4));
  set("mdYearWhole",finalYears);
  set("mdMonthCalc",`${yearDecimalRemainder.toFixed(4)} × 12 = ${monthFraction.toFixed(4)} → ${finalMonths} महिने`);
  set("mdDayCalc",`${monthDecimalRemainder.toFixed(4)} × 30 = ${dayFraction.toFixed(4)} → ${daysWhole} दिवस`);

  set("mdBirthDasha",lord);
  set("mdBhogyaDuration",`${finalYears} वर्ष ${finalMonths} महिने ${daysWhole} दिवस`);
  const dob=document.getElementById("dob")?.value||"";
  set("mdBirthDate",mdFmtDate(dob));
  if(!mdValidDate(dob)){
    set("mdDashaEnd","");
    const body=document.getElementById("mdDashaRows");
    if(body)body.innerHTML='<tr><td colspan="6">जन्मतारीख आवश्यक / Birth date required</td></tr>';
    updateAntardashaCalculation("Enter a valid birth date to calculate the MD and AD dates.");
    return;
  }
  set("mdDashaEnd",mdFmtDate(mdAddYMD(dob,finalYears,finalMonths,daysWhole)));

  const rows=[];
  let curLord=lord;
  let startDate=dob;
  // First row is the birth-time remaining MD.
  rows.push({key:`0:${curLord}`,lord:curLord,years:mdYears,y:finalYears,m:finalMonths,d:daysWhole,start:startDate,
    end:mdAddYMD(startDate,finalYears,finalMonths,daysWhole),isBirth:true,birthRemainingDays:remainingDays,
    birthElapsedDays:withinArc*mdYears*360/48000,
    fullStart:mdAddOffset(dob,remainingDays-mdYears*360)});
  let currentDate=mdAddYMD(startDate,finalYears,finalMonths,daysWhole);
  // Then show the following complete Mahadashas; one Vimshottari cycle contains 9 planets (120 years total).
  for(let i=1;i<9;i++){
    curLord=mdNextLord[curLord];
    const yy=mdLordYears[curLord];
    const end=mdAddYMD(currentDate,yy,0,0);
    rows.push({key:`${i}:${curLord}`,lord:curLord,years:yy,y:yy,m:0,d:0,start:currentDate,end,isBirth:false,fullStart:currentDate});
    currentDate=end;
  }
  const body=document.getElementById("mdDashaRows");
  if(body) body.innerHTML=rows.map(x=>`<tr><td>${x.lord}</td><td>${x.y}</td><td>${x.m}</td><td>${x.d}</td><td>${mdFmtDate(x.start)}</td><td>${mdFmtDate(x.end)}</td></tr>`).join("");
  window.mdDashaPeriods=rows;
  updateAntardashaCalculation();
}


/* -------------------- TAB 8 : कार्येश calculation --------------------
   Uses the already-calculated KP nirayan planet positions and KP MASTER
   nirayan cusps.  Tab 7 (MD) is not modified by this routine.

   KP sub-lord calculation:
   - 27 nakshatras, each 13°20′.
   - Sub divisions are proportional to Vimshottari MD years / 120.
   - The first sub in a star is the star lord itself, then the Vimshottari
     sequence continues cyclically.

   For a planet, its core significator houses are the houses it occupies and
   owns, plus the houses occupied/owned by its star lord (KP star-lord level).
   The four tables are then generated as direct/inverse views of those
   significators, including cusp/planet sub-lord rows.
*/
const KP_NAK_LORDS=["केतू","शुक्र","रवी","चंद्र","मंगळ","राहू","गुरु","शनि","बुध"];
const KP_VIM_ORDER=["केतू","शुक्र","रवी","चंद्र","मंगळ","राहू","गुरु","शनि","बुध"];
const KP_YEARS={"केतू":7,"शुक्र":20,"रवी":6,"चंद्र":10,"मंगळ":7,"राहू":18,"गुरु":16,"शनि":19,"बुध":17};
const KP_SIGN_LORD={
  "मेष":"मंगळ","वृषभ":"शुक्र","मिथुन":"बुध","कर्क":"चंद्र",
  "सिंह":"रवी","कन्या":"बुध","तुळ":"शुक्र","वृश्चिक":"मंगळ",
  "धनु":"गुरु","मकर":"शनि","कुंभ":"शनि","मीन":"गुरु"
};
const KP_PLANET_CANON={"रवी":"रवी","चंद्र":"चंद्र","मंगळ":"मंगळ","बुध":"बुध","गुरु":"गुरु","शुक्र":"शुक्र","शनि":"शनि","राहू":"राहू","राहु":"राहू","केतू":"केतू","केतु":"केतू"};

function kpCanonicalPlanet(x){ return KP_PLANET_CANON[String(x||"").trim()] || String(x||"").trim(); }
function kpHouseArcContains(cusps, h, lon){
  const a=normDegSec(cusps[h-1]);
  const b=normDegSec(cusps[h%12]);
  const x=normDegSec(lon);
  const span=normDegSec(b-a);
  const rel=normDegSec(x-a);
  return rel < span || (span===0 && rel===0);
}
function kpPlanetHouse(cusps, lon){
  for(let h=1;h<=12;h++) if(kpHouseArcContains(cusps,h,lon)) return h;
  return 12;
}
function kpSignIndex(lon){ return Math.floor(normDegSec(lon)/108000); }
function kpSignLordByLon(lon){ return KP_SIGN_LORD[rashi[kpSignIndex(lon)]] || ""; }
function kpStarLord(lon){
  const x=normDegSec(lon);
  const nak=Math.min(26,Math.floor(x/48000)); // 13°20′ = 48,000″
  return KP_NAK_LORDS[nak%9];
}
function kpSublord(lon){
  const x=normDegSec(lon);
  const nak=Math.min(26,Math.floor(x/48000));
  const within=x-nak*48000;
  const starLord=KP_NAK_LORDS[nak%9];
  let acc=0;
  const start=KP_VIM_ORDER.indexOf(starLord);
  for(let j=0;j<9;j++){
    const lord=KP_VIM_ORDER[(start+j)%9];
    const span=48000*KP_YEARS[lord]/120;
    if(within < acc+span || j===8) return lord;
    acc+=span;
  }
  return starLord;
}
function kpFmtHouses(set){ return [...set].sort((a,b)=>a-b).join(", "); }
function kpHouseData(){
  // Read the already-calculated KP Nirayan cusps and planetary positions.
  // Do not recalculate or alter Tabs 1-7 here.
  const rawCusps=Array.isArray(window.cuspResults)?window.cuspResults:[];
  const cusps=rawCusps.map(x=>Number(x?.nir));
  if(cusps.length!==12 || cusps.some(x=>!Number.isFinite(x))) return null;

  const planetsData={};
  const rawPlanets=window.lastPlanetPositions||{};
  planets.forEach(name=>{
    const lon=Number(rawPlanets[name]);
    if(!Number.isFinite(lon)) return;
    const n=kpCanonicalPlanet(name);
    planetsData[n]={
      lon:normDegSec(lon),
      house:kpPlanetHouse(cusps,normDegSec(lon)),
      signLord:kpSignLordByLon(lon),
      starLord:kpStarLord(lon),
      sublord:kpSublord(lon)
    };
  });
  if(Object.keys(planetsData).length===0) return null;

  const houses={};
  for(let h=1;h<=12;h++){
    const cusp=normDegSec(cusps[h-1]);
    const sign=rashi[kpSignIndex(cusp)];
    houses[h]={
      cusp,
      sign,
      owner:KP_SIGN_LORD[sign]||"",
      starLord:kpStarLord(cusp),
      sublord:kpSublord(cusp),
      occupants:[]
    };
  }
  Object.entries(planetsData).forEach(([p,d])=>{
    if(houses[d.house]) houses[d.house].occupants.push(p);
  });

  // House ownership. Rahu/Ketu do not own a sign; their sign lord is used
  // when their significators are expanded, as per the KP convention used here.
  const owned={};
  planets.forEach(p=>owned[kpCanonicalPlanet(p)]=[]);
  for(let h=1;h<=12;h++){
    const owner=kpCanonicalPlanet(houses[h].owner);
    if(owner && owned[owner]) owned[owner].push(h);
  }

  // KP कार्येश (significator) set for each planet:
  // 1) houses occupied by the planet's star lord
  // 2) houses owned by the planet's star lord
  // 3) house occupied by the planet
  // 4) houses owned by the planet
  // Rahu/Ketu additionally represent the houses of their sign lord.
  const sig={};
  Object.entries(planetsData).forEach(([p,d])=>{
    const out=new Set();
    const star=kpCanonicalPlanet(d.starLord);

    Object.entries(houses).forEach(([hs,hd])=>{
      const h=Number(hs);
      if(star && hd.occupants.includes(star)) out.add(h);
    });
    if(star && owned[star]) owned[star].forEach(h=>out.add(h));

    if(d.house) out.add(d.house);
    if(owned[p]) owned[p].forEach(h=>out.add(h));

    if(p==='राहू' || p==='केतू'){
      const signLord=kpCanonicalPlanet(d.signLord);
      Object.entries(houses).forEach(([hs,hd])=>{
        const h=Number(hs);
        if(signLord && hd.occupants.includes(signLord)) out.add(h);
      });
      if(signLord && owned[signLord]) owned[signLord].forEach(h=>out.add(h));
    }
    sig[p]=out;
  });

  const houseSig={};
  for(let h=1;h<=12;h++){
    houseSig[h]=Object.entries(sig)
      .filter(([,set])=>set.has(h))
      .map(([p])=>p);
  }

  const subHouseSig={};
  for(let h=1;h<=12;h++){
    const sl=kpCanonicalPlanet(houses[h].sublord);
    subHouseSig[h]=(sl && sig[sl]) ? [...sig[sl]] : [];
  }

  const subPlanetSig={};
  Object.entries(planetsData).forEach(([p,d])=>{
    const sl=kpCanonicalPlanet(d.sublord);
    subPlanetSig[p]=(sl && sig[sl]) ? [...sig[sl]] : [];
  });

  return {cusps,planetsData,houses,owned,sig,houseSig,subHouseSig,subPlanetSig};
}

function updateKaryeshTables(){
  const data=kpHouseData();
  const ids=[];
  for(let h=1;h<=12;h++) ids.push([`karyesh_bhava_graha_${h}`,data?kpFmtHouses(data.houseSig[h]):""]);
  const gp=["रवी","चंद्र","मंगळ","राहू","गुरु","शनि","बुध","केतू","शुक्र"];
  gp.forEach((p,i)=>ids.push([`karyesh_graha_bhava_${i+1}`,data&&data.sig[p]?kpFmtHouses(data.sig[p]):""]));
  for(let h=1;h<=12;h++) ids.push([`karyesh_sublord_bhava_${h}`,data?kpFmtHouses(data.subHouseSig[h]):""]);
  gp.forEach((p,i)=>ids.push([`karyesh_sublord_graha_${i+1}`,data&&data.subPlanetSig[p]?kpFmtHouses(data.subPlanetSig[p]):""]));
  ids.forEach(([id,v])=>{const e=document.getElementById(id);if(e)e.value=(v||"डेटा उपलब्ध नाही")});

  const box=document.querySelector('#karyesh .karyesh-page');
  if(box){
    let note=box.querySelector('.karyesh-note');
    if(!note){ note=document.createElement('div'); note.className='karyesh-note'; box.insertBefore(note,box.querySelector('.karyesh-grid')); }
    note.innerHTML=data
      ? '<b>Automatic KP कार्येश गणना:</b> रॅफेलमधील निरयन १२ भाव, ग्रहस्थिती, ग्रहांचे नक्षत्रस्वामी व उपनक्षत्रस्वामी यांवरून कार्येश भाव automatic भरले आहेत. Tab 7 महादशा गणना लॉक आहे.'
      : '<b>टीप:</b> Tab 5/6 मधील निरयन भाव व ग्रहस्थिती उपलब्ध झाल्यावर कार्येश गणना automatic भरेल.';
  }
}

function calculateAll(){
  syncPlaceLongitudeFromBasic();
  updateTotalAyanamsha();
  updateLongitudeDifference();
  updateLMTCalculation();
  window.KPWorksheetEphemeris?.prepare();
  updateTab4SampattikKaal(); updateSampattikTimeDifferences();
  updateRaphaelTable5();

  let std=sec(document.getElementById("stdLon").value), lon=sec(document.getElementById("lon").value);
  let diff=std-lon;
  let bt=document.getElementById("birthTime").value||"13:11:00";
  let ay=sec(document.getElementById("ayanValue").value||"22:48:18");
  const basicSummary=document.getElementById("basicSummary");
  if(basicSummary) basicSummary.innerHTML=`<table><tr><th>मूल्य</th><th>Result</th></tr><tr><td>L.M.T.</td><td>${document.getElementById("lmtFinal")?.value||""}</td></tr><tr><td>Longitude Difference</td><td>${document.getElementById("lonDifference")?.value||""}</td></tr><tr><td>KP Ayanamsha</td><td>${fmtLong(ay)}</td></tr></table>`;
  const timeCalc=document.getElementById("timeCalc");
  if(timeCalc) timeCalc.innerHTML=`<div class="formula">भारत प्रमाण रेखांश = ${document.getElementById("stdLon").value}
जन्मस्थळ रेखांश = ${document.getElementById("placeStdLon").value}
फरक = ${fmtLong(Math.abs(diff))}
जन्मवेळ = ${bt}
L.M.T. = ${document.getElementById("lmtFinal")?.value||""}</div>`;
  window.manualBirthST = document.getElementById("birthST")?.value || "14:13:49";
  const stCalc=document.getElementById("stCalc");
  if(stCalc) stCalc.innerHTML=`<div class="formula">जन्मस्थळाचा अंतिम Sidereal Time = ${window.manualBirthST||"14:13:49"}
Ephemeris ST / Raphael ST values येथे तुमच्या manual data मधून घेतले जातील.
KP Ayanamsha = ${fmtLong(ay)}</div>`;
  renderPlanets(null,ay);renderRaphCalc();renderCusps(ay);updateMDCalculation();updateKaryeshTables();renderChart();renderReport();
}

function signedMotionSeconds(a,b){
  let d=parseDmsAny(b)-parseDmsAny(a);
  const full=1296000, half=648000;
  if(d>half) d-=full;
  if(d<-half) d+=full;
  return d;
}
function signedDms(s){
  const sign=s<0?"-":"";
  s=Math.abs(Math.round(s));
  let d=Math.floor(s/3600),m=Math.floor((s%3600)/60),x=s%60;
  return `${sign}${d}:${String(m).padStart(2,"0")}:${String(x).padStart(2,"0")}`;
}
function renderPlanets(p,ay){
  // The latest worksheet calculator is authoritative. Older renderers below
  // were written for tables that this version no longer contains.
  if(typeof window.calculateTab6SunMethod==="function"){
    window.calculateTab6SunMethod();
    if(typeof window.copyExactBirthDatePosition==="function") window.copyExactBirthDatePosition();
    window.lastPlanetPositions={};
    planets.forEach((name,i)=>{
      const final=(document.getElementById(`p6_final_${i}`)?.value||"").replace(/\s*R\s*$/i,"").trim();
      const sign=(document.getElementById(`p6_rashi_${i}`)?.value||"").trim();
      const index=rashi.findIndex(value=>value===sign || (value==="तुळ"&&sign==="तुला"));
      if(final && index>=0) window.lastPlanetPositions[name]=normDegSec(index*108000+parseDmsAny(final));
    });
    return;
  }
  const set=(id,v)=>{const e=document.getElementById(id);if(e)e.value=(v==null?"":v)};
  const get=id=>(document.getElementById(id)?.value||"").trim();
  const birthDate=get("dob");
  const birthTime24=get("birthTime") || "13:11:00";
  const [bh,bm,bs]=(birthTime24+":00").split(":").map(Number);
  const birthAmPm=(bh>=12)?"PM":"AM";
  let h12=bh%12; if(h12===0) h12=12;
  const birthTime12=`${String(h12).padStart(2,'0')}:${String(bm||0).padStart(2,'0')}:${String(bs||0).padStart(2,'0')}`;
  set("planet6BirthTime",birthTime12);
  const bpm=document.getElementById("planet6BirthAmPm"); if(bpm) bpm.value=birthAmPm;

  const d1=document.getElementById("p6_date_1"), d2=document.getElementById("p6_date_2");
  const t1=document.getElementById("p6_time_1"), t2=document.getElementById("p6_time_2");
  const ap1=document.getElementById("p6_ampm_1"), ap2=document.getElementById("p6_ampm_2");

  // DATE RULE: first row is ALWAYS the birth date.
  // 05:30 AM or later -> second row is the NEXT calendar day.
  // Before 05:30 AM -> second row is the PREVIOUS calendar day.
  // This is re-applied every time DOB or birth time changes.
  const birthSec=sec(birthTime24);
  const before0530=birthSec<19800;
  const dateObj=birthDate?new Date(birthDate+'T00:00:00'):null;
  let prevISO='', nextISO='';
  if(dateObj && !Number.isNaN(dateObj.getTime())){
    const prev=new Date(dateObj); prev.setDate(prev.getDate()-1);
    const next=new Date(dateObj); next.setDate(next.getDate()+1);
    const iso=d=>{
      const y=d.getFullYear();
      const m=String(d.getMonth()+1).padStart(2,'0');
      const day=String(d.getDate()).padStart(2,'0');
      return `${y}-${m}-${day}`;
    };
    prevISO=iso(prev); nextISO=iso(next);
    if(d1) d1.value=birthDate;
    if(d2) d2.value=before0530?prevISO:nextISO;
  }
  if(t1) t1.value='05:30:00';
  if(t2) t2.value='05:30:00';
  if(ap1) ap1.value='AM';
  if(ap2) ap2.value='AM';

  // Automatically load the two corresponding 05:30 ephemeris positions into the table.
  // Row 1 is birth date; row 2 is the adjacent date selected by the 05:30 rule.
  const row1Date=birthDate;
  const row2Date=before0530?prevISO:nextISO;
  const eph1=row1Date?findEph(row1Date):null;
  const eph2=row2Date?findEph(row2Date):null;
  for(let i=0;i<9;i++){
    // If the selected date exists in the embedded ephemeris, fill automatically.
    // If it is not present, preserve any manually entered planetary value instead of
    // erasing it; this lets the same calculation table work with a larger external
    // KP ephemeris dataset when supplied by the user.
    if(eph1) set(`p6_d_${i}`, eph1[i+1]||'');
    if(eph2) set(`p6_t_${i}`, eph2[i+1]||'');
  }

  const aySec=parseDmsAny(get("ayanValue")||"22:48:18");
  // Fraction of the 24-hour interval measured from the 05:30 ephemeris point.
  // After 05:30: elapsed = birth time - 05:30.
  // Before 05:30: elapsed = (birth time + 24h) - 05:30, i.e. from previous day's 05:30.
  const elapsedSec=before0530 ? (birthSec+86400-19800) : (birthSec-19800);
  const fraction=Math.max(0,Math.min(1,elapsedSec/86400));

  const signedDiff=(first,second)=>{
    let d=parseDmsAny(first)-parseDmsAny(second);
    const full=1296000, half=648000;
    if(d>half)d-=full;
    if(d<-half)d+=full;
    return d;
  };
  const fmtSigned=s=>{
    const neg=s<0; s=Math.abs(Math.round(s));
    const d=Math.floor(s/3600),m=Math.floor((s%3600)/60),x=s%60;
    return `${d}:${String(m).padStart(2,'0')}:${String(x).padStart(2,'0')}${neg?' R':''}`;
  };
  const fmtClock=s=>{
    s=Math.round(s);
    const neg=s<0; s=Math.abs(s);
    const d=Math.floor(s/3600),m=Math.floor((s%3600)/60),x=s%60;
    return `${neg?'-':''}${String(d).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(x).padStart(2,'0')}`;
  };

  window.lastPlanetPositions={};
  planets.forEach((name,i)=>{
    const row1=get(`p6_d_${i}`), row2=get(`p6_t_${i}`);
    const row1sec=parseDmsAny(row1), row2sec=parseDmsAny(row2);
    const hasBoth=!!row1 && !!row2;

    // IMPORTANT: daily motion is ALWAYS chronological NEXT DATE − PREVIOUS DATE.
    // After 05:30: row1 = birth date (previous), row2 = next date -> row2 - row1.
    // Before 05:30: row2 = previous date, row1 = birth date (next) -> row1 - row2.
    const daily=hasBoth ? (before0530 ? signedDiff(row1,row2) : signedDiff(row2,row1)) : NaN;
    const retro=Number.isFinite(daily)&&daily<0;
    set(`p6_motion_${i}`,Number.isFinite(daily)?fmtSigned(daily):"");

    // Keep the user's editable hours/minutes inputs and their automatic total.
    const hhRaw=get(`p6_hours_${i}`), mmRaw=get(`p6_minutes_${i}`);
    const hhSec=hhRaw?parseDmsAny(hhRaw):NaN, mmSec=mmRaw?parseDmsAny(mmRaw):NaN;
    let totalMotion=NaN;
    if(Number.isFinite(hhSec) && Number.isFinite(mmSec)) totalMotion=hhSec+mmSec;
    set(`p6_total_${i}`,Number.isFinite(totalMotion)?fmtSigned(totalMotion):"");

    // Automatic birth-time position: always start from the PREVIOUS day's 05:30
    // position and move forward by the elapsed fraction.
    const base=before0530 ? row2sec : row1sec;
    let birthPos=NaN;
    if(hasBoth && Number.isFinite(daily)) birthPos=normDegSec(base + daily*fraction);
    set(`p6_birth_${i}`,Number.isFinite(birthPos)?fmtLong(birthPos):"");

    // Preserve the existing manual hours/minutes calculation in the next row.
    let sum=NaN;
    if(Number.isFinite(birthPos)&&Number.isFinite(totalMotion)) sum=normDegSec(birthPos+totalMotion);
    set(`p6_add_${i}`,Number.isFinite(sum)?fmtLong(sum):"");

    if(Number.isFinite(sum)){
      const nir=normDegSec(sum-aySec);
      const rashiIndex=Math.floor(nir/108000);
      const remaining=nir-(rashiIndex*108000);
      set(`p6_ayan_${i}`,fmtLong(rashiIndex*108000));
      set(`p6_final_${i}`,fmtLong(remaining)+(retro&&i<7?" R":""));
      set(`p6_rashi_${i}`,rashi[rashiIndex]);
      window.lastPlanetPositions[name]=nir;
      const finalEl=document.getElementById(`p6_final_${i}`);
      if(finalEl) finalEl.dataset.rashi=rashi[rashiIndex];
    }else{
      set(`p6_ayan_${i}`,""); set(`p6_final_${i}`,""); set(`p6_rashi_${i}`,"");
    }
  });

  const info=document.getElementById("ephDateInfo");
  if(info){
    const sourceMsg = (!eph1 || !eph2)
      ? `<br><span style="color:#a33"><b>टीप:</b> निवडलेल्या तारखेचा 05:30 एफेमेरीस डेटा सध्या embedded data मध्ये उपलब्ध नाही. त्यामुळे उपलब्ध manual ग्रहअंश दिल्यास पुढील गणना automatic चालेल.</span>`
      : '';
    info.innerHTML=`<b>ग्रहस्थिती गणना:</b> दैनिक गती नेहमी कालानुक्रमाने <b>पुढील दिवसाची 05:30 ग्रहस्थिती − मागील दिवसाची 05:30 ग्रहस्थिती</b> अशी काढली जाते. जन्मवेळ 05:30 नंतर असल्यास जन्मतारखेपासून पुढील दिवसाकडे, आणि 05:30 पूर्वी असल्यास मागील दिवसापासून जन्मतारखेकडे इष्ट वेळेचे प्रमाण लावून <b>जन्मवेळची स्थिती</b> automatic काढली जाते.${sourceMsg}`;
  }
  const ruleDates=document.getElementById("planet6RuleDates");
  if(ruleDates){
    const a=d1?.value||"", b=d2?.value||"";
    ruleDates.textContent=(a&&b)?`${a}  /  ${b}`:"";
  }
}

function renderRaphCalc(){
  const target=document.getElementById("raphCalc");
  if(!target) return;
  const rows=readRaphaelRows();
  const targetST=getBirthST()||"14:13:49";
  const ay=parseDmsAny(document.getElementById("ayanValue").value||"22:48:18");

  let html=`
  <div class="notice" style="margin-bottom:10px">
    <b>इष्टभाव फरक = (फरक क्र.2 × फरक क्र.3) ÷ फरक क्र.1</b><br>
    Calculated result पूर्ण मिनिटावर round करून: <b>छोटी भाव स्थिती + इष्टभाव फरक = सायन भाव</b><br>
    नंतर: <b>सायन भाव − अयनांश = निरयन भावस्थिती</b>
  </div>
  <table>
  <thead><tr>
    <th>भाव</th><th>राशी</th><th>मो. सां. वे.</th><th>छो. सां. वे.</th>
    <th>इष्ट सां. वे.</th><th>फरक क्र.1</th><th>फरक क्र.2</th><th>फरक क्र.3</th>
    <th>इष्टभाव फरक</th><th>सायन भाव</th><th>स्थळ रेखांश गणना</th><th>निरयन भावस्थिती</th>
  </tr></thead><tbody>`;

  rows.forEach((r,i)=>{
    if(!r.bigST || !r.smallST || !r.bigBhava || !r.smallBhava){
      html+=`<tr><td>${i+1}</td><td>${r.rashi||""}</td><td colspan="10">डेटा अपूर्ण</td></tr>`;
      return;
    }
    const z=interpolateRaphaelRow(r.bigST,r.smallST,targetST,r.bigBhava,r.smallBhava,i===0);
    const nir=normDegSec(z.result-ay);
    const autoRashi=degreeRashiName(degToDms(nir));
    html+=`<tr>
      <td><b>${i+1}</b></td>
      <td><b>${autoRashi}</b></td>
      <td>${r.bigST}</td><td>${r.smallST}</td><td>${targetST}</td>
      <td>${hms(z.f1)}</td><td>${hms(z.f2)}</td><td>${fmtLong(z.f3)}</td>
      <td>${hms(z.rounded)}</td><td>${fmtLong(z.result)}</td><td>${fmtLong(ay)}</td>
      <td><b>${fmtLong(nir)}</b></td>
    </tr>`;
  });
  html+=`</tbody></table>`;
  target.innerHTML=html;
}
function parseDmsAny(v){
  if(v==null || v==="") return 0;
  let a=String(v).trim().split(":").map(Number);
  return (a[0]||0)*3600+(a[1]||0)*60+(a[2]||0);
}
function degToDms(s){
  s=((s%1296000)+1296000)%1296000;
  let d=Math.floor(s/3600), m=Math.floor((s%3600)/60), x=Math.round(s%60);
  if(x===60){x=0;m++} if(m===60){m=0;d++} if(d===360)d=0;
  return `${d}:${String(m).padStart(2,"0")}:${String(x).padStart(2,"0")}`;
}
function dmsToSeconds(v){return parseDmsAny(v)}
function interpolateRaphaelRow(bigST, smallST, targetST, bigBhava, smallBhava, isLagna){
  let f1=parseDmsAny(bigST)-parseDmsAny(smallST);
  if(f1<0) f1+=86400;
  let f2=parseDmsAny(targetST)-parseDmsAny(smallST);
  if(f2<0) f2+=86400;
  let f3=parseDmsAny(bigBhava)-parseDmsAny(smallBhava);
  if(f3<0) f3+=1296000;
  let raw=(f2*f3)/f1;
  let rounded=Math.round(raw/60)*60;
  let result=parseDmsAny(smallBhava)+rounded;
  return {f1,f2,f3,raw,rounded,result};
}
function readRaphaelRows(){
  return [...document.querySelectorAll("#raphRows tr")].map((tr)=>{
    let inputs=[...tr.querySelectorAll("input")];
    return {
      bhava: tr.children[0]?.textContent.trim() || "",
      rashi: tr.querySelector("select")?.value || "",
      bigST: inputs.find(x=>x.dataset.c==="2")?.value || "",
      smallST: inputs.find(x=>x.dataset.c==="3")?.value || "",
      bigBhava: inputs.find(x=>x.dataset.c==="4")?.value || "",
      smallBhava: inputs.find(x=>x.dataset.c==="5")?.value || ""
    };
  });
}
function getBirthST(){
  const field=document.getElementById("birthST");
  const v=field?.value?.trim() || "";
  window.manualBirthST=v;
  return v;
}
function renderCusps(ay){
  if(!document.getElementById("raphRows")){
    // Tab 5 calculates six houses; their opposite houses share the same degree
    // in the opposite sign. Use those current outputs for the chart and KP tables.
    const calculated={};
    [10,11,12,1,2,3].forEach(h=>{
      const value=(document.getElementById(`r5_nirayan_${h}`)?.value||"").trim();
      calculated[h]=value?normDegSec(parseDmsAny(value)):null;
      const opposite=((h+5)%12)+1;
      calculated[opposite]=value?normDegSec(calculated[h]+648000):null;
    });
    window.cuspResults=Array.from({length:12},(_,i)=>({i:i+1,nir:calculated[i+1],rashi:calculated[i+1]===null?"":rashi[Math.floor(calculated[i+1]/108000)]}));
    return;
  }
  let rows=readRaphaelRows(), targetST=getBirthST();
  let out=[];
  for(let i=0;i<12;i++){
    let r=rows[i] || {};
    if(r.bigST && r.smallST && r.bigBhava && r.smallBhava && targetST){
      let z=interpolateRaphaelRow(r.bigST,r.smallST,targetST,r.bigBhava,r.smallBhava,i===0);
      let nir=normDegSec(z.result-ay);
      out.push({i:i+1,r,z,nir,rashi:degreeRashiName(degToDms(nir))});
    }else out.push({i:i+1,r,z:null,nir:null,rashi:""});
  }
  window.cuspResults=out;

  let html=`<table><thead><tr>
  <th>भाव</th><th>राशी</th><th>फरक क्र.1</th><th>फरक क्र.2</th><th>फरक क्र.3</th>
  <th>इष्टभाव फरक</th><th>सायन भाव</th><th>स्थळ रेखांश गणना</th><th>निरयन भावस्थिती</th>
  </tr></thead><tbody>`;
  html+=out.map(x=>{
    if(!x.z) return `<tr><td>${x.i}</td><td>${x.r.rashi||""}</td><td colspan="7">डेटा अपूर्ण</td></tr>`;
    return `<tr>
      <td><b>${x.i}</b></td><td><b>${x.rashi}</b></td>
      <td>${hms(x.z.f1)}</td><td>${hms(x.z.f2)}</td><td>${fmtLong(x.z.f3)}</td>
      <td>${hms(x.z.rounded)}</td><td>${fmtLong(x.z.result)}</td><td>${fmtLong(ay)}</td>
      <td><b>${fmtLong(x.nir)}</b></td>
    </tr>`;
  }).join("");
  html+=`</tbody></table>`;
  const target=document.getElementById("cuspTable");
  if(target) target.innerHTML=html;
}

window.kundaliManual = false;

function renderChart(force=false){
  if(window.kundaliManual && !force) return;
  const chart=document.getElementById("kundali");
  if(!chart) return;

  const signNames=["मेष","वृषभ","मिथुन","कर्क","सिंह","कन्या","तुळ","वृश्चिक","धनु","मकर","कुंभ","मीन"];
  const positions={
    11:{r:1,c:1},0:{r:1,c:2},1:{r:1,c:3},2:{r:1,c:4},
    3:{r:2,c:4},4:{r:3,c:4},5:{r:4,c:4},6:{r:4,c:3},
    7:{r:4,c:2},8:{r:4,c:1},9:{r:3,c:1},10:{r:2,c:1}
  };

  const boxes=Array.from({length:12},()=>[]);
  const add=(signAbs,kind,label)=>{
    if(signAbs==null || !isFinite(signAbs)) return;
    const abs=normDegSec(signAbs);
    const idx=Math.min(11,Math.floor(abs/108000));
    boxes[idx].push({degree:abs%108000,kind,label,text:fmtLong(abs%108000)});
  };
  (window.cuspResults||[]).forEach(x=>add(x.nir,"cusp","भाव "+x.i));
  Object.entries(window.lastPlanetPositions||{}).forEach(([name,lon])=>add(lon,"planet",name));
  boxes.forEach(b=>b.sort((a,b)=>a.degree-b.degree || (a.kind==="cusp"?-1:1)));

  let out="";
  for(let i=0;i<12;i++){
    const pos=positions[i];
    const entries=boxes[i].map(v=>`<div class="s9-entry ${v.kind}">${v.label} — ${v.text}</div>`).join("");
    out+=`<div class="s9-cell" contenteditable="true" spellcheck="false" data-sign-index="${i}" style="grid-row:${pos.r};grid-column:${pos.c}">${entries}</div>`;
  }

  const val=id=>document.getElementById(id)?.value||"";
  const lagna=(window.cuspResults||[]).find(x=>x.i===1);
  let lagnaText="";
  if(lagna && lagna.nir!=null){
    const a=normDegSec(lagna.nir), si=Math.floor(a/108000);
    lagnaText=`<div style="margin-top:6px;text-align:center;font-weight:800">लग्न: ${signNames[si]} ${fmtLong(a%108000)}</div>`;
  }

  out+=`<div class="s9-center" contenteditable="true" spellcheck="false">
    <div style="width:100%">
      <div class="s9-center-title">कृष्णमूर्ती पद्धतीची लग्न व भावचलित कुंडली</div>
      <div class="s9-data">
        <b>नाव:</b> ${val("name")}<br>
        <b>जन्मतारीख:</b> ${val("dob")}<br>
        <b>जन्मवेळ:</b> ${val("birthTime")}<br>
        <b>अक्षांश:</b> ${val("lat")}<br>
        <b>रेखांश:</b> ${val("lon")}<br>
        <b>जन्मवेळी असलेली भोग्य महादशा:</b><br>
        ${val("mdBirthDasha")} ${val("mdBhogyaDuration") ? "— "+val("mdBhogyaDuration") : ""}
      </div>${lagnaText}
    </div>
  </div>`;

  out+=`
    <span class="s9-label s9-top0">मीन</span><span class="s9-label s9-top1">मेष</span><span class="s9-label s9-top2">वृषभ</span><span class="s9-label s9-top3">मिथुन</span>
    <span class="s9-label s9-right0">कर्क</span><span class="s9-label s9-right1">सिंह</span><span class="s9-label s9-right2">कन्या</span>
    <span class="s9-label" style="right:-38px;bottom:-24px;width:35px;text-align:left">तुळ</span>
    <span class="s9-label" style="left:25%;bottom:-24px;width:25%;text-align:center">वृश्चिक</span>
    <span class="s9-label" style="left:0;bottom:-24px;width:25%;text-align:center">धनु</span>
    <span class="s9-label s9-left2">मकर</span><span class="s9-label s9-left1">कुंभ</span>`;

  chart.innerHTML=out;
  chart.querySelectorAll('[contenteditable="true"]').forEach(el=>{
    el.addEventListener('input',()=>{
      window.kundaliManual=true;
      const st=document.getElementById('kundaliEditStatus');
      if(st) st.textContent='Manual edit mode — changes preserved';
    });
  });

  const validation=document.getElementById("chartAscValidation");
  if(validation){
    if(lagna && lagna.nir!=null){
      const a=normDegSec(lagna.nir), si=Math.floor(a/108000);
      validation.innerHTML=`<b>लग्न:</b> ${signNames[si]} ${fmtLong(a%108000)} &nbsp; | &nbsp; <b>भाव १ निरयन:</b> ${fmtLong(a)}`;
    }else validation.textContent="रॅफेल टेबलमधील १२ भावांची निरयन गणना पूर्ण झाल्यावर लग्न automatic दाखवले जाईल.";
  }
}

function autoFillKundali(){
  window.kundaliManual=false;
  const st=document.getElementById('kundaliEditStatus');
  if(st) st.textContent='Automatic calculation mode';
  document.querySelectorAll('#kundali [contenteditable]').forEach(el=>el.removeAttribute('contenteditable'));
  if(typeof calculateAll==='function') calculateAll();
  else renderChart(true);
  window.dispatchEvent(new CustomEvent('chart-manual-change',{detail:{manual:false}}));
}
function enableKundaliEdit(){
  const chart=document.getElementById('kundali');
  if(!chart) return;
  window.kundaliManual=true;
  const st=document.getElementById('kundaliEditStatus');
  if(st) st.textContent='Manual edit mode — click any house or the center to edit. Auto Fill restores calculated values.';
  chart.classList.add('manual-chart');
  chart.querySelectorAll('.v38-cell,.v38-center,.s9-cell,.s9-center').forEach(el=>{
    if(el.dataset.manualReady!=='1'){
      // Plain text keeps manual notes editable and imported backups inert.
      const text=el.innerText||el.textContent||'';
      el.textContent=text;
      el.dataset.manualText=text;
      el.dataset.manualReady='1';
      el.addEventListener('input',()=>{
        el.dataset.manualText=el.innerText;
        if(typeof renderReport==='function') renderReport();
        window.dispatchEvent(new CustomEvent('chart-manual-change',{detail:{manual:true}}));
      });
    }
    el.setAttribute('contenteditable','plaintext-only');
    el.setAttribute('spellcheck','false');
    el.style.whiteSpace='pre-wrap';
    el.style.padding='8px';
    el.style.overflow='auto';
    el.style.fontSize='12px';
    el.setAttribute('aria-label',el.classList.contains('v38-center')?'Edit chart center':`Edit chart house ${Number(el.dataset.signIndex)+1}`);
  });
  window.dispatchEvent(new CustomEvent('chart-manual-change',{detail:{manual:true}}));
}

function snapshotSection(id){
  const src=document.getElementById(id);
  if(!src) return "";
  const clone=src.cloneNode(true);
  if(['kp-fourfold','kp-sixfold','kp-fourstep-section'].includes(id))clone.hidden=false;
  const originals=[...src.querySelectorAll("input,select,textarea")];
  clone.querySelectorAll("input,select,textarea").forEach((el,i)=>{
    const original=originals[i];
    if(original.type==="hidden"){el.remove();return;}
    const span=document.createElement("span");
    let text=el.tagName==="SELECT"?(original.options[original.selectedIndex]?.textContent||""):(original.value||"");
    if(window.KPPreferences?.isConfigured()&&original.type==="date")text=window.KPPreferences.formatDate(original.value);
    if(window.KPPreferences?.isConfigured()&&original.type==="time")text=window.KPPreferences.formatTime(original.value);
    span.textContent=text;
    span.style.display="inline-block";
    span.style.minWidth="35px";
    span.style.padding="2px 4px";
    span.style.border="0";
    span.style.textAlign=getComputedStyle(original).textAlign||"center";
    el.replaceWith(span);
  });
  clone.querySelectorAll(".no-print,button,script").forEach(x=>x.remove());
  [clone,...clone.querySelectorAll("*")].forEach(el=>{
    if(el.id) el.dataset.reportId=el.id;
    [...el.attributes].forEach(attribute=>{
      if(attribute.name==="id" || attribute.name==="contenteditable" || /^on/i.test(attribute.name)) el.removeAttribute(attribute.name);
    });
  });
  clone.classList.remove("active");
  return clone.innerHTML;
}

function renderReport(){
  const pages=[
    ["1. मूलभूत माहिती","basic"],
    ["2. स्थळ रेखांश गणना","ayan"],
    ["3. स्थानिक जन्मवेळ (L.M.T.) गणना","lmt"],
    ["4. सांपत्तिक काळ गणना","stcalc"],
    ["5. रॅफेल टेबल ऑफ हाऊसेस","raphael5"],
    ["6. ग्रहस्थिती गणना","planet"],
    ["7. महादशा (MD) गणना","mdcalc"],
    ["8. कार्येश","karyesh"],
    ["9. South Indian Kundali","south9"]
  ];
  const container=document.getElementById("printReport");
  if(!container) return;
  container.innerHTML=pages.map(([title,id])=>`
    <div class="report-page">
      <div class="report-page-title">${title}</div>
      <div class="report-cover">${snapshotSection(id)}</div>
    </div>`).join("");
}

function printReport(){
  calculateAll();
  renderReport();
  window.KPLanguage?.localize(document.getElementById("printReport"));
  document.querySelectorAll(".tab").forEach(x=>x.classList.remove("printTarget"));
  document.getElementById("report").classList.add("printTarget");
  window.print();
  setTimeout(()=>document.getElementById("report").classList.remove("printTarget"),700);
}

function getChartData(){
  const fields={};
  document.querySelectorAll("main > section:not(#report):not(#home) input[id],main > section:not(#report):not(#home) select[id],main > section:not(#report):not(#home) textarea[id]").forEach(el=>{
    if(el.readOnly || (el.disabled && !el.closest('#transit') && el.id!=='birth-dst-minutes') || el.dataset.calculationLocked==="true") return;
    const field={value:el.value};
    if(el.type==="checkbox" || el.type==="radio") field.checked=el.checked;
    if(el.dataset.auto!==undefined) field.auto=el.dataset.auto;
    fields[el.id]=field;
  });
  return {
    version:3,
    format:"KP-RAPHAEL-LKP",
    savedAt:new Date().toISOString(),
    coverPhoto:window.KPReportPhoto?window.KPReportPhoto.get():'',
    fields,
    basic:Object.fromEntries(["name","dob","birthTime","lat","lon","dayAyan","daySum"].filter(id=>document.getElementById(id)).map(id=>[id,document.getElementById(id).value])),
    eph:readEph(),
    kundali:window.kundaliManual?{
      manual:true,
      cells:[...document.querySelectorAll('#kundali .v38-cell')].map(el=>({signIndex:Number(el.dataset.signIndex),text:el.dataset.manualText??el.textContent??''})),
      center:document.querySelector('#kundali .v38-center')?.dataset.manualText??document.querySelector('#kundali .v38-center')?.textContent??''
    }:{manual:false}
  };
}
function restoreChartData(data){
  const isObject=value=>value && typeof value==="object" && !Array.isArray(value);
  const savedCoordinateDms=value=>{
    const number=Number(value),total=Math.round(Math.abs(number)*3600);
    return (number<0?'-':'')+Math.floor(total/3600)+':'+String(Math.floor(total%3600/60)).padStart(2,'0')+':'+String(total%60).padStart(2,'0');
  };
  if(!isObject(data) || (!isObject(data.fields) && !isObject(data.basic))) throw new Error("This file does not contain a saved chart.");
  const source=isObject(data.fields)?data.fields:data.basic;
  if(Object.keys(source).length>2000) throw new Error("Saved chart contains too many fields.");
  const entries=Object.entries(source).map(([id,field])=>{
    let record=isObject(field)?field:{value:field};
    if(typeof record.value!=="string" && typeof record.value!=="number") throw new Error("Saved chart contains an invalid field.");
    // Matchmaking uses decimal coordinates for its numeric controls, while the
    // native Birth Details worksheet uses signed D:M:S. Migrate old and newly
    // imported Matchmaking kundalis before placing their values in the form.
    if((id==='lat'||id==='lon')&&String(record.value).trim()!==''&&Number.isFinite(Number(record.value))&&!String(record.value).includes(':'))record={...record,value:savedCoordinateDms(record.value)};
    const maxLength=['mm-memos'].includes(id)?100000:10000;
    if(String(record.value).length>maxLength) throw new Error("Saved chart contains an oversized field.");
    return [id,record];
  });
  for(const [id,record] of entries){
    if(id==='mm-memos'&&!window.KPMatchmaking?.validateSaved(String(record.value)))throw new Error('Saved matchmaking records are invalid.');
    if(id==='chart-categories'&&!window.KPHorary?.validateCategories(String(record.value)))throw new Error('Saved chart categories are invalid.');
  }
  const preferenceEntry=entries.find(([id])=>id==='kp-software-settings');
  if(preferenceEntry&&String(preferenceEntry[1].value).trim()){
    let preferences;
    try{preferences=JSON.parse(String(preferenceEntry[1].value));}catch(error){throw new Error('Saved software settings are invalid.');}
    if(!isObject(preferences))throw new Error('Saved software settings are invalid.');
  }
  if(data.eph!==undefined && (!Array.isArray(data.eph) || data.eph.length>20000 || data.eph.some(row=>!Array.isArray(row)||row.length!==10||row.some(value=>typeof value!=="string"||value.length>100)))) throw new Error("Saved ephemeris data is invalid.");
  if(data.coverPhoto!==undefined && (!window.KPReportPhoto || !window.KPReportPhoto.isValid(data.coverPhoto))) throw new Error("Saved cover photo is invalid.");
  if(data.kundali!==undefined){
    const chart=data.kundali;
    if(!isObject(chart) || typeof chart.manual!=="boolean") throw new Error("Saved chart edit mode is invalid.");
    if(chart.manual && (!Array.isArray(chart.cells)||chart.cells.length!==12||new Set(chart.cells.map(cell=>cell?.signIndex)).size!==12||chart.cells.some(cell=>!isObject(cell)||!Number.isInteger(cell.signIndex)||cell.signIndex<0||cell.signIndex>11||typeof cell.text!=="string"||cell.text.length>10000)||typeof chart.center!=="string"||chart.center.length>20000)) throw new Error("Saved manual chart text is invalid.");
  }
  const eligible=new Map([...document.querySelectorAll("main > section:not(#report):not(#home) input[id],main > section:not(#report):not(#home) select[id],main > section:not(#report):not(#home) textarea[id]")].filter(el=>!el.readOnly&&(!el.disabled||el.closest('#transit')||el.id==='birth-dst-minutes')&&el.dataset.calculationLocked!=="true").map(el=>[el.id,el]));
  // Older chart files contain manual ephemeris rows. Do not let an automatic
  // source left active in the current chart overwrite those imported values.
  for(const id of ['p6-ephemeris-source','st-ephemeris-source','kp-ayanamsha-source','r5-house-source']){
    const control=eligible.get(id);
    if(control)control.value='manual';
  }
  const newDefaults={'instant-prashna':'0','chart-kind':'natal','horary-system':'249','horary-number':'1','birth-dst-minutes':'0','rpw-memos':'[]','mm-memos':'[]'};
  for(const [id,value] of Object.entries(newDefaults))if(eligible.has(id))eligible.get(id).value=value;
  entries.forEach(([id,record])=>{
    const el=eligible.get(id);
    if(!el) return;
    el.value=String(record.value);
    if((el.type==="checkbox" || el.type==="radio") && typeof record.checked==="boolean") el.checked=record.checked;
    if(record.auto==="0" || record.auto==="1") el.dataset.auto=record.auto;
    else if(/^p6_(row_date_[12]|birth_pos_date)$/.test(id)) el.dataset.auto="0";
  });
  if(!entries.some(([id])=>id==='birth-utc-offset')){
    const parts=String(document.getElementById('stdLon')?.value||'82:30:00').split(':').map(Number);
    const sign=parts[0]<0?-1:1,meridian=sign*(Math.abs(parts[0]||0)+(parts[1]||0)/60+(parts[2]||0)/3600);
    if(eligible.has('birth-utc-offset'))eligible.get('birth-utc-offset').value=String(meridian/15);
  }
  window.KPHorary?.refresh();
  if(data.eph!==undefined) window.savedEphemeris=data.eph.map(row=>row.slice());
  if(data.coverPhoto!==undefined) window.KPReportPhoto.apply(data.coverPhoto,{persist:false});
  if(!isObject(data.fields)){
    // Older saves held only basic data. Keep their date controls synchronized
    // and load the available ephemeris without restoring calculated outputs.
    const dob=document.getElementById("dob")?.value;
    if(dob){
      const before=sec(document.getElementById("birthTime")?.value)<19800;
      const dates={p6_row_date_1:before?dateAdd(dob,-1):dob,p6_row_date_2:before?dob:dateAdd(dob,1),p6_birth_pos_date:dob};
      Object.entries(dates).forEach(([id,value])=>{const el=document.getElementById(id);if(el){el.value=value;el.dataset.auto="1"}});
      const a=findEph(dates.p6_row_date_1), b=findEph(dates.p6_row_date_2);
      for(let i=0;i<9;i++){
        if(a) document.getElementById(`p6_d_${i}`).value=a[i+1];
        if(b) document.getElementById(`p6_t_${i}`).value=b[i+1];
      }
    }
  }
  renderEph();
  // Loading a saved chart reconstructs a clean calculated layout first.
  window.kundaliManual=false;
  const savedADSelection=entries.find(([id])=>id==="adMDSelect");
  window.requestAntardashaSelection?.(String(savedADSelection?.[1].value??""));
  if(!preferenceEntry&&document.getElementById('kp-software-settings'))document.getElementById('kp-software-settings').value='';
  window.KPPreferences?.restore({persist:true,notify:false});
  calculateAll();
  window.KPTransit?.cancel();
  window.KPTransit?.refresh();
  window.KPTransitChart?.refresh();
  window.KPTransitPanchang?.refresh();
  window.KPDailyEphemeris?.cancel();
  window.KPDailyEphemeris?.refresh();
  window.KPPrediction?.refresh();
  window.KPPersonalPredictions?.refresh();
  window.KPDashaFal?.refresh();
  window.KPGemstones?.refresh();
  window.KPTimeSlices?.invalidate();
  window.KPEventPromise?.refresh();
  window.KPNadiAstrology?.stopRealTime();
  window.KPNadiAstrology?.refresh();
  window.KPMatchmaking?.restore(document.getElementById('mm-memos')?.value||'[]');
  window.KPHomeDasha?.refresh();
  window.KPHomeChartReference?.setHouse(1);
  window.KPChartStyle?.refresh();
  if(data.kundali?.manual){
    data.kundali.cells.forEach(cell=>{
      const target=document.querySelector(`#kundali .v38-cell[data-sign-index="${cell.signIndex}"]`);
      if(target){target.textContent=cell.text;target.dataset.manualText=cell.text;}
    });
    const center=document.querySelector('#kundali .v38-center');
    if(center){center.textContent=data.kundali.center;center.dataset.manualText=data.kundali.center;}
    enableKundaliEdit();
    renderReport();
  }else{
    const status=document.getElementById('kundaliEditStatus');
    if(status) status.textContent='Automatic calculation mode';
  }
  window.dispatchEvent(new CustomEvent("chart-saved",{detail:{savedAt:data.savedAt||null,action:"loaded"}}));
  return true;
}
function saveData(){
  const notify=(message,type)=>typeof window.showToast==="function"?window.showToast(message,type):alert(message);
  try{
    const data=getChartData();
    localStorage.setItem("kpRaphaelData",JSON.stringify(data));
    window.dispatchEvent(new CustomEvent("chart-saved",{detail:{savedAt:data.savedAt,action:"saved"}}));
    notify("Chart and worksheet data saved in this browser.","success");
    return true;
  }catch(error){notify("Unable to save chart. Browser storage may be full or unavailable.","error");return false;}
}
function loadData(){
  const notify=(message,type)=>typeof window.showToast==="function"?window.showToast(message,type):alert(message);
  try{
    const saved=localStorage.getItem("kpRaphaelData");
    if(!saved){notify("No saved chart in this browser yet.","info");return false;}
    const chart=JSON.parse(saved),preferences=localStorage.getItem(window.KPPreferences?.storageKey||'kpRaphaelSoftwarePreferencesV1');
    if(preferences){chart.fields=chart.fields||{};chart.fields['kp-software-settings']={value:preferences};}
    restoreChartData(chart);
    notify("Saved chart loaded and recalculated.","success");
    return true;
  }catch(error){notify("Unable to load saved chart. The data is damaged or browser storage is unavailable.","error");return false;}
}
init();

