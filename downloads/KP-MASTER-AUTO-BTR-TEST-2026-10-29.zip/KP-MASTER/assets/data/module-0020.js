
/* v20 FINAL FIX — Tab 6 जन्मवेळची स्थिती = जन्मतारखेच्या 05:30 ग्रहस्थितीची direct copy.
   No interpolation/calculation is used for this row.
   The birth-date row is whichever planetary row date exactly matches DOB:
   - Birth after 05:30: second row = DOB, first row = next day.
   - Birth before 05:30: second row = DOB, first row = preceding day.
   This override intentionally supersedes earlier v17/v19 birth-position logic only.
   Tabs 1–5 are untouched.
*/
(function(){
  function copyBirthDateRowDirect(){
    if(document.getElementById('chart-kind')?.value==='horary')return;
    const dob=document.getElementById('dob')?.value||'';
    if(!dob) return;
    const d1=document.getElementById('p6_row_date_1')?.value||'';
    const d2=document.getElementById('p6_row_date_2')?.value||'';
    let sourcePrefix='';
    if(d1===dob) sourcePrefix='p6_d_';
    else if(d2===dob) sourcePrefix='p6_t_';
    else return;

    for(let i=0;i<9;i++){
      const src=document.getElementById(sourcePrefix+i);
      const dst=document.getElementById('p6_birth_'+i);
      if(src && dst) dst.value=src.value||'';
    }

    // The date displayed beside जन्मवेळची स्थिती is always the birth date.
    const bp=document.getElementById('p6_birth_pos_date');
    if(bp){ bp.value=dob; bp.disabled=true; bp.title='जन्मवेळची स्थिती — जन्मतारखेच्या ग्रहस्थितीची थेट प्रत'; }
  }

  window.copyBirthDateRowDirect=copyBirthDateRowDirect;
  document.addEventListener('DOMContentLoaded',function(){
    ['dob','birthTime','p6_row_date_1','p6_row_date_2'].forEach(id=>{
      const e=document.getElementById(id);
      if(e){
        e.addEventListener('change',()=>setTimeout(copyBirthDateRowDirect,0));
        e.addEventListener('input',()=>setTimeout(copyBirthDateRowDirect,0));
      }
    });
    copyBirthDateRowDirect();
    setTimeout(copyBirthDateRowDirect,100);
    setTimeout(copyBirthDateRowDirect,500);
  });
})();

