
/* v31: Astrologer settings + developer footer */
(function(){
  const DEFAULTS = {
    name: 'Astro.Nitin Talegaonkar',
    mobile: '8412098690',
    address: ''
  };

  function getSettings(){
    try{
      const s = JSON.parse(localStorage.getItem('kpAstrologerSettings') || '{}');
      return Object.assign({}, DEFAULTS, window.KP_EMBEDDED_ASTROLOGER_SETTINGS || {}, s);
    }catch(e){ return Object.assign({}, DEFAULTS, window.KP_EMBEDDED_ASTROLOGER_SETTINGS || {}); }
  }

  window.applyAstrologerSettings = function(){
    const s = getSettings();
    const n = document.getElementById('astroName');
    const m = document.getElementById('astroMobile');
    const a = document.getElementById('astroAddress');
    if(n && !n.matches(':focus')) n.value = s.name;
    if(m && !m.matches(':focus')) m.value = s.mobile;
    if(a && !a.matches(':focus')) a.value = s.address;
    const f = document.getElementById('softwareDeveloperFooter');
    if(f) f.textContent = 'Software developer Name: ' + s.name + ' | Mob: ' + s.mobile;
  };

  window.saveAstrologerSettings = function(){
    const s = {
      name: (document.getElementById('astroName')?.value || DEFAULTS.name).trim() || DEFAULTS.name,
      mobile: (document.getElementById('astroMobile')?.value || DEFAULTS.mobile).trim() || DEFAULTS.mobile,
      address: (document.getElementById('astroAddress')?.value || '').trim()
    };
    localStorage.setItem('kpAstrologerSettings', JSON.stringify(s));
    applyAstrologerSettings();
    const st = document.getElementById('astroSettingStatus');
    if(st) st.textContent = '✓ Astrologer setting saved. Footer and print report updated.';
  };

  window.resetAstrologerSettings = function(){
    localStorage.removeItem('kpAstrologerSettings');
    applyAstrologerSettings();
    const st = document.getElementById('astroSettingStatus');
    if(st) st.textContent = 'Default astrologer setting restored.';
  };

  document.addEventListener('DOMContentLoaded', function(){
    applyAstrologerSettings();
  });
})();

