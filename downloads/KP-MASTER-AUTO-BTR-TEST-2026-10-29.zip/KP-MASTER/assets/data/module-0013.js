
document.addEventListener("DOMContentLoaded",()=>{
  const std=document.getElementById("stdLon");
  const place=document.getElementById("placeStdLon");
  if(std) std.addEventListener("input", updateLongitudeDifference);
  if(place) place.addEventListener("input", updateLongitudeDifference);
  updateLongitudeDifference();
});

