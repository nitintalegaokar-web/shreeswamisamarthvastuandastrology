
/* Fortuna is a derived display point. It never enters the nine-graha model,
   worksheet inputs, significators, aspects or transit-search criteria.
   Native model longitudes use arcseconds; Transit Chart longitudes use degrees. */
(function(){
  'use strict';
  const CIRCLE=1296000;
  const norm=value=>((value%CIRCLE)+CIRCLE)%CIRCLE;
  const finite=value=>(typeof value==='number'||typeof value==='string'&&value.trim()!=='')&&Number.isFinite(Number(value));
  const settings=()=>window.KPPreferences?.get?.()||{};
  function isVisible(){return settings().showFortuna===true;}
  function calculate(data,options={}){
    if(!data||data.ready===false||!window.KPDisplay?.longitudeDetails)return null;
    const unit=options.unit||(Array.isArray(data.houses)?'arcseconds':null);
    if(!['arcseconds','degrees'].includes(unit))return null;
    const multiplier=unit==='degrees'?3600:1;
    const rawCusps=Array.isArray(data.houses)?data.houses:data.cusps;
    if(!Array.isArray(rawCusps)||rawCusps.length!==12||rawCusps.some(cusp=>!finite(typeof cusp==='object'?cusp?.longitude:cusp)))return null;
    const cusps=rawCusps.map(cusp=>norm(Number(typeof cusp==='object'?cusp.longitude:cusp)*multiplier));
    const spans=cusps.map((cusp,index)=>norm(cusps[(index+1)%12]-cusp));
    if(spans.some(span=>span<1e-7)||Math.abs(spans.reduce((total,span)=>total+span,0)-CIRCLE)>1e-5)return null;
    const planets=Array.isArray(data.planets)?data.planets:[];
    const sun=planets.find(planet=>planet.id==='Su'),moon=planets.find(planet=>planet.id==='Mo');
    if(!finite(sun?.longitude)||!finite(moon?.longitude))return null;
    const sunLongitude=norm(Number(sun.longitude)*multiplier),moonLongitude=norm(Number(moon.longitude)*multiplier);
    const sunHouse=cusps.findIndex((cusp,index)=>norm(sunLongitude-cusp)<spans[index])+1;
    if(!sunHouse)return null;
    const sect=sunHouse>=7?'day':'night';
    const requested=options.formula??settings().fortunaFormula??'sect';
    const formula=['sect','day','night'].includes(requested)?requested:'sect';
    const formulaUsed=formula==='sect'?sect:formula;
    const longitude=norm(cusps[0]+(formulaUsed==='day'?moonLongitude-sunLongitude:sunLongitude-moonLongitude));
    return {id:'Fo',name:'Fortuna',ready:true,...window.KPDisplay.longitudeDetails(longitude),
      longitudeDegrees:longitude/3600,unit:'arcseconds',formula,formulaUsed,sect,sunHouse,
      ascLongitude:cusps[0],sunLongitude,moonLongitude,
      formulaText:formulaUsed==='day'?'Asc + Moon − Sun':'Asc + Sun − Moon'};
  }
  function getNatal(){return isVisible()?calculate(window.currentKPModel,{unit:'arcseconds'}):null;}
  function getTransit(data){return isVisible()?calculate(data,{unit:'degrees'}):null;}
  function description(point){
    if(!point)return '';
    return 'Fortuna · '+point.signCode+' '+point.degree+' · '+(point.formulaUsed==='day'?'Day':'Night')+' formula: '+point.formulaText+' · (SGL–STL–SBL): ('+point.sgl+'-'+point.stl+'-'+point.sl+')';
  }
  function updateInfo(id,point){
    const element=document.getElementById(id);
    if(!element)return;
    element.textContent=description(point);
    element.hidden=!point;
    if(point)element.dataset.longitude=point.longitude;else delete element.dataset.longitude;
  }
  window.KPFortuna=Object.freeze({calculate,getNatal,getTransit,isVisible,description,updateInfo});
})();

