
(function(){
  'use strict';
  const IDS=['Su','Mo','Ma','Me','Ju','Ve','Sa','Ra','Ke'];
  const ROMAN=['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];
  const SIGNS=['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
  const NAK=['Ashwini','Bharani','Krittika','Rohini','Mrigashirsha','Ardra','Punarvasu','Pushya','Ashlesha','Magha','P.Phalguni','U.Phalguni','Hasta','Chitra','Swati','Vishakha','Anuradha','Jyeshtha','Mula','P.Ashadha','U.Ashadha','Shravana','Dhanishtha','Shatabhisha','P.Bhadra','U.Bhadra','Revati'];
  const LORDS=['Ketu','Venus','Sun','Moon','Mars','Rahu','Jupiter','Saturn','Mercury'];
  const TITHI=['Pratipada','Dwitiya','Tritiya','Chaturthi','Panchami','Shashthi','Saptami','Ashtami','Navami','Dashami','Ekadashi','Dwadashi','Trayodashi','Chaturdashi'];
  const YOGA=['Vishkambha','Priti','Ayushman','Saubhagya','Shobhana','Atiganda','Sukarma','Dhriti','Shula','Ganda','Vriddhi','Dhruva','Vyaghata','Harshana','Vajra','Siddhi','Vyatipata','Variyana','Parigha','Shiva','Siddha','Sadhya','Shubha','Shukla','Brahma','Indra','Vaidhriti'];
  const KARANA=['Bava','Balava','Kaulava','Taitila','Gara','Vanija','Vishti'];
  const CIRCLE=1296000;
  const norm=value=>((value%CIRCLE)+CIRCLE)%CIRCLE;
  const value=id=>String(document.getElementById(id)?.value||'').trim();
  const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const dateOK=source=>/^\d{4}-\d{2}-\d{2}$/.test(source)&&Number.isFinite(Date.parse(source+'T12:00:00Z'))&&new Date(source+'T12:00:00Z').toISOString().slice(0,10)===source;
  function panchang(sunArcseconds,moonArcseconds,dob){
    if(typeof sunArcseconds!=='number'||typeof moonArcseconds!=='number'||!Number.isFinite(sunArcseconds)||!Number.isFinite(moonArcseconds))return null;
    const sun=norm(sunArcseconds),moon=norm(moonArcseconds),elongation=norm(moon-sun);
    const tithiIndex=Math.floor(elongation/43200),halfTithiIndex=Math.floor(elongation/21600),yogaIndex=Math.floor(norm(sun+moon)/48000),nakIndex=Math.floor(moon/48000),moonSignIndex=Math.floor(moon/108000);
    return {tithiIndex,tithiNumber:tithiIndex+1,halfTithiIndex,yogaIndex,nakIndex,moonSignIndex,
      tithi:tithiIndex===14?'Purnima':tithiIndex===29?'Amavasya':TITHI[tithiIndex%15],paksha:tithiIndex<15?'Shukla':'Krishna',
      karana:halfTithiIndex===0?'Kimstughna':halfTithiIndex<57?KARANA[(halfTithiIndex-1)%7]:['Shakuni','Chatushpada','Naga'][halfTithiIndex-57],
      yoga:YOGA[yogaIndex],nakshatra:NAK[nakIndex],nakLord:LORDS[nakIndex%9],pada:Math.floor((moon%48000)/12000)+1,rashi:SIGNS[moonSignIndex],
      weekday:dateOK(String(dob||''))?['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][new Date(dob+'T12:00:00Z').getUTCDay()]:'—'};
  }
  function dateText(source){
    if(!dateOK(source))return source||'—';
    if(window.KPPreferences?.isConfigured())return window.KPPreferences.formatDate(source);
    return source.slice(8,10)+'/'+source.slice(5,7)+'/'+source.slice(0,4);
  }
  function timeText(source){
    if(window.KPPreferences?.isConfigured())return window.KPPreferences.formatTime(source);
    const parts=/^(\d{1,2}):([0-5]\d)(?::([0-5]\d))?$/.exec(source);
    if(!parts||Number(parts[1])>23)return source||'—';
    const hour=Number(parts[1]);return String(hour%12||12).padStart(2,'0')+':'+parts[2]+':'+(parts[3]||'00')+' '+(hour<12?'AM':'PM');
  }
  function enteredDMS(source){
    if(!/^-?\d+(?:\.\d+)?(?::\d+(?:\.\d+)?){0,2}$/.test(source))return null;
    const parts=source.replace(/^-/,'').split(':').map(Number);
    if(parts.slice(1).some(part=>part>=60))return null;
    return (source.startsWith('-')?-1:1)*(parts[0]+(parts[1]||0)/60+(parts[2]||0)/3600);
  }
  function coordinate(source,axis){
    const number=enteredDMS(source);if(number===null)return source||'—';
    const seconds=Math.round(Math.abs(number)*3600),d=Math.floor(seconds/3600),m=Math.floor(seconds%3600/60),s=seconds%60;
    return d+'° '+String(m).padStart(2,'0')+'′ '+String(s).padStart(2,'0')+'″ '+(axis==='lat'?(number<0?'S':'N'):(number<0?'W':'E'));
  }
  function timezone(){
    const meridian=enteredDMS(value('stdLon'));if(meridian===null)return '—';
    const offset=meridian/15,minutes=Math.round(Math.abs(offset)*60);
    return (offset<0?'−':'+')+String(Math.floor(minutes/60)).padStart(2,'0')+':'+String(minutes%60).padStart(2,'0');
  }
  function markers(id,model,house=false){
    if(window.KPPreferences?.get().notationMarkers===false)return '';
    const tokens=house?window.KPDisplay?.getHouseNotations(id,model)||[]:window.KPDisplay?.getNotations(id,model)||[];
    return tokens.length?'<span class="sp-markers">'+tokens.map(token=>'<span class="sp-marker" data-marker="'+escape(token)+'">'+escape(token)+'</span>').join('')+'</span>':'';
  }
  function planet(id,model,primary=false){
    return '<span class="sp-reference'+(primary?' sp-primary-planet':'')+'" data-single-planet="'+escape(id)+'">'+escape(id)+markers(id,model)+'</span>';
  }
  function renderValue(source,model,annotate=true){
    if(Array.isArray(source))return source.length?source.map(item=>renderValue(item,model,annotate)).join(', '):'';
    if(IDS.includes(source))return annotate?planet(source,model):escape(source);
    return escape(source===undefined||source===null?'—':source);
  }
  function table(key,title,rows,fields,houses,model,widths){
    const ready=model?.ready,compactBasic=key.startsWith('basic');
    return '<table class="sp-table" data-single-table="'+key+'"><caption'+(key.startsWith('basic')?' class="sp-sr-caption"':'')+'>'+escape(title)+'</caption>'+(widths?'<colgroup>'+widths.map(width=>'<col style="width:'+width+'%">').join('')+'</colgroup>':'')+'<thead><tr><th scope="col">'+(houses?'House':'Planet')+'</th>'+fields.map(field=>'<th scope="col">'+escape(field[1])+'</th>').join('')+'</tr></thead><tbody>'+rows.map(row=>'<tr data-'+(houses?'house':'planet')+'="'+escape(row.id)+'"><th scope="row">'+(houses?escape(ROMAN[row.id-1])+markers(row.id,model,true):planet(row.id,model,true))+'</th>'+fields.map(([key])=>{
      const source=!ready?undefined:key==='nak'?NAK[row.nakIndex]:key==='degree'?window.KPDisplay.formatDegree(row.longitude):row[key];
      const displayed=ready&&key==='nak'?escape(row.nakCode+' ('+row.pada+')'):ready&&key==='degree'?escape(String(source).replace(/\s+/g,'')):renderValue(source,model,!compactBasic||houses&&key==='occ');
      return '<td data-field="'+key+'" data-value="'+escape(source===undefined?'':typeof source==='object'?JSON.stringify(source):source)+'"'+(ready&&key==='nak'?' title="'+escape(source+' · Pada '+row.pada)+'"':'')+'>'+displayed+'</td>';
    }).join('')+'</tr>').join('')+'</tbody></table>';
  }
  function nativeData(model){
    const sun=model?.ready?model.planets.find(point=>point.id==='Su'):null,moon=model?.ready?model.planets.find(point=>point.id==='Mo'):null;
    const info=sun&&moon?panchang(sun.longitude,moon.longitude,value('dob')):null;
    const rows=[
      [['name','Name',value('name')],['dob','Date',dateText(value('dob'))],['time','BT',timeText(value('birthTime'))]],
      [['place','Place',value('birthPlace')],['latitude','Lat',coordinate(value('lat'),'lat')],['longitude','Long',coordinate(value('lon'),'lon')]],
      [['timezone','TZ',timezone()],['dst','DST','0'],['tithi','Tithi',info?.tithi]],
      [['paksha','Paksha',info?.paksha],['weekday','Vaar',info?.weekday],['nakshatra','Nak',info?.nakshatra]],
      [['yoga','Yoga',info?.yoga],['karana','Karana',info?.karana],['rashi','Rasi',info?.rashi]],
      [['star-lord','Nak Ld',info?.nakLord],['pada','Pada',info?.pada],['ayanamsha','Ayanam',value('ayanValue')]],
      [['house-system','Hs Sys','Raphael cusps'],['node-type','Node Type','Worksheet'],['dst-note','Time','Standard time']]];
    return '<table class="sp-table sp-native-table" aria-label="Native basic data and Panchang"><tbody>'+rows.map(row=>'<tr>'+row.map(([key,label,text])=>'<td data-native-field="'+key+'" data-value="'+escape(text??'')+'"><strong>'+escape(label)+'</strong> '+escape(text||'—')+'</td>').join('')+'</tr>').join('')+'</tbody></table>';
  }
  function chart(){
    const sourceId=window.KPChartStyle?.getSourceId()||'kundali',source=document.getElementById(sourceId);
    if(!source)return '<div class="sp-status">Complete the chart calculations to show the kundali.</div>';
    const clone=source.cloneNode(true);
    clone.classList.add('sp-chart');clone.dataset.sourceChart=sourceId;clone.hidden=false;clone.removeAttribute('data-kundali-alternate');
    for(const element of [clone,...clone.querySelectorAll('*')]){
      if(element.id){element.dataset.reportId='single-'+element.id;element.removeAttribute('id');}
      for(const attribute of [...element.attributes])if(/^on/i.test(attribute.name)||['contenteditable','tabindex','aria-controls'].includes(attribute.name))element.removeAttribute(attribute.name);
    }
    // The compact chart is much smaller than the workspace. Give complete
    // name/degree/lord labels their own vertical slots before cloning to print.
    clone.querySelectorAll('.v38-lane').forEach(lane=>{
      const items=[...lane.querySelectorAll('.v38-item')];if(!items.length)return;
      const slot=100/Math.max(2.5,items.length),tops=items.map(item=>Math.max(0,Math.min(100-slot,parseFloat(item.style.top)||0)));
      for(let i=1;i<tops.length;i++)tops[i]=Math.max(tops[i],tops[i-1]+slot);
      if(tops.at(-1)>100-slot){tops[tops.length-1]=100-slot;for(let i=tops.length-2;i>=0;i--)tops[i]=Math.min(tops[i],tops[i+1]-slot);}
      lane.style.setProperty('--v38-lane-scale',String(Math.min(1,3/items.length)));
      items.forEach((item,i)=>{item.style.top=Math.max(0,tops[i])+'%';item.style.height=slot+'%';});
    });
    const centre=clone.querySelector('.v38-center');
    if(centre){centre.removeAttribute('data-manual-text');centre.replaceChildren();const om=document.createElement('span');om.className='sp-om';om.textContent='ॐ';centre.append(om);}
    return clone.outerHTML;
  }
  function dashaCards(periods){
    if(periods.length!==9)return '<p class="sp-status">Complete the birth date and calculated Moon position to show all nine Mahadashas and their Antardashas.</p>';
    return '<div class="sp-md-grid">'+periods.map(period=>{
      const id=window.KPDisplay?.idByName[period.lord]||period.lord,ads=window.calculateAntardashas?.(period)||[];
      return '<table class="sp-table sp-md-card" data-single-md-key="'+escape(period.key)+'" data-md-lord="'+escape(id)+'" data-md-full-start="'+escape(ads[0]?.start||'')+'" data-md-end="'+escape(period.end)+'"><caption>'+escape(id)+' Dasa</caption><colgroup><col><col></colgroup><thead><tr><th scope="col">Pln</th><th scope="col">Start Date</th></tr></thead><tbody>'+ads.map(ad=>{
        const lord=window.KPDisplay?.idByName[ad.lord]||ad.lord;
        return '<tr data-ad-lord="'+escape(lord)+'" data-period-start="'+escape(ad.start)+'" data-period-end="'+escape(ad.end)+'" data-birth-active="'+Boolean(ad.birthActive)+'"><th scope="row">'+escape(lord)+'</th><td>'+escape(dateText(ad.start))+'</td></tr>';
      }).join('')+'</tbody></table>';
    }).join('')+'</div>';
  }
  function render(){
    const model=window.currentKPModel,periods=Array.isArray(window.mdDashaPeriods)?window.mdDashaPeriods:[],ready=Boolean(model?.ready);
    const planets=ready?model.planets:IDS.map(id=>({id})),houses=ready?model.houses:ROMAN.map((name,index)=>({id:index+1,name}));
    const fourPlanets=ready?model.fourfold.planets:planets,fourHouses=ready?model.fourfold.houses:houses;
    const page=document.createElement('div');page.className='report-page report-single-page';page.dataset.reportSection='single-page';page.dataset.ready=String(ready&&periods.length===9);page.setAttribute('aria-label','Single-page astrology report');
    const basicPlanet=[['signCode','Sgn'],['degree','Degree'],['nak','Nak'],['occ','Occ'],['own','Own'],['sgl','SgL'],['stl','StL'],['sl','SL'],['ssl','SSL']];
    const basicHouse=[['signCode','Sgn'],['degree','Degree'],['nak','Nak'],['occ','Occ'],['sgl','SgL'],['stl','StL'],['sl','SL'],['ssl','SSL']];
    const four=[['A','A'],['B','B'],['C','C'],['D','D']];
    page.innerHTML='<div class="report-page-title">Single-page report</div><div class="sp-page-inner"><p class="sp-status"'+(ready?' hidden':'')+'>Complete the planet and house worksheets to calculate this report.</p><div class="sp-content"><div class="sp-column sp-left">'+chart()+nativeData(model)+table('fourfold-planet','Significators (4 Fold) – Planets',fourPlanets,four,false,model,[20,20,20,20,20])+table('fourfold-house','Significators (4 Fold) – Houses',fourHouses,four,true,model,[15,21.25,21.25,21.25,21.25])+'</div><div class="sp-column sp-right">'+table('basic-planet','Basic planetary calculations',planets,basicPlanet,false,model,[12,7,18,15,7,9,8,8,8,8])+table('basic-house','Basic house calculations',houses,basicHouse,true,model,[12,7,18,16,15,8,8,8,8])+dashaCards(periods)+'</div></div><footer class="sp-footer"><p><span data-astrologer-field="name"></span><span data-astrologer-field="mobile"></span><span data-astrologer-field="address"></span></p><p>KP MASTER · Krishnamurti Paddhati astrology report</p></footer></div>';
    const contact=[['name','astroName'],['mobile','astroMobile'],['address','astroAddress']].filter(([,id])=>value(id));
    contact.forEach(([field,id],index)=>{page.querySelector('[data-astrologer-field="'+field+'"]').textContent=(index?' · ':'')+value(id);});
    return page;
  }
  window.KPSinglePageReport=Object.freeze({render,panchang});
  function initialize(){window.renderReport?.();window.KPReportPages?.refresh();}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

