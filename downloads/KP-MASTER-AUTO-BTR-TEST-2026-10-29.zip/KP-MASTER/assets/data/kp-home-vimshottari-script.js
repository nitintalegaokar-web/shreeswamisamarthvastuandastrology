
(function(){
'use strict';
const byId=id=>document.getElementById(id),LEVELS=['MD','AD','PD','SD','PrD'],TITLES=['Mahadasha · Dasha','Antardasha · Bhukti','Pratyantardasha · Antara','Sookshma','Prana'];
const ORDER=typeof mdSeq!=='undefined'?[...mdSeq]:['केतू','शुक्र','रवी','चंद्र','मंगळ','राहू','गुरु','शनि','बुध'];
const YEARS=typeof mdLordYears!=='undefined'?{...mdLordYears}:{'केतू':7,'शुक्र':20,'रवी':6,'चंद्र':10,'मंगळ':7,'राहू':18,'गुरु':16,'शनि':19,'बुध':17};
const MS_DAY=86400000,ROMAN=['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];
let initialized=false,root=null,depth=0,path=[],periods=[],signature='',rotation=1,rotationSignature='',queued=false,renderingRotation=false;
const value=id=>String(byId(id)?.value||'');
function el(tag,text,cls){const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(cls)node.className=cls;return node;}
function civilDateValid(date){if(typeof mdValidDate==='function')return mdValidDate(date);return /^\d{4}-\d{2}-\d{2}$/.test(date)&&new Date(date+'T00:00:00Z').toISOString().slice(0,10)===date;}
function civilTimeValid(time){return /^\d{2}:\d{2}(?::\d{2})?$/.test(time)&&time.split(':').map(Number).every((n,i)=>Number.isFinite(n)&&n>=0&&n<(i===0?24:60));}
function standardOffset(){const text=value('stdLon').trim();const parts=text.replace(/^[+-]/,'').split(':').map(Number);if(!/^[+-]?\d+(?::\d+(?:\.\d+)?){0,2}$/.test(text)||!parts.every(Number.isFinite))return 5.5;const sign=text.startsWith('-')?-1:1;const hours=sign*((parts[0]||0)+(parts[1]||0)/60+(parts[2]||0)/3600)/15;return Math.abs(hours)<=14?hours:5.5;}
function civilMs(date,time='00:00:00'){if(!civilDateValid(date)||!civilTimeValid(time))return NaN;return new Date(date+'T'+(time.length===5?time+':00':time)+'Z').getTime();}
function localISO(ms){return Number.isFinite(ms)?new Date(ms).toISOString().slice(0,19):'';}
function exactOffset(date,time,offset){
 if(!Number.isFinite(offset)||!civilDateValid(date)||!civilTimeValid(time))return NaN;
 const sign=offset<0?-1:1,absolute=Math.abs(offset),whole=Math.floor(absolute+1e-10),fraction=absolute-whole;
 const years=Math.floor(whole/360),months=Math.floor((whole%360)/30),days=whole%30;
 const shifted=typeof mdAddYMD==='function'?mdAddYMD(date,sign*years,sign*months,sign*days):'';
 return shifted?civilMs(shifted,time)+sign*fraction*MS_DAY:NaN;
}
function generateMD(){
 const nativeDate=value('dob'),nativeTime=value('birthTime')||'00:00:00',source=window.mdDashaPeriods||[];
 if(!source.length||!civilDateValid(nativeDate)||!civilTimeValid(nativeTime))return [];
 let previousEnd=NaN;
 return source.map((p,index)=>{
  const totalDays=YEARS[p.lord]*360,elapsed=p.isBirth?Number(p.birthElapsedDays)||0:0;
  const remaining=p.isBirth?Number(p.birthRemainingDays):totalDays;
  const startMs=index===0?civilMs(nativeDate,nativeTime):previousEnd;
  const anchorDate=index===0?nativeDate:localISO(startMs).slice(0,10),anchorTime=index===0?nativeTime:localISO(startMs).slice(11,19);
  const endMs=exactOffset(anchorDate,anchorTime,p.isBirth?remaining:totalDays);
  previousEnd=endMs;
  return {level:0,lord:p.lord,key:p.key,index,sourceStart:p.start,sourceEnd:p.end,startMs,endMs,start:localISO(startMs),end:localISO(endMs),durationDays:totalDays,anchorDate,anchorTime,offsetDays:-elapsed,elapsedDays:elapsed,isBirth:Boolean(p.isBirth)};
 }).filter(p=>YEARS[p.lord]&&Number.isFinite(p.startMs)&&Number.isFinite(p.endMs)&&p.endMs>=p.startMs);
}
function subdivide(parent){
 if(!parent||parent.level>=4||!YEARS[parent.lord]||!Number.isFinite(parent.durationDays)||parent.durationDays<=0||!Number.isFinite(parent.startMs)||!Number.isFinite(parent.endMs))return [];
 const first=ORDER.indexOf(parent.lord);if(first<0)return [];
 let cumulative=0;
 const rows=ORDER.map((_,i)=>{
  const lord=ORDER[(first+i)%ORDER.length],durationDays=parent.durationDays*YEARS[lord]/120;
  const offsetDays=parent.offsetDays+cumulative;
  const startMs=i===0&&parent.level>0?parent.startMs:exactOffset(parent.anchorDate,parent.anchorTime,offsetDays);
  cumulative+=durationDays;
  const endMs=i===8?parent.endMs:exactOffset(parent.anchorDate,parent.anchorTime,parent.offsetDays+cumulative);
  return {level:parent.level+1,lord,key:parent.key+'/'+i,index:i,startMs,endMs,start:localISO(startMs),end:localISO(endMs),durationDays,anchorDate:parent.anchorDate,anchorTime:parent.anchorTime,offsetDays,elapsedDays:parent.elapsedDays,isBirth:parent.isBirth};
 });
 const fullStart=parent.level===0&&parent.isBirth?exactOffset(parent.anchorDate,parent.anchorTime,parent.offsetDays):parent.startMs;
 // mdAddYMD deliberately clamps anniversaries such as 31 January to 28 February.
 // Fine subdivisions straddling that clamp must still be ordered and contained
 // in their selected parent. Preserve parent boundaries and exact proportions.
 const calendarLinear=parent.calendarLinear||rows.some(row=>row.endMs<row.startMs-.001||row.startMs<fullStart-.001||row.endMs>parent.endMs+.001);
 if(calendarLinear){let offset=0;const span=parent.endMs-fullStart;rows.forEach((row,i)=>{row.startMs=fullStart+span*offset/parent.durationDays;offset+=row.durationDays;row.endMs=i===8?parent.endMs:fullStart+span*offset/parent.durationDays;row.start=localISO(row.startMs);row.end=localISO(row.endMs);row.calendarLinear=true;});}
 return rows;
}
function referenceMs(){return civilMs(value('home-dasha-date'),value('home-dasha-time'));}
function activeIndex(rows,ms){return rows.findIndex(p=>p.startMs<=ms&&ms<p.endMs);}
function levels(){const result=[periods];for(let d=1;d<5;d++){const selected=result[d-1]?.[path[d-1]];result.push(subdivide(selected));}return result;}
function selectReference(resetDepth=true){
 const ms=referenceMs();let rows=periods;const next=[];
 for(let d=0;d<5;d++){const index=activeIndex(rows,ms);if(index<0)break;next.push(index);rows=subdivide(rows[index]);}
 path=next.length?next:[0];if(resetDepth)depth=0;
 render();
}
function seedNow(){const date=new Date(Date.now()+standardOffset()*3600000);byId('home-dasha-date').value=date.toISOString().slice(0,10);byId('home-dasha-time').value=date.toISOString().slice(11,19);}
function prettyLord(lord){return window.KPDisplay?.idByName?.[lord]||lord;}
function formatDate(date){return window.KPPreferences?.isConfigured()?window.KPPreferences.formatDate(date):(typeof mdFmtDate==='function'?mdFmtDate(date):date);}
function formatTime(time){return window.KPPreferences?.isConfigured()?window.KPPreferences.formatTime(time):time;}
function render(){
 if(!root)return;
 const table=byId('home-dasha-table'),status=byId('home-dasha-status'),crumbs=byId('home-dasha-path');table.replaceChildren();crumbs.replaceChildren();
 const header=el('thead'),hr=el('tr');
 LEVELS.forEach((level,d)=>{const th=el('th'),button=el('button',level);button.type='button';button.dataset.dashaDepth=String(d);button.title=TITLES[d];button.disabled=d>path.length||d>0&&!path.slice(0,d).every((v,i)=>Number.isInteger(v)&&levels()[i]?.[v]);if(d===depth)button.setAttribute('aria-current','step');th.append(button);hr.append(th);});hr.append(el('th','Ending date / time'));header.append(hr);table.append(header);
 root.dataset.ready=String(periods.length>0);
 if(!periods.length){const body=el('tbody'),tr=el('tr'),td=el('td','Complete the birth date, birth time and calculated Moon position.');td.colSpan=6;td.style.whiteSpace='normal';tr.append(td);body.append(tr);table.append(body);status.textContent='Vimshottari periods appear after the Moon calculation is complete.';return;}
 const all=levels(),rows=all[depth]||[],ms=referenceMs();
 for(let d=0;d<depth;d++){const parent=all[d]?.[path[d]];if(!parent)continue;const button=el('button',LEVELS[d]+' '+prettyLord(parent.lord));button.type='button';button.dataset.dashaDepth=String(d);button.title='Return to '+TITLES[d];crumbs.append(button);}
 const body=el('tbody');rows.forEach((period,index)=>{
  const row=el('tr');row.dataset.dashaRow=String(index);row.dataset.dashaLevel=LEVELS[depth];row.dataset.dashaLord=period.lord;row.dataset.periodStart=period.start;row.dataset.periodEnd=period.end;row.dataset.durationDays=String(period.durationDays);row.classList.toggle('is-current',period.startMs<=ms&&ms<period.endMs);row.classList.toggle('is-selected',path[depth]===index);
  LEVELS.forEach((level,d)=>{const cell=el('td');if(d<depth)cell.textContent=prettyLord(all[d]?.[path[d]]?.lord||'');else if(d===depth){const button=el('button',prettyLord(period.lord),'home-vim-row-choice');button.type='button';button.dataset.dashaChoice=String(index);button.title=depth<4?'Show '+TITLES[depth+1]+' under '+period.lord:period.lord+' Prana';cell.append(button);}else cell.textContent='—';row.append(cell);});
  const end=el('td');end.append(el('span',formatDate(period.end.slice(0,10)),'home-vim-end-date'),el('span',formatTime(period.end.slice(11,19)),'home-vim-end-time'));end.title='Starts '+formatDate(period.start.slice(0,10))+' '+formatTime(period.start.slice(11,19));row.append(end);body.append(row);
 });table.append(body);
 const active=activeIndex(periods,ms);status.textContent=!Number.isFinite(ms)?'Enter a valid reference date and time.':active<0?'The selected time is outside this calculated MD timeline. Choose a listed period to explore.':TITLES[depth]+' · highlighted row is active at the selected time.';
 const birth=periods[0];byId('home-dasha-balance').textContent='Birth MD: '+prettyLord(birth.lord)+' · '+(value('mdBhogyaDuration')||'');
 byId('home-dasha-depth').textContent=depth<4?'Select a lord to open '+LEVELS[depth+1]+'.':'Prana · fifth level';
}
function refresh(){
 if(!initialized)return;
 const next=JSON.stringify({date:value('dob'),time:value('birthTime'),offset:value('stdLon'),periods:window.mdDashaPeriods||[]});
 if(next!==signature){signature=next;periods=generateMD();selectReference(true);}else render();
 applyRotation();
}
function getData(){const all=levels();return {ready:periods.length>0,referenceDate:value('home-dasha-date'),referenceTime:value('home-dasha-time'),timeZoneHours:standardOffset(),depth,level:LEVELS[depth],path:[...path],levels:all.map((rows,d)=>({level:LEVELS[d],selectedIndex:path[d]??null,rows:rows.map(p=>({...p}))})),rows:(all[depth]||[]).map(p=>({...p}))};}
function schedule(){if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;refresh();});}
function initialize(){
 if(initialized||!byId('home'))return;initialized=true;
 const oldCards=[byId('home-md')?.closest('.home-dasha-panel'),byId('home-ad')?.closest('.home-dasha-panel')];oldCards.forEach(card=>{if(card){card.classList.add('kp-dasha-replaced');card.setAttribute('aria-hidden','true');}});
 root=el('article',undefined,'home-panel');root.id='home-vimshottari';const heading=el('div',undefined,'home-panel-heading');heading.append(el('h2','Vimshottari Dasha'));root.append(heading);
 const controls=el('div',undefined,'home-vim-controls');const date=el('input'),time=el('input'),now=el('button','Now');date.type='date';date.id='home-dasha-date';date.setAttribute('aria-label','Vimshottari reference date');time.type='time';time.step='1';time.id='home-dasha-time';time.setAttribute('aria-label','Vimshottari reference time');now.type='button';now.id='home-dasha-now';controls.append(date,time,now);root.append(controls);
 const crumbs=el('div',undefined,'home-vim-path');crumbs.id='home-dasha-path';crumbs.setAttribute('aria-label','Dasha parent periods');root.append(crumbs);const table=el('table',undefined,'kp-table home-vim-table');table.id='home-dasha-table';table.setAttribute('aria-label','Vimshottari five-level periods');root.append(table);
 const status=el('p',undefined,'home-vim-status');status.id='home-dasha-status';status.setAttribute('role','status');root.append(status);
 const footer=el('div',undefined,'home-vim-footer'),balance=el('span'),detail=el('span');balance.id='home-dasha-balance';detail.id='home-dasha-depth';footer.append(balance,detail);root.append(footer);
 oldCards[0]?.before(root);if(!root.isConnected)byId('home').querySelector('.home-summary-column')?.prepend(root);
 root.addEventListener('click',event=>{if(event.detail>1){event.stopPropagation();return;}const row=event.target.closest('[data-dasha-row]'),back=event.target.closest('[data-dasha-depth]');if(event.target.closest('#home-dasha-now')){seedNow();selectReference();}else if(back&&!back.disabled){depth=Number(back.dataset.dashaDepth);render();}else if(row){path[depth]=Number(row.dataset.dashaRow);path=path.slice(0,depth+1);if(depth<4){depth++;const next=levels()[depth];path[depth]=Math.max(0,activeIndex(next,referenceMs()));}render();}event.stopPropagation();});
 root.addEventListener('change',event=>{event.stopPropagation();if(['home-dasha-date','home-dasha-time'].includes(event.target.id))selectReference();});root.addEventListener('input',event=>event.stopPropagation());
 seedNow();installRotation();
 const observer=new MutationObserver(schedule);['mdDashaRows','adDashaRows'].forEach(id=>{if(byId(id))observer.observe(byId(id),{childList:true,subtree:true,characterData:true});});
 ['chart-saved','chart-manual-change','kundali-style-changed','kp-ephemeris-ready','kp-preferences-changed'].forEach(name=>window.addEventListener(name,schedule));document.addEventListener('change',event=>{if(!event.target.closest('#home'))schedule();});
 const original=window.refreshHomeDashboard;if(typeof original==='function')window.refreshHomeDashboard=function(...args){const result=original.apply(this,args);schedule();return result;};
 refresh();
}
const NS='http://www.w3.org/2000/svg';
function svgNode(name,attributes,text){const node=document.createElementNS(NS,name);Object.entries(attributes||{}).forEach(([key,val])=>node.setAttribute(key,String(val)));if(text!==undefined)node.textContent=text;return node;}
const POLYGONS=[[[240,0],[360,120],[240,240],[120,120]],[[0,0],[240,0],[120,120]],[[0,0],[120,120],[0,240]],[[0,240],[120,120],[240,240],[120,360]],[[0,240],[120,360],[0,480]],[[0,480],[120,360],[240,480]],[[240,240],[360,360],[240,480],[120,360]],[[240,480],[360,360],[480,480]],[[360,360],[480,240],[480,480]],[[240,240],[360,120],[480,240],[360,360]],[[480,0],[480,240],[360,120]],[[240,0],[480,0],[360,120]]];
const CENTRES=[[240,120],[120,40],[40,120],[120,240],[40,360],[120,440],[240,360],[360,440],[440,360],[360,240],[440,120],[360,40]];
function horizontalBounds(polygon,y){const intersections=[];polygon.forEach((a,i)=>{const b=polygon[(i+1)%polygon.length];if(a[1]===b[1]){if(Math.abs(y-a[1])<1e-6)intersections.push(a[0],b[0]);}else if(y>=Math.min(a[1],b[1])&&y<=Math.max(a[1],b[1]))intersections.push(a[0]+(y-a[1])*(b[0]-a[0])/(b[1]-a[1]));});return [Math.min(...intersections),Math.max(...intersections)];}
function renderReferenceNorth(model,target){
 const reference=model.houses.find(h=>Number(h.id)===rotation),ascSign=reference?.signIndex;if(!Number.isInteger(ascSign))return;
 const sectors=Array.from({length:12},()=>({cusps:[],planets:[]}));model.houses.forEach(cusp=>sectors[(cusp.signIndex-ascSign+12)%12].cusps.push(cusp));const fortuna=window.KPFortuna?.getNatal();[...model.planets,...(fortuna?[fortuna]:[])].forEach(planet=>sectors[(planet.signIndex-ascSign+12)%12].planets.push(planet));
 const chart=el('div',undefined,'north9-chart');chart.dataset.homeChart='';chart.dataset.houseReference=String(rotation);const svg=svgNode('svg',{viewBox:'0 0 480 480',role:'img','aria-label':'North Indian kundali referenced to natal house '+rotation,preserveAspectRatio:'xMidYMid meet'});svg.append(svgNode('title',{},'North Indian kundali · natal house '+rotation+' as reference'),svgNode('rect',{x:1,y:1,width:478,height:478,fill:'#fff',stroke:'#a3a0b5','stroke-width':2}),svgNode('path',{d:'M0 0L480 480M480 0L0 480M240 0L480 240L240 480L0 240Z',fill:'none',stroke:'#b7b2c6','stroke-width':1.2}));
 sectors.forEach((sector,index)=>{const sign=(ascSign+index)%12+1,[,cy]=CENTRES[index],group=svgNode('g',{'data-sign':sign,'data-rashi-house':index+1});const labelY=cy-22,bounds=horizontalBounds(POLYGONS[index],labelY);group.append(svgNode('text',{x:(bounds[0]+bounds[1])/2,y:labelY,'text-anchor':'middle',fill:'#6c598d','font-size':11,'font-weight':650},sign+(index===0?' · Ref '+ROMAN[rotation-1]:'')));const count=Math.max(sector.cusps.length,sector.planets.length),lineHeight=Math.min(17,56/Math.max(1,count));
 function add(point,kind,row){const y=cy-5+row*lineHeight,b=horizontalBounds(POLYGONS[index],y-lineHeight/3),centre=(b[0]+b[1])/2,retro=kind==='planet'&&/R/i.test(value('p6_motion_'+point.index));const relative=kind==='cusp'?((Number(point.id)-rotation+12)%12)+1:null;const label=(kind==='cusp'?ROMAN[relative-1]:point.id)+(retro?'ᴿ':'')+' '+point.degree;const laneWidth=Math.max(5,(b[1]-b[0])/2-9),size=Math.min(10.5,lineHeight*.72,laneWidth/Math.max(1,label.length*.61));const attrs={x:kind==='cusp'?centre-4:centre+4,y,'text-anchor':kind==='cusp'?'end':'start',fill:kind==='cusp'?'#778ad0':'#597332','font-size':size,'font-weight':600,'data-longitude':point.longitude,'data-original-name':kind==='cusp'?ROMAN[Number(point.id)-1]:point.id,'data-original-degree':point.degree+(retro?' R':'')};attrs[kind==='cusp'?'data-cusp':'data-planet']=point.id;if(kind==='cusp')attrs['data-relative-house']=relative;const entry=svgNode('text',attrs,label);entry.append(svgNode('title',{},(kind==='cusp'?'Natal house '+ROMAN[Number(point.id)-1]:point.name)+' · '+point.sign+' '+point.degree));group.append(entry);}
 sector.cusps.forEach((point,row)=>add(point,'cusp',row));sector.planets.forEach((point,row)=>add(point,'planet',row));svg.append(group);});chart.append(svg);target.replaceChildren(chart);window.KPPreferences?.decorate(chart);window.KPTableFontSizes?.refresh();
 // Decoration uses source natal names, so restore just the relative cusp labels.
 chart.querySelectorAll('text[data-cusp]').forEach(node=>{const name=node.querySelector('[data-north-name]');if(name)name.textContent=referenceLabel(Number(node.dataset.relativeHouse));else if(node.childNodes[0]?.nodeType===3)node.childNodes[0].textContent=node.childNodes[0].textContent.replace(/^\S+/,referenceLabel(Number(node.dataset.relativeHouse)));});
}
function applyRotation(){
 if(renderingRotation)return;const target=byId('home-kundali'),model=window.currentKPModel;if(!target)return;renderingRotation=true;
 try{target.dataset.houseReference=String(rotation);const style=window.KPChartStyle?.getStyle()||'south';if(style==='north'&&model?.ready&&window.KPPairedNorth){KPPairedNorth.render(target,model,rotation);}else if(style==='north'&&rotation!==1&&model?.ready){const sig=JSON.stringify({rotation,style,model:model.houses.map(h=>[h.id,h.longitude]),planets:model.planets.map(p=>[p.id,p.longitude]),prefs:window.KPPreferences?.get(),html:target.firstElementChild?.dataset?.houseReference});if(sig!==rotationSignature||target.firstElementChild?.dataset?.houseReference!==String(rotation)){rotationSignature=sig;renderReferenceNorth(model,target);}}else if(style==='south'){target.querySelectorAll('.v38-cusp[data-cusp]').forEach(node=>{const natal=Number(node.dataset.cusp),relative=(natal-rotation+12)%12+1,label=node.querySelector('.v38-name');node.dataset.relativeHouse=String(relative);if(label&&label.textContent!==referenceLabel(relative))label.textContent=referenceLabel(relative);node.title='Relative house '+ROMAN[relative-1]+' · natal house '+ROMAN[natal-1];});}
 const caption=byId('home-chart-reference-note');if(caption)caption.textContent=rotation===1?'Natal chart':'House '+ROMAN[rotation-1]+' as reference';
 }finally{renderingRotation=false;}
}
function referenceLabel(number){return window.KPPreferences?.get()?.houseNotation==='numeric'?String(number):ROMAN[number-1];}
function setRotation(house){const n=Number(house);if(!Number.isInteger(n)||n<1||n>12)return false;rotation=n;rotationSignature='';byId('home-chart-reference').value=String(n);window.KPHomeDashboard?.refresh();applyRotation();window.KPRelativeSignificators?.refresh();return true;}
function installRotation(){const heading=byId('home-kundali')?.closest('.home-panel')?.querySelector('.home-panel-heading');if(!heading)return;const controls=el('div',undefined,'home-chart-reference-controls'),button=el('button','Rotate chart'),select=el('select'),note=el('span','Natal chart');button.type='button';button.id='home-rotate-button';button.setAttribute('aria-expanded','false');select.id='home-chart-reference';select.hidden=true;select.setAttribute('aria-label','Reference natal house for chart');for(let i=1;i<=12;i++){const option=el('option','House '+ROMAN[i-1]);option.value=String(i);select.append(option);}note.id='home-chart-reference-note';controls.append(button,select,note);heading.after(controls);button.addEventListener('click',event=>{event.stopPropagation();select.hidden=!select.hidden;button.setAttribute('aria-expanded',String(!select.hidden));if(!select.hidden)select.focus();});select.addEventListener('change',event=>{event.stopPropagation();setRotation(select.value);});
 const observer=new MutationObserver(()=>{if(!renderingRotation)requestAnimationFrame(applyRotation);});observer.observe(byId('home-kundali'),{childList:true,subtree:true});
}
window.KPHomeDasha=Object.freeze({refresh,getData,subdivide,exactOffset,selectReference,now:()=>{seedNow();selectReference();},setDepth:d=>{if(Number.isInteger(d)&&d>=0&&d<5&&(d===0||levels()[d]?.length)){depth=d;render();return true;}return false;}});
window.KPHomeChartReference=Object.freeze({getHouse:()=>rotation,setHouse:setRotation,refresh:applyRotation});
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

