
(()=>{'use strict';let individualPreview=false;const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function complete(){
 const api=window.KPPersonalPredictions;if(!api)return window.KPPrediction?.snapshot?.()||'<p>Prediction data is unavailable.</p>';
 const tabs=[...document.querySelectorAll('#pred-subtabs [data-pred-tab]')].filter(button=>button.dataset.predTab!=='analysis'),sections=[];
 for(const button of tabs){const category=button.dataset.predTab;let data;try{data=api.matchRules(category);}catch(error){data={ready:false,reason:error.message,rows:[]};}
  if(!data?.ready||!data.rows?.length)continue;sections.push('<section data-prediction-category="'+esc(category)+'"><h2>'+esc(button.textContent.trim())+' · '+data.rows.length+'</h2>'+data.rows.map(row=>'<article data-prediction-result="'+esc(row.id||row.key||'matched')+'">'+(row.title&&row.title!==row.text?'<h3>'+esc(row.title)+'</h3>':'')+'<p>'+esc(row.text||row.value||row.title||'')+'</p>'+(row.proof?'<p class="prediction-proof">'+esc(row.proof)+'</p>':'')+'</article>').join('')+'</section>');
 }
 const name=document.getElementById('name')?.value||'—',dob=document.getElementById('dob')?.value||'—';return '<div class="prediction-complete-report"><p><strong>Native:</strong> '+esc(name)+' · '+esc(dob)+'</p><p>Automatically collected kundali-matched prediction results from every available Prediction section.</p>'+sections.join('')+(sections.length?'':'<p>No matching prediction results are available for this kundali.</p>')+'</div>';
}
function install(){
 const render=window.renderReport;if(render)window.renderReport=function(...args){const result=render.apply(this,args);if(!individualPreview){const cover=document.querySelector('#printReport>[data-report-section="prediction"]>.report-cover');if(cover)cover.innerHTML=complete();}return result;};window.renderReport?.();
 const old=window.KPReportPreview;if(!old)return false;window.KPReportPreview=Object.freeze({...old,open(id){if(id!=='prediction')return old.open(id);individualPreview=true;try{return old.open(id);}finally{individualPreview=false;}}});return true;
}
let tries=0;const timer=setInterval(()=>{if(install()||++tries>50)clearInterval(timer);},25);
})();

