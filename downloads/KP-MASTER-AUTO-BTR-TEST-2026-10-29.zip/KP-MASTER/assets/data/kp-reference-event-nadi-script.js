
(() => {
  'use strict';
  const get=id=>document.getElementById(id);
  const make=(tag,cls,text)=>{const node=document.createElement(tag);if(cls)node.className=cls;if(text)node.textContent=text;return node;};
  const group=(parent,id)=>{const input=get(id),wrapper=input?.closest('.ep-controls>div,.na-controls>div');if(wrapper)parent.append(wrapper);};
  function eventWindow(){
    const card=document.querySelector('#event-promise .ep-card');if(!card||card.dataset.referenceLayout)return false;
    card.dataset.referenceLayout='event-promise';
    const originalControls=card.querySelector('.ep-controls'),actions=card.querySelector('.ep-actions');
    const windowGrid=make('div','ep-ref-window'),left=make('div','ep-ref-left'),right=make('div','ep-ref-right');
    const groups=make('div','ep-ref-groups');['ep-cusp','ep-favorable','ep-neutral','ep-opposed'].forEach(id=>group(groups,id));
    const analysis=make('div','ep-ref-analysis'),methods=make('div','ep-ref-methods');['ep-input-mode','ep-method'].forEach(id=>group(methods,id));
    const options=make('div','ep-ref-options');actions?.querySelectorAll('label').forEach(node=>options.append(node));
    analysis.append(methods,options,make('h3','', 'Significator of Cusps'),get('ep-layer-mount'));
    const combined=make('div','ep-ref-combined'),values=make('div');values.id='ep-ref-combined';values.setAttribute('aria-label','Combined significator houses');combined.append(make('span','', 'Combined Significators'),values);analysis.append(combined);
    const footer=make('div','ep-ref-footer');actions?.querySelectorAll('button').forEach(node=>footer.append(node));
    left.append(groups,analysis,footer,get('ep-status'));const legend=card.querySelector('.ep-legend');if(legend)left.append(legend);
    const eventControls=make('div','ep-ref-event-controls');['ep-category','ep-search','ep-event','ep-custom-houses'].forEach(id=>group(eventControls,id));right.append(eventControls,get('ep-source-mount'),get('ep-proof-mount'));
    windowGrid.append(left,right);card.append(windowGrid);originalControls?.remove();actions?.remove();
    const synchronizeCombined=()=>{const dt=[...get('ep-proof-mount').querySelectorAll('dt')].find(node=>node.textContent.trim()==='Combined houses');values.innerHTML=dt?.nextElementSibling?.innerHTML||'—';};
    new MutationObserver(synchronizeCombined).observe(get('ep-proof-mount'),{childList:true,subtree:true});synchronizeCombined();return true;
  }
  function nadiWindow(){
    const card=document.querySelector('#nadi-astrology .na-card');if(!card||card.dataset.referenceLayout)return false;
    card.dataset.referenceLayout='nadi-astrology';
    const oldControls=card.querySelector('.na-controls'),oldLayout=card.querySelector('.na-layout'),oldActions=card.querySelector('.na-actions');
    const windowGrid=make('div','na-ref-window'),positions=make('div','na-ref-positions'),chart=make('div','na-ref-chart'),controls=make('div','na-ref-controls'),coordinates=make('div','na-ref-coordinates'),criteria=make('div','na-ref-criteria'),notes=make('div','na-ref-notes');
    const tableDetails=get('na-positions')?.closest('details');if(tableDetails){tableDetails.open=true;positions.append(make('h3','', 'PLANETARY POSITION'),tableDetails);}
    chart.append(make('h3','', 'NATAL RASHI CHART'),get('na-native-chart'),get('na-native-info'));
    const inputGroups=make('div','na-ref-inputs');['na-source','na-method','na-cusp-source','na-date','na-time','na-timezone','na-place','na-latitude','na-longitude'].forEach(id=>group(inputGroups,id));oldControls?.querySelectorAll('.kp-india-picker').forEach(panel=>inputGroups.append(panel));controls.append(make('h3','', 'Time Slice and Chart Inputs'),inputGroups);
    const step=make('div','na-ref-step'),count=get('na-step-count')?.closest('label');if(count)step.append(count);['na-step','na-backward','na-forward','na-real-time'].forEach(id=>{if(get(id))step.append(get(id));});controls.append(step);
    const buttons=make('div','na-ref-buttons');['na-update','na-use-native','na-open-transit'].forEach(id=>{if(get(id))buttons.append(get(id));});controls.append(buttons,get('na-status'));
    const query=make('div','na-ref-query');['na-category','na-search','na-event','na-custom-houses'].forEach(id=>group(query,id));coordinates.append(make('h3','', 'Nadi Co-ordinates'),query,get('na-grid'));
    notes.append(make('h3','', 'Event Notes'),get('na-notes'));const noteIntro=card.querySelector('.na-side .na-intro');if(noteIntro)notes.append(noteIntro);
    criteria.append(get('na-source-mount'));windowGrid.append(positions,chart,controls,coordinates,criteria,notes);card.append(windowGrid);oldControls?.remove();oldActions?.remove();oldLayout?.remove();
    const sourceChart=get('kundali'),destination=get('na-native-chart');
    const synchronizeChart=()=>{if(!sourceChart||!destination||destination.dataset.selectedNadiChart==='true')return;const clone=sourceChart.cloneNode(true);[clone,...clone.querySelectorAll('[id]')].forEach(node=>node.removeAttribute('id'));clone.dataset.reportId='kundali';clone.dataset.nadiNativeChart='true';clone.removeAttribute('tabindex');clone.querySelectorAll('[contenteditable]').forEach(node=>{node.removeAttribute('contenteditable');node.setAttribute('aria-readonly','true');});destination.replaceChildren(clone);};
    if(sourceChart){new MutationObserver(synchronizeChart).observe(sourceChart,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['class']});synchronizeChart();}
    const compactCoordinateDetails=()=>{get('na-grid').querySelectorAll('.na-tile:not([data-reference-trace])').forEach(tile=>{tile.dataset.referenceTrace='true';const details=make('details','na-ref-trace');details.append(make('summary','', 'Calculation details'));const metadata=tile.querySelector(':scope>small');if(metadata)details.append(metadata);tile.querySelectorAll('.na-layer').forEach(layer=>{const level=layer.querySelector(':scope>small');if(!level)return;const row=make('div','na-ref-trace-row');row.append(make('b','',(layer.querySelector(':scope>span')?.textContent||'')+' '+(layer.querySelector(':scope>strong')?.textContent||'')),level);details.append(row);});const match=tile.querySelector('.na-match');if(match)details.append(match);tile.append(details);});};
    new MutationObserver(compactCoordinateDetails).observe(get('na-grid'),{childList:true,subtree:true});compactCoordinateDetails();return true;
  }
  function initialize(){eventWindow();nadiWindow();}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

