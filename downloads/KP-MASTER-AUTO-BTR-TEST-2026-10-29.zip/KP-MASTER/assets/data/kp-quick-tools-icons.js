
(()=>{'use strict';
// Inline SVGs keep navigation icons available offline and independent of symbol fonts.
const icons={
 tutorial:['TUT','<path d="m2 7 10-4 10 4-10 4ZM6 9v6c4 3 8 3 12 0V9M22 7v8M6 21h12"/>'],
 home:['HOME','<path d="m3 10 9-7 9 7v10H7v-9h10v9"/>'],
 basic:['BD','<circle cx="12" cy="7" r="4"/><path d="M4 21v-3a8 8 0 0 1 16 0v3"/>'],
 'basic-information':['BI','<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 7h8M8 12h8M8 17h5"/>'],
 'admin-calculations':['ADM','<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M7 10V6a5 5 0 0 1 10 0v4"/>'],
 ayan:['LON','<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>'],
 lmt:['LMT','<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2M3 3l2 2"/>'],
 stcalc:['ST','<circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2m-2-14 .8 2.5H16l-1.8 1.5.7 2.5L13 6l-1.9 1.5.7-2.5L10 3.5h2.2Z"/>'],
 raphael5:['RH','<rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18"/>'],
 planet:['PP','<circle cx="12" cy="12" r="4"/><ellipse cx="12" cy="12" rx="11" ry="5" transform="rotate(-30 12 12)"/><circle cx="18" cy="4" r="1"/>'],
 mdcalc:['DBA','<path d="M5 3v18M5 6h5m-5 6h5m-5 6h5"/><rect x="10" y="3" width="11" height="5" rx="1"/><rect x="10" y="10" width="9" height="5" rx="1"/><rect x="10" y="17" width="7" height="4" rx="1"/>'],
 karyesh:['SIG','<path d="M3 5h18M3 12h18M3 19h18M8 3v18M15 3v18"/>'],
 'education-profession':['E&P','<path d="m2 7 10-4 10 4-10 4ZM6 9v5c4 3 8 3 12 0V9M22 7v6"/><rect x="7" y="17" width="10" height="5" rx="1"/><path d="M10 17v-2h4v2"/>'],
 disease:['HLTH','<path d="M8 3H3v6a5 5 0 0 0 10 0V3h-3M8 14v3a4 4 0 0 0 8 0v-3"/><circle cx="17" cy="11" r="3"/>'],
 'dasha-promise':['DP','<circle cx="10" cy="10" r="7"/><path d="M10 6v4l3 2m1 6 3 3 5-7"/>'],
 prediction:['PRED','<rect x="3" y="3" width="15" height="18" rx="1"/><path d="M7 7h7M7 11h7M7 16l2 2 6-6m3 7h3"/>'],
 muhurta:['MUH','<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18"/><circle cx="12" cy="15" r="3"/><path d="M12 13v2l2 1"/>'],
 'event-promise':['EP','<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18m-14 5 3 3 7-5"/>'],
 'nadi-astrology':['NA','<circle cx="4" cy="7" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="20" cy="17" r="2"/><path d="m6 8 4 3m4 2 4 3M3 19h6M15 5h6"/>'],
 'ruling-planets':['RP','<path d="m3 7 4 4 5-8 5 8 4-4-2 11H5ZM5 21h14"/>'],
 matchmaking:['MATCH','<path d="M12 20S2 14 2 8c0-5 7-6 10-1 3-5 10-4 10 1 0 6-10 12-10 12Z"/>'],
 aspects:['ASP','<path d="M3 21V3m0 18h18M3 21 18 6M3 14a7 7 0 0 1 5 2"/>'],
 transit:['TR','<circle cx="7" cy="17" r="3"/><path d="m9 15 12-12M14 3h7v7M3 3v6h6"/>'],
 'transit-chart':['TC','<path d="m12 2 10 10-10 10L2 12ZM7 7l10 10M7 17 17 7"/>'],
 'transit-panchang':['TP','<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18m11 3c-4 4 0 7 3 5-5 0-2-5-3-5Z"/>'],
 ephemeris:['EPH','<path d="M3 3h18v18H3ZM3 9h18M3 15h18M9 3v18M15 3v18"/><circle cx="6" cy="6" r="1"/>'],
 'hit-theory':['HIT','<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 1v6M12 17v6M1 12h6M17 12h6"/>'],
 'vedic-kundali':['VED','<rect x="2" y="2" width="20" height="20"/><path d="m12 2 10 10-10 10L2 12ZM2 2l20 20M2 22 22 2"/>'],
 south9:['SI','<rect x="2" y="2" width="20" height="20"/><path d="M2 7h20M2 17h20M7 2v20M17 2v20"/>'],
 resources:['RES','<path d="M12 5C8 2 4 3 2 4v16c4-2 7-1 10 1 3-2 6-3 10-1V4c-2-1-6-2-10 1ZM12 5v16M5 7h4M5 11h4M15 7h4M15 11h4"/>'],
 report:['RPT','<path d="M6 9V3h12v6M6 17H3v-7h18v7h-3M6 14h12v7H6ZM16 11h2"/>'],
 about:['INFO','<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>'],
 astrosettings:['SET','<path d="M4 3v18M12 3v18M20 3v18M1 8h6M9 16h6M17 6h6"/><circle cx="4" cy="8" r="2"/><circle cx="12" cy="16" r="2"/><circle cx="20" cy="6" r="2"/>'],
 notepad:['NOTE','<path d="M12 3H3v18h18v-9M8 16l1-5L19 1l4 4-10 10ZM17 3l4 4"/>']
};
function decorate(button,tab,fullName){const entry=icons[tab];if(!entry)return;
 button.replaceChildren();button.dataset.quickFunction=tab;
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('aria-hidden','true');svg.setAttribute('focusable','false');svg.classList.add('kp-quick-icon');svg.innerHTML=entry[1];
 const label=document.createElement('span');label.className='kp-quick-label';label.textContent=entry[0];button.append(svg,label);button.title=fullName+' ('+entry[0]+')';button.setAttribute('aria-label',fullName);
}
window.KPQuickTools={decorate};
})();

