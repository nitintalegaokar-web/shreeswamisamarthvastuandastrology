
(()=>{'use strict';const $=id=>document.getElementById(id),events=KPHandbook.getCatalogue().events;const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function currentRule(prefix){return events.find(e=>String(e.id)===$(prefix+'-event')?.value);}
function sync(prefix){const e=currentRule(prefix);if(!e)return;if(prefix==='ep'){$('ep-cusp').value=String(e.mainHouses[0]);window.KPEventPromise.refresh();}else window.KPNadiAstrology.refresh();}
function selection(prefix){const select=document.createElement('select');select.id=prefix+'-handbook-event';select.setAttribute('aria-label','KP handbook event');select.append(new Option('Select handbook event',''));events.forEach(e=>select.append(new Option(e.category+' · '+e.event.en+' · cusp '+e.mainHouses[0],String(e.id))));return select;}
function init(){['ep','na'].forEach(prefix=>$(prefix+'-event')?.addEventListener('change',()=>sync(prefix)));
const transit=$('transit');if(transit){const panel=document.createElement('details');panel.innerHTML='<summary>Use KP handbook event houses</summary>';const select=selection('tr');panel.append(select);transit.querySelector('.tr-card')?.append(panel);select.addEventListener('change',()=>{const e=events.find(e=>String(e.id)===select.value);if(!e)return;const houses=$('tr-houses');houses.value=e.relevantHouses.join(',');houses.dispatchEvent(new Event('change',{bubbles:true}));});}
}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();})();

