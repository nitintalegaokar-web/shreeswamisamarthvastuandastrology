
(function(){
  window.parseTimeToSeconds = window.parseTimeToSeconds || function(v){
    if(v===null || v===undefined || v==="") return 0;
    if(typeof v === "number" && Number.isFinite(v)) return v;
    const p=String(v).trim().split(":").map(Number);
    return (p[0]||0)*3600+(p[1]||0)*60+(p[2]||0);
  };
  window.secondsToHms24 = window.secondsToHms24 || function(total){
    total=Math.round(Number(total)||0);
    const h=Math.floor(total/3600);
    const m=Math.floor((total%3600)/60);
    const s=total%60;
    return String(h).padStart(2,"0")+":"+String(m).padStart(2,"0")+":"+String(s).padStart(2,"0");
  };
  window.secondsToHms = window.secondsToHms || window.secondsToHMS || function(total){
    return window.secondsToHms24(total);
  };
})();

