
(()=>{const init=()=>{const p=document.createElement('p');p.className='am-orb-note';p.textContent='Supplied book table: conjunction ±6°, semisextile ±2°, semisquare ±2°, sextile ±3°, square/trine ±5°, sesquiquadrate/quincunx ±2°; quintile group 18°/24°/36°/72°/108° ±2°, 144° ±3°. Opposition retains its configured limit pending clarification. Applying/separating ranges are not inferred from static longitude differences.';document.querySelector('#aspects .am-advanced')?.prepend(p);};if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();})();

