
/* v29 overrides: Tab 8 refresh + exact KP significator tables + reference South Indian chart */
(function(){
  const P9=["रवी","चंद्र","मंगळ","बुध","गुरु","शुक्र","शनि","राहू","केतू"];
  const GP9=["रवी","चंद्र","मंगळ","राहू","गुरु","शनि","बुध","केतू","शुक्र"];
  const R9=["मेष","वृषभ","मिथुन","कर्क","सिंह","कन्या","तुळ","वृश्चिक","धनु","मकर","कुंभ","मीन"];
  const SL9={"मेष":"मंगळ","वृषभ":"शुक्र","मिथुन":"बुध","कर्क":"चंद्र","सिंह":"रवी","कन्या":"बुध","तुळ":"शुक्र","वृश्चिक":"मंगळ","धनु":"गुरु","मकर":"शनि","कुंभ":"शनि","मीन":"गुरु"};
  const VL9={"केतू":7,"शुक्र":20,"रवी":6,"चंद्र":10,"मंगळ":7,"राहू":18,"गुरु":16,"शनि":19,"बुध":17};
  const KO9=["केतू","शुक्र","रवी","चंद्र","मंगळ","राहू","गुरु","शनि","बुध"];
  const canon=x=>({"राहु":"राहू","केतु":"केतू"}[String(x||"").trim()]||String(x||"").trim());
  const norm=x=>((Number(x)||0)%1296000+1296000)%1296000;
  const signIndex=x=>Math.min(11,Math.floor(norm(x)/108000));
  const starLord=x=>KO9[Math.min(26,Math.floor(norm(x)/48000))%9];
  function subLord(x){const a=norm(x), n=Math.min(26,Math.floor(a/48000)), w=a-n*48000, s=KO9[n%9], st=KO9.indexOf(s); let acc=0; for(let j=0;j<9;j++){const l=KO9[(st+j)%9], span=48000*VL9[l]/120; if(w<acc+span||j===8)return l; acc+=span;} return s;}
  function houseOf(cusps,lon){const x=norm(lon); for(let h=1;h<=12;h++){const a=norm(cusps[h-1]), b=norm(cusps[h%12]), span=norm(b-a), rel=norm(x-a); if(rel<span || (span===0&&rel===0))return h;} return 12;}
  function worksheetDms(value){
    const text=String(value??'').replace(/\s*R\s*$/i,'').trim();
    const match=/^(\d{1,3}):([0-5]?\d):([0-5]?\d)$/.exec(text);
    return match ? Number(match[1])*3600+Number(match[2])*60+Number(match[3]) : NaN;
  }
  function syncWorksheetPositions(){
    if(typeof window.updatePlanet6Automatic==='function')window.updatePlanet6Automatic();
    window.KPHorary?.apply();
    window.KPDefaultLocation?.writeInstantCusps();
    // The current worksheets are authoritative: their calculators can update
    // these fields without rebuilding the older global chart caches.
    const cusps=Array(12).fill(null), lp={};
    [10,11,12,1,2,3].forEach(h=>{
      const lon=worksheetDms(document.getElementById('r5_nirayan_'+h)?.value);
      if(!Number.isFinite(lon)||lon>=1296000)return;
      cusps[h-1]=lon;
      cusps[(h+5)%12]=norm(lon+648000);
    });
    P9.slice(0,8).forEach((p,i)=>{
      const degree=worksheetDms(document.getElementById('p6_final_'+i)?.value);
      const sign=String(document.getElementById('p6_rashi_'+i)?.value||'').trim().replace(/^तुला$/,'तुळ');
      const si=R9.indexOf(sign);
      if(si>=0&&Number.isFinite(degree)&&degree<108000)lp[p]=si*108000+degree;
    });
    if(Object.hasOwn(lp,'राहू'))lp['केतू']=norm(lp['राहू']+648000);
    if(document.getElementById('chart-kind')?.value==='horary'){
      const horary=window.KPHorary?.getData();
      for(let i=0;i<12;i++)cusps[i]=horary?.cusps?.[i]!==undefined?horary.cusps[i]*3600:null;
      const exact=window.KPHorary?.applyPlanets();
      for(const key of Object.keys(lp))delete lp[key];
      Object.assign(lp,exact||{});
    }
    window.cuspResults=cusps.map((nir,i)=>({i:i+1,nir,rashi:nir===null?'':R9[signIndex(nir)]}));
    window.lastPlanetPositions=lp;
    return {cusps,lp};
  }
  window.syncKPWorksheetPositions=syncWorksheetPositions;
  function getData(){
    const {cusps,lp}=syncWorksheetPositions();
    if(cusps.some(x=>x===null)||Object.keys(lp).length!==9)return null;
    const pd={};
    P9.forEach(p=>{const lon=Number(lp[p]);if(!Number.isFinite(lon))return; const n=norm(lon), si=signIndex(n);pd[p]={lon:n,house:houseOf(cusps,n),signLord:SL9[R9[si]],starLord:starLord(n),sublord:subLord(n)};});
    if(Object.keys(pd).length!==9)return null;
    const H={}; for(let h=1;h<=12;h++){const c=norm(cusps[h-1]),sg=R9[signIndex(c)];H[h]={cusp:c,sign:sg,owner:SL9[sg],starLord:starLord(c),sublord:subLord(c),occupants:[]};}
    Object.entries(pd).forEach(([p,d])=>{H[d.house].occupants.push(p);});
    const owned={};P9.forEach(p=>owned[p]=[]); for(let h=1;h<=12;h++){const o=canon(H[h].owner);if(owned[o])owned[o].push(h);}
    const sig={};
    P9.forEach(p=>{
      const d=pd[p], out=new Set(), sl=canon(d.starLord);
      // KP hierarchy: star lord's occupied houses, then star lord's owned houses,
      // then planet's occupied house and owned houses.
      if(sl){Object.entries(H).forEach(([hs,hd])=>{if(hd.occupants.includes(sl))out.add(Number(hs));});(owned[sl]||[]).forEach(h=>out.add(h));}
      out.add(d.house);(owned[p]||[]).forEach(h=>out.add(h));
      // Rahu/Ketu additionally represent their sign-lord's occupied/owned houses.
      if(p==='राहू'||p==='केतू'){const rl=canon(d.signLord);if(rl){Object.entries(H).forEach(([hs,hd])=>{if(hd.occupants.includes(rl))out.add(Number(hs));});(owned[rl]||[]).forEach(h=>out.add(h));}}
      sig[p]=out;
    });
    const byH={};for(let h=1;h<=12;h++)byH[h]=P9.filter(p=>sig[p].has(h));
    const subH={};for(let h=1;h<=12;h++){const s=canon(H[h].sublord);subH[h]=s&&sig[s]?[...sig[s]]:[];}
    const subP={};P9.forEach(p=>{const s=canon(pd[p].sublord);subP[p]=s&&sig[s]?[...sig[s]]:[];});
    return {cusps,pd,H,sig,byH,subH,subP};
  }
  const set=(id,v)=>{const e=document.getElementById(id);if(e)e.value=v||"—";};
  const list=v=>[...(v||[])].sort((a,b)=>a-b).join(", ");
  window.updateKaryeshTables=function(){
    const d=getData();
    for(let h=1;h<=12;h++)set('karyesh_bhava_graha_'+h,d?d.byH[h].join(", "):"");
    GP9.forEach((p,i)=>set('karyesh_graha_bhava_'+(i+1),d?list(d.sig[p]):""));
    for(let h=1;h<=12;h++)set('karyesh_sublord_bhava_'+h,d?list(d.subH[h]):"");
    GP9.forEach((p,i)=>set('karyesh_sublord_graha_'+(i+1),d?list(d.subP[p]):""));
    const page=document.querySelector('#karyesh .karyesh-page');
    let note=page?.querySelector('.karyesh-note');
    if(page&&!note){note=document.createElement('div');note.className='karyesh-note';note.setAttribute('role','status');note.setAttribute('aria-live','polite');page.prepend(note);}
    if(note)note.innerHTML=d?'✓ <b>कार्येश गणना पूर्ण.</b> Tab 5 निरयन भाव व Tab 6 निरयन ग्रहस्थितीवरून ४ही कार्येश तक्ते automatic भरले आहेत.':'<b>कार्येश गणनेसाठी माहिती अपूर्ण आहे.</b> Tab 5 मधील सर्व भाव व Tab 6 मधील सर्व ९ ग्रहांची माहिती भरा. माहिती पूर्ण झाल्यावर ४ही तक्ते automatic भरतील.';
  };
  function localDms(sec){sec=Math.round(norm(sec));let d=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;return d+'°'+String(m).padStart(2,'0')+'′'+String(s).padStart(2,'0')+'″';}
  function planetLocal(lon){return localDms(norm(lon)%108000);}
  function buildEntries(){
    const boxes=Array.from({length:12},()=>[]), cr=Array.isArray(window.cuspResults)?window.cuspResults:[], lp=window.lastPlanetPositions||{};
    cr.forEach(x=>{const n=x&&x.nir!=null&&x.nir!==""?Number(x.nir):NaN;if(Number.isFinite(n)){const i=signIndex(n);boxes[i].push({type:'cusp',text:'भाव '+x.i+' — '+planetLocal(n)});}});
    P9.forEach((p,i)=>{let n=Number(lp[p]);if(!Number.isFinite(n)){const e=document.getElementById('p6_final_'+i);if(e&&e.value)n=parseDmsAny(e.value.replace(/\s*R\s*$/,''));}if(Number.isFinite(n)){const idx=signIndex(n), retro=(document.getElementById('p6_motion_'+i)?.value||'').includes('R');boxes[idx].push({type:'planet',text:p+' — '+planetLocal(n)+(retro?' R':'')});}});
    boxes.forEach(b=>b.sort((a,b)=>parseFloat(a.text.match(/(\d+)/)?.[1]||0)-parseFloat(b.text.match(/(\d+)/)?.[1]||0)));
    return boxes;
  }
  window.renderChart=function(force=false){
    if(window.kundaliManual&&!force)return;
    const chart=document.getElementById('kundali');if(!chart)return;
    chart.className='south9-chart v29-chart';
    const boxes=buildEntries();
    const pos={11:[1,1],0:[1,2],1:[1,3],2:[1,4],3:[2,4],4:[3,4],5:[4,4],6:[4,3],7:[4,2],8:[4,1],9:[3,1],10:[2,1]};
    let out='';
    for(let i=0;i<12;i++){const rc=pos[i], entries=boxes[i].map(e=>'<div class="v29-entry '+(e.type==='cusp'?'v29-cusp':'v29-planet')+'">'+e.text+'</div>').join('');out+='<div class="s9-cell" style="grid-row:'+rc[0]+';grid-column:'+rc[1]+'">'+entries+'</div>';}
    const val=id=>document.getElementById(id)?.value||'';
    const lag=(window.cuspResults||[]).find(x=>x.i===1); let lagTxt='';
    if(lag&&lag.nir!=null&&lag.nir!==""&&Number.isFinite(Number(lag.nir)))lagTxt='<div><b>लग्न अंश:</b> '+planetLocal(lag.nir)+'</div>';
    out+='<div class="s9-center"><div style="width:100%"><div class="s9-center-title">कृष्णमूर्ती पद्धतीची लग्न व भावचलित कुंडली</div><div class="s9-data"><b>नाव:</b> '+val('name')+'<br><b>जन्मतारीख:</b> '+val('dob')+'<br><b>जन्मवेळ:</b> '+val('birthTime')+'<br><b>अक्षांश:</b> '+val('lat')+'<br><b>रेखांश:</b> '+val('lon')+'<br><b>जन्मवेळी असलेली भोग्य महादशा:</b> '+val('mdBirthDasha')+(val('mdBhogyaDuration')?' — '+val('mdBhogyaDuration'):'')+lagTxt+'</div></div></div>';
    // Rashi names intentionally hidden; the fixed South-Indian boxes remain in place.
    out+='';
    chart.innerHTML=out;
    const cv=document.getElementById('chartAscValidation');if(cv)cv.innerHTML=lag?'<b>लग्न अंश:</b> '+planetLocal(lag.nir):'रॅफेल टेबलची निरयन भावस्थिती उपलब्ध झाल्यावर कुंडली automatic भरेल.';
  };
  // Re-run Tab 8 and Tab 9 after all original calculations have populated their globals.
  function v29Refresh(){try{if(typeof updateKaryeshTables==='function')updateKaryeshTables();if(typeof renderChart==='function')renderChart(true);}catch(e){console.error('v29 refresh',e);}}
  let refreshTimer, pendingRaphaelUpdate=false;
  function scheduleRefresh(event){
    if(!event.target?.closest('#basic,#ayan,#lmt,#stcalc,#raphael5,#planet'))return;
    pendingRaphaelUpdate=pendingRaphaelUpdate||Boolean(event.target.closest('#basic,#ayan,#lmt,#stcalc'));
    clearTimeout(refreshTimer);
    // Existing worksheet handlers run synchronously or on a zero-delay timer.
    // Read their final outputs once they have settled, for input and change alike.
    refreshTimer=setTimeout(()=>{
      if(pendingRaphaelUpdate&&typeof updateRaphaelTable5==='function')updateRaphaelTable5();
      pendingRaphaelUpdate=false;
      v29Refresh();
    },80);
  }
  document.addEventListener('DOMContentLoaded',()=>{
    setTimeout(v29Refresh,150);setTimeout(v29Refresh,600);setTimeout(v29Refresh,1200);
    document.addEventListener('input',scheduleRefresh);
    document.addEventListener('change',scheduleRefresh);
    window.addEventListener('chart-saved',event=>{if(event.detail?.action==='loaded')v29Refresh();});
    document.querySelectorAll('nav button[data-tab]').forEach(b=>b.addEventListener('click',()=>{if(['karyesh','south9'].includes(b.dataset.tab)){setTimeout(v29Refresh,80);setTimeout(v29Refresh,400);}}));
  });
})();

