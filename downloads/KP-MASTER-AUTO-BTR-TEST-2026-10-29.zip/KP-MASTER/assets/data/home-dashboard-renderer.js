
/* Home reads the same calculated chart and timelines as the worksheets.
   Its chart and table copies are display-only; calculations stay in their
   original tabs, and the AD selector changes the existing MD selection. */
(function () {
  'use strict';
  const byId = id => document.getElementById(id);
  const views = ['basic', 'fourfold', 'sixfold', 'fourstep', 'nadi'];
  const labels = {basic: 'Basic calculations', fourfold: 'Four-fold significators', sixfold: 'Six-fold significators', fourstep: 'Four-step theory', nadi: 'Nadi significators'};
  const weekdayLords = ['Su', 'Mo', 'Ma', 'Me', 'Ju', 'Ve', 'Sa'];
  let currentView = 'basic';
  let queued = false;
  let initialized = false;
  // Render from source changes, not from translated/fitted mirror DOM.
  // Comparing a decorated mirror to its raw source continuously replaced
  // hovered labels and restarted both tooltip and language observers.
  const renderedMarkup=new WeakMap(),renderedText=new WeakMap();
  function replaceStable(mount,...nodes){const html=nodes.map(n=>n.outerHTML||n.textContent).join('');if(renderedMarkup.get(mount)===html&&mount.childNodes.length===nodes.length)return false;mount.replaceChildren(...nodes);renderedMarkup.set(mount,html);return true;}
  function textStable(node,text){if(!node||renderedText.get(node)===text)return;node.textContent=text;renderedText.set(node,text);}


  function element(tag, text, className) {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (className) node.className = className;
    return node;
  }
  const value = id => String(byId(id)?.value || '').trim();
  const list = values => Array.isArray(values) && values.length ? values.join(', ') : '—';
  function dateText(source) {
    if(window.KPPreferences?.isConfigured())return window.KPPreferences.formatDate(source);
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(source || '');
    return match ? match[3] + '/' + match[2] + '/' + match[1] : '—';
  }
  function birthDate() {
    const source = value('dob');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(source)) return null;
    const date = new Date(source + 'T12:00:00Z');
    return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === source ? date : null;
  }

  // Strip identities, editability, inline actions and form controls from
  // mirrored content. Manual chart text is kept exactly as it appears.
  function readonlyCopy(sourceId) {
    const source = byId(sourceId);
    if (!source) return null;
    const clone = source.cloneNode(true);
    [clone, ...clone.querySelectorAll('*')].forEach(node => {
      [...node.attributes].forEach(attribute => {
        if (['id', 'name', 'for', 'contenteditable', 'tabindex', 'aria-controls', 'aria-labelledby', 'aria-describedby', 'headers'].includes(attribute.name) || /^on/i.test(attribute.name)) node.removeAttribute(attribute.name);
      });
      if (node.matches('input, select, textarea')) {
        const display = element('span', node.value || '—', 'home-readonly-value');
        node.replaceWith(display);
      }
    });
    clone.dataset.homeSourceId = sourceId;
    if (sourceId === 'kundali' || sourceId === 'kundali-north') clone.dataset.homeChart = '';
    return clone;
  }
  function mirror(mountId, sourceId) {
    const mount = byId(mountId), copy = readonlyCopy(sourceId);
    if (!mount || !copy) return;
    replaceStable(mount,copy);
  }

  function renderNative() {
    const mount = byId('home-native');
    if (!mount) return;
    const date = birthDate();
    const dateLabel = date ? dateText(value('dob')) + ' (' + new Intl.DateTimeFormat('en-IN', {weekday: 'long', timeZone: 'UTC'}).format(date) + ')' : '—';
    const fields = [
      ['name', 'Name'], ['dob', 'Date'], ['birthTime', 'Time'], ['birthPlace', 'Place'],
      ['lat', 'Latitude'], ['lon', 'Longitude'], ['ayanValue', 'KP ayanamsha'], ['lmtFinal', 'Local mean time']
    ];
    const details = element('dl', undefined, 'home-native-details');
    fields.forEach(([id, label]) => {
      const entry = element('div');
      const text = id === 'dob' ? dateLabel : id === 'birthTime' && window.KPPreferences?.isConfigured() ? window.KPPreferences.formatTime(value(id)) : value(id) || '—';
      const content = element('dd', text);
      content.dataset.homeField = id;
      content.dataset.homeValue = String(byId(id)?.value || '');
      entry.append(element('dt', label), content);
      details.append(entry);
    });
    replaceStable(mount,details);
  }

  function selectedMD() {
    const periods = Array.isArray(window.mdDashaPeriods) ? window.mdDashaPeriods : [];
    return periods.find(period => period.key === byId('adMDSelect')?.value) || periods[0] || null;
  }
  function timeline(periods, kind) {
    const table = element('table', undefined, 'kp-table home-dasha-table');
    table.dataset.homeSourceId = kind === 'md' ? 'mdDashaRows' : 'adDashaRows';
    table.setAttribute('aria-label', kind === 'md' ? 'Mahadasha timeline' : 'Antardasha timeline');
    const head = element('thead'), header = element('tr');
    [kind === 'md' ? 'MD' : 'AD', 'Start date', 'End date'].forEach(label => {
      const cell = element('th', label);
      cell.scope = 'col';
      header.append(cell);
    });
    head.append(header);
    const body = element('tbody');
    const selected = selectedMD();
    periods.forEach(period => {
      const row = element('tr');
      row.dataset.dashaLord = period.lord;
      row.dataset.periodStart = period.start;
      row.dataset.periodEnd = period.end;
      row.dataset.birthActive = String(Boolean(kind === 'md' ? period.isBirth : period.birthActive));
      const name = element('th');
      name.scope = 'row';
      if (kind === 'md') {
        row.dataset.homeMdKey = period.key;
        row.classList.toggle('is-selected', selected?.key === period.key);
        row.dataset.selected = String(selected?.key === period.key);
        const button = element('button', period.lord, 'home-md-choice');
        button.type = 'button';
        button.dataset.homeMdKey = period.key;
        button.setAttribute('aria-pressed', String(selected?.key === period.key));
        button.title = 'Show Antardasha for ' + period.lord;
        name.append(button);
        row.title = `${period.y} years, ${period.m} months, ${period.d} days${period.isBirth ? ' · Balance at birth' : ''}`;
      } else {
        name.textContent = period.lord;
        row.classList.toggle('is-birth-active', Boolean(period.birthActive));
        row.title = `${period.years} years, ${period.months} months, ${period.days} days${period.birthActive ? ' · At birth' : ''}`;
      }
      row.append(name, element('td', dateText(period.start)), element('td', dateText(period.end)));
      body.append(row);
    });
    table.append(head, body);
    return table;
  }
  function renderDashas() {
    const mdMount = byId('home-md'), adMount = byId('home-ad');
    if (!mdMount || !adMount) return;
    const focusedSelect = document.activeElement?.matches('#home .home-ad-select');
    const periods = Array.isArray(window.mdDashaPeriods) ? window.mdDashaPeriods : [];
    mdMount.dataset.ready = String(periods.length > 0);
    adMount.dataset.ready = String(periods.length > 0);
    if (!periods.length) {
      replaceStable(mdMount,element('p', 'Complete the birth date and Moon position to calculate MD.', 'home-empty'));
      replaceStable(adMount,element('p', 'Antardasha appears after the Moon position is calculated.', 'home-empty'));
      return;
    }
    const balance = element('p', 'Birth balance · ' + (value('mdBirthDasha') || periods[0].lord) + ': ' + (value('mdBhogyaDuration') || '—'), 'home-dasha-note');
    balance.dataset.homeBirthMdBalance = '';
    replaceStable(mdMount,timeline(periods, 'md'), balance);
    const selected = selectedMD();
    const control = element('label', undefined, 'home-ad-label');
    control.append(element('span', 'Mahadasha'));
    const select = element('select', undefined, 'home-ad-select');
    select.setAttribute('aria-label', 'Select Mahadasha for Home Antardasha');
    select.dataset.calculationLocked = 'true';
    periods.forEach(period => {
      const option = element('option', period.lord + ' · ' + dateText(period.start) + ' – ' + dateText(period.end));
      option.value = period.key;
      option.selected = period.key === selected.key;
      select.append(option);
    });
    control.append(select);
    const adPeriods = typeof window.calculateAntardashas === 'function' ? window.calculateAntardashas(selected) : [];
    const adBalance = element('p', 'At birth · ' + (value('adBirthLord') || '—') + ': ' + (value('adBirthBalance') || '—'), 'home-dasha-note');
    adBalance.dataset.homeBirthAdBalance = '';
    replaceStable(adMount,control, timeline(adPeriods, 'ad'), adBalance);
    if (focusedSelect) select.focus({preventScroll: true});
  }

  function renderView() {
    const home = byId('home');
    if (!home) return;
    home.dataset.activeView = currentView;
    home.querySelectorAll('button[data-home-view]').forEach(button => {
      const active = button.dataset.homeView === currentView;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
      if (button.getAttribute('role') === 'tab') button.setAttribute('aria-selected', String(active));
    });
    const steps = currentView === 'fourstep';
    if (byId('home-data-tables')) byId('home-data-tables').hidden = steps || currentView === 'nadi';
    if (byId('home-fourstep')) byId('home-fourstep').hidden = !steps;
    textStable(byId('home-planet-heading'),'Planets · '+labels[currentView]);
    textStable(byId('home-house-heading'),'Houses · '+labels[currentView]);
    if(byId('home-nadi-significators'))byId('home-nadi-significators').hidden=currentView!=='nadi';
    if(currentView==='nadi')window.KPHomeNadi?.render();
    else if (steps) mirror('home-fourstep', 'kp-fourstep');
    else {
      mirror('home-planets', 'kp-' + currentView + '-planet');
      mirror('home-houses', 'kp-' + currentView + '-house');
    }
    const legend=byId('home-notations-legend');
    if(legend){
      const markup=window.KPDisplay?.legendHTML()||'';
      if(renderedMarkup.get(legend)!==markup){legend.innerHTML=markup;renderedMarkup.set(legend,markup);}
      legend.hidden=window.KPPreferences?.get().notationMarkers===false;
    }
  }
  function refresh() {
    const home = byId('home');
    if (!home) return;
    const ready = Boolean(window.currentKPModel?.ready);
    home.dataset.modelReady = String(ready);
    const status = byId('home-status');
    if (status) {
      status.dataset.ready = String(ready);
      textStable(status,ready?'Chart ready · Current birth chart':'Complete the house cusps in Tab 5 and planet positions in Tab 6 to view the complete chart.');
    }
    mirror('home-kundali', window.KPChartStyle?.getSourceId() || 'kundali');
    renderView();
    renderNative();

    renderDashas();
  }
  function scheduleRefresh() {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => { queued = false; refresh(); });
  }
  function setView(view) {
    if (!views.includes(view)) return false;
    currentView = view;
    renderView();
    return true;
  }
  function selectMD(key) {
    const select = byId('adMDSelect');
    if (!select || select.disabled || ![...select.options].some(option => option.value === key)) return;
    select.value = key;
    select.dispatchEvent(new Event('change', {bubbles: true}));
    refresh();
  }
  function initialize() {
    const home = byId('home');
    if (!home || initialized) return;
    initialized = true;
    home.addEventListener('click', event => {
      const viewButton = event.target.closest('button[data-home-view]');
      const mdButton = event.target.closest('button[data-home-md-key]');
      if (viewButton) { event.stopPropagation(); setView(viewButton.dataset.homeView); }
      else if (mdButton) { event.stopPropagation(); selectMD(mdButton.dataset.homeMdKey); }
    });
    home.addEventListener('input', event => event.stopPropagation());
    home.addEventListener('change', event => {
      event.stopPropagation();
      if (event.target.matches('.home-ad-select')) selectMD(event.target.value);
    });
    document.addEventListener('input', event => { if (!event.target.closest('#home')) scheduleRefresh(); });
    document.addEventListener('change', event => { if (!event.target.closest('#home')) scheduleRefresh(); });
    ['chart-saved', 'chart-manual-change'].forEach(name => window.addEventListener(name, scheduleRefresh));
    const observer = new MutationObserver(scheduleRefresh);
    ['kundali', 'kundali-north', 'kp-basic-planet', 'kp-basic-house', 'kp-fourfold-planet', 'kp-fourfold-house', 'kp-sixfold-planet', 'kp-sixfold-house', 'kp-fourstep', 'mdDashaRows', 'adDashaRows'].forEach(id => {
      const source = byId(id);
      if (source) observer.observe(source, {childList: true, subtree: true, characterData: true});
    });
    refresh();
  }
  window.refreshHomeDashboard = refresh;
  window.KPHomeDashboard = Object.freeze({refresh, setView, getView: () => currentView});
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize);
  else initialize();
})();

