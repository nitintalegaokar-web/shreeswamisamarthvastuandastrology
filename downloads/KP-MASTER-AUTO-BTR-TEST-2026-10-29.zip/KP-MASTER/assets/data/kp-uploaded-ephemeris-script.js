
(()=>{'use strict';const data=JSON.parse(document.getElementById('kp-uploaded-ephemeris-data').textContent),start=Date.parse(data.start+'T00:00:00Z'),ids=['Su','Mo','Ma','Me','Ju','Ve','Sa','Ra','Ke'];
window.KPUploadedEphemeris=Object.freeze({get(date){if(!/^\d{4}-\d{2}-\d{2}$/.test(date))return null;const stamp=Date.parse(date+'T00:00:00Z'),index=(stamp-start)/86400000;if(!Number.isInteger(index)||index<0||index>=data.rows.length)return null;const row=data.rows[index];return {date,st:row[0],positions:Object.fromEntries(ids.map((id,i)=>[id,row[i+1]/60]))};},start:data.start,end:data.end,count:data.rows.length});
})();

