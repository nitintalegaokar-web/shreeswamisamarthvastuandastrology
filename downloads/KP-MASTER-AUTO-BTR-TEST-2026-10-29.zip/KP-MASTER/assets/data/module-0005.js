
document.addEventListener("DOMContentLoaded",()=>{
  const ids=[];
  ["p6_d_","p6_t_","p6_hours_","p6_minutes_"].forEach(prefix=>{
    for(let i=0;i<9;i++) ids.push(prefix+i);
  });
  ids.forEach(id=>{
    const e=document.getElementById(id);
    if(e) e.addEventListener("input",()=>{
      if(typeof calculateAll==="function") calculateAll();
    });
  });
});

