
document.addEventListener("DOMContentLoaded",()=>{
  const base=document.getElementById("baseSidereal0530");
  if(base) base.addEventListener("input",()=>{
    updateSiderealTimeCalculation();
    updateSampattikTimeDifferences();
  });

  ["birthTime","stdLon","placeStdLon","lon"].forEach(id=>{
    const el=document.getElementById(id);
    if(el) el.addEventListener("input",()=>{
      if(id==="lon") syncPlaceLongitudeFromBasic();
      updateLongitudeDifference();
      updateLMTCalculation();
      updateSiderealTimeCalculation(); updateSampattikTimeDifferences();
    });
  });

  updateSiderealTimeCalculation(); updateSampattikTimeDifferences();
});

