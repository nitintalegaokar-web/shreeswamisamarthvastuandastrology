
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  function placeLookup(placeId, target) {
    const panel=document.querySelector('.kp-india-picker[data-place-for="'+placeId+'"]');
    if(!panel||panel.parentElement.classList.contains('kp-reference-place-lookup'))return;
    const details=document.createElement('details');details.className='kp-reference-place-lookup no-print';
    const summary=document.createElement('summary');summary.textContent='Choose Indian city / village';details.append(summary);
    if(target)target.append(details);else panel.before(details);
    details.append(panel);
    $(placeId)?.addEventListener('focus',()=>{details.open=true;});
  }
  function linkedRadios(select, className, labelText) {
    const group=document.createElement('div');group.className=className;group.setAttribute('role','group');group.setAttribute('aria-label',labelText);
    for(const option of select.options){
      const label=document.createElement('label'),input=document.createElement('input');input.type='radio';input.name=select.id+'-reference-options';input.value=option.value;input.dataset.calculationLocked='true';input.checked=select.value===option.value;
      label.append(input,document.createTextNode(option.textContent));group.append(label);
      input.addEventListener('change',()=>{if(input.checked){select.value=input.value;select.dispatchEvent(new Event('change',{bubbles:true}));}});
    }
    const sync=()=>group.querySelectorAll('input').forEach(input=>input.checked=input.value===select.value);
    select.addEventListener('change',sync);window.addEventListener('chart-saved',sync);select.closest('section')?.addEventListener('click',()=>setTimeout(sync,0));document.addEventListener('change',event=>{if(event.target?.id==='kp-software-settings')sync();});
    return group;
  }
  function matchmaking() {
    const section=$('matchmaking'),pair=section?.querySelector('.mm-pair'),main=section?.querySelector('#mm-status')?.closest('.mm-card');
    if(!pair||!main||main.classList.contains('mm-reference-main'))return;
    main.classList.add('mm-reference-main');
    const notebook=main.querySelector('.mm-notebook');
    if(notebook){const storage=document.createElement('div');storage.className='mm-reference-saved no-print';storage.hidden=true;storage.append(notebook);section.append(storage);}
    for(const kind of ['boy','girl']){
      const place=$('mm-'+kind+'-place'),label=place?.closest('label');
      if(label){const help=document.createElement('p');help.className='mm-place-instruction';help.textContent='Enter a place name and select its coordinates';label.before(help);}
      placeLookup('mm-'+kind+'-place');
    }
    for(const kind of ['boy','girl']){const profile=$('mm-profile-'+kind);if(profile){const details=document.createElement('details');details.className='mm-birth-chart-details';details.open=true;const summary=document.createElement('summary');summary.textContent='Chart positions';profile.before(details);details.append(summary,profile);}}
    const result=$('mm-result');let results;if(result){results=document.createElement('details');results.className='mm-reference-results';const summary=document.createElement('summary');summary.textContent='Calculated compatibility';result.before(results);results.append(summary,result);$('mm-calculate')?.addEventListener('click',()=>results.open=true);}
    const region=$('mm-region');
    if(region){region.closest('label').classList.add('mm-region-native');const radios=linkedRadios(region,'mm-region-radios','Manglik calculation options');radios.querySelectorAll('label').forEach(label=>{const input=label.querySelector('input');label.lastChild.textContent=({north:'1, 4, 7, 8, 12 houses (North)',south:'2, 4, 7, 8, 12 houses (South)',both:'1, 2, 4, 7, 8, 12 houses (Both)'})[input.value];});['north','south','both'].forEach(value=>{const input=radios.querySelector('input[value="'+value+'"]');if(input)radios.append(input.parentElement);});region.closest('.mm-controls').prepend(radios);}
    const actions=$('mm-calculate')?.closest('.mm-actions');
    if(actions){
      actions.classList.add('mm-reference-footer');$('mm-calculate').textContent='Calculate / Preview';$('mm-print').textContent='Print';$('mm-save-memo').textContent='Save';
      const pdf=document.createElement('button');pdf.type='button';pdf.textContent='Export to PDF';pdf.title='Select this report and use Save as PDF in the print dialog';pdf.disabled=$('mm-print').disabled;new MutationObserver(()=>pdf.disabled=$('mm-print').disabled).observe($('mm-print'),{attributes:true,attributeFilter:['disabled']});pdf.addEventListener('click',()=>$('mm-print').click());
      const close=document.createElement('button');close.type='button';close.textContent='Close';close.addEventListener('click',()=>document.querySelector('.app-sidebar [data-tab="home"]')?.click());
      if(results&&$('mm-csv')){const exportRow=document.createElement('div');exportRow.className='mm-actions';exportRow.append($('mm-csv'));results.append(exportRow);}
      actions.prepend($('mm-print'));$('mm-calculate').after(pdf);actions.append(close);main.append(actions);
    }
  }
  function transit() {
    const section=$('transit-chart'),column=section?.querySelector('.tc-control-column'),controls=column?.querySelector('.tc-controls'),grid=controls?.querySelector('.tc-control-grid');
    if(!grid||controls.dataset.referenceWindow)return;
    controls.dataset.referenceWindow='true';const heading=section.querySelector('.tc-card > h2');if(heading)heading.textContent='Transit Chart';
    const dasha=$('tc-dasha')?.closest('article');if(dasha){dasha.classList.add('tc-reference-dasha');column.prepend(dasha);}
    const place=document.createElement('article');place.className='tc-reference-place no-print';
    const placeRow=$('tc-place')?.parentElement;if(placeRow)place.append(placeRow);
    const location=document.createElement('details');location.className='tc-reference-location';const summary=document.createElement('summary');summary.textContent='Change place';location.append(summary);
    const locationGrid=document.createElement('div');locationGrid.className='tc-reference-location-grid';location.append(locationGrid);
    for(const id of ['tc-latitude','tc-longitude','tc-timezone']){const row=$(id)?.parentElement;if(row)locationGrid.append(row);}
    place.append(location);column.insertBefore(place,controls);placeLookup('tc-place',location);
    controls.querySelector('h3').textContent='Choose date and time';
    const advance=document.createElement('article');advance.className='tc-reference-advance no-print';
    const cuspSelect=$('tc-cusp-source');
    if(cuspSelect){const original=cuspSelect.parentElement;original.classList.add('tc-reference-native-source');advance.append(original,linkedRadios(cuspSelect,'tc-reference-cusps','House cusps'));}
    const step=$('tc-step-size'),stepLabel=controls.querySelector('label[for="tc-step-size"]');if(stepLabel)advance.append(stepLabel);if(step)advance.append(step);
    const direction=$('tc-forward')?.closest('.tc-actions'),realtime=$('tc-realtime')?.closest('.tc-actions');if(direction)advance.append(direction);if(realtime)advance.append(realtime);
    section.querySelector('.tc-chart-column').append(advance);
  }
  function initialize(){matchmaking();transit();}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

