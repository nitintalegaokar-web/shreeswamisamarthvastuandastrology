
/* v16 — Tab 6: use EXACTLY the same calculation method as Ravi/Sun.
   1) दैनिक गती = first row position - second row position.
   2) For birth after 05:30, birth position = first-row position + daily motion × elapsed fraction.
   3) For birth before 05:30, birth position = second-row position + daily motion × elapsed fraction.
   4) एकूण = तास + मिनिटे.
   5) बेरीज = जन्मवेळची स्थिती + एकूण.
   6) वजा राशी अंश = completed 30° blocks from बेरीज.
   7) पत्रिकेतील स्थिती = बेरीज - वजा राशी अंश.
   8) राशी name follows the 30° block.
   This final handler intentionally overrides older duplicate Tab-6 handlers.
*/
(function(){
  const N=9, FULL=1296000, R30=108000;
  const pad2=n=>String(Math.abs(Math.trunc(n))).padStart(2,'0');
  const parse=v=>{
    if(v==null || String(v).trim()==='') return NaN;
    const a=String(v).trim().replace(/\s*R\s*$/i,'').split(':').map(Number);
    if(a.length<2 || a.some(x=>!Number.isFinite(x))) return NaN;
    return a[0]*3600+(a[1]||0)*60+(a[2]||0);
  };
  const norm=s=>((s%FULL)+FULL)%FULL;
  const dms=s=>{
    if(!Number.isFinite(s)) return '';
    s=Math.round(norm(s));
    const d=Math.floor(s/3600); s%=3600;
    const m=Math.floor(s/60), sec=s%60;
    return `${d}:${pad2(m)}:${pad2(sec)}`;
  };
  const clock=s=>{
    if(!Number.isFinite(s)) return '';
    const neg=s<0; s=Math.abs(Math.round(s));
    const h=Math.floor(s/3600); s%=3600;
    const m=Math.floor(s/60), sec=s%60;
    return `${pad2(h)}:${pad2(m)}:${pad2(sec)}${neg?' R':''}`;
  };
  const set=(id,v)=>{const e=document.getElementById(id); if(e)e.value=v??'';};
  const get=id=>(document.getElementById(id)?.value||'').trim();

  function syncTime(){
    const src=get('birthTime');
    if(!src) return;
    const a=src.split(':').map(Number);
    if(a.length<2 || !Number.isFinite(a[0])) return;
    let h=a[0], m=a[1]||0, sec=a[2]||0;
    const ap=h>=12?'PM':'AM';
    let h12=h%12; if(h12===0)h12=12;
    set('planet6BirthTime',`${pad2(h12)}:${pad2(m)}:${pad2(sec)}`);
    const apEl=document.getElementById('planet6BirthAmPm'); if(apEl)apEl.value=ap;
  }

  function syncDates(){
    if(document.getElementById('p6-ephemeris-source')?.value==='manual')return;
    const dob=get('dob'), bt=get('birthTime')||'05:30:00';
    const d1=document.getElementById('p6_date_1'), d2=document.getElementById('p6_date_2');
    if(!dob||!d1||!d2)return;
    const [Y,M,D]=dob.split('-').map(Number);
    if(!Y||!M||!D)return;
    const base=new Date(Y,M-1,D);
    const sec=parse(bt), before=Number.isFinite(sec)&&sec<19800;
    const adj=new Date(base); adj.setDate(adj.getDate()+(before?-1:1));
    const iso=x=>`${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`;
    d1.value=dob; d2.value=iso(adj);
    ['p6_time_1','p6_time_2'].forEach(id=>set(id,'05:30:00'));
    ['p6_ampm_1','p6_ampm_2'].forEach(id=>set(id,'AM'));
  }

  function calc(){
    syncTime(); syncDates();
    const bt=get('birthTime')||'05:30:00';
    const birthSec=parse(bt);
    if(!Number.isFinite(birthSec))return;
    const before=birthSec<19800;
    // Exact Sun/Ravi method: elapsed fraction from 05:30.
    const elapsed=before ? birthSec+86400-19800 : birthSec-19800;
    const fraction=Math.max(0,Math.min(1,elapsed/86400));

    for(let i=0;i<N;i++){
      const first=parse(get(`p6_d_${i}`));
      const second=parse(get(`p6_t_${i}`));
      const has=Number.isFinite(first)&&Number.isFinite(second);
      if(!has){
        ['p6_motion_'+i,'p6_total_'+i,'p6_birth_'+i,'p6_add_'+i,'p6_ayan_'+i,'p6_final_'+i,'p6_rashi_'+i].forEach(id=>set(id,''));
        continue;
      }

      // EXACTLY like Ravi/Sun in the user's screenshot: first - second.
      const motion=first-second;
      const isNode=(i===7||i===8);
      set(`p6_motion_${i}`,clock(motion)+(motion<0&&!isNode?'':'').replace(/\sR$/,''));
      if(motion<0 && !isNode) set(`p6_motion_${i}`,clock(motion));
      else set(`p6_motion_${i}`,clock(motion).replace(/\sR$/,''));

      // User-entered hour/minute correction values -> total.
      const h=parse(get(`p6_hours_${i}`)), m=parse(get(`p6_minutes_${i}`));
      const total=(Number.isFinite(h)&&Number.isFinite(m)) ? h+m : NaN;
      set(`p6_total_${i}`,Number.isFinite(total)?clock(total).replace(/\sR$/,''):'');

      // जन्मवेळची स्थिती = जन्मतारखेच्या 05:30 ग्रहस्थितीची थेट प्रत.
      // कोणतीही interpolation / daily-motion गणना येथे वापरायची नाही.
      const dob=get('dob');
      const rd1=(document.getElementById('p6_row_date_1')?.value||document.getElementById('p6_date_1')?.value||'').trim();
      const rd2=(document.getElementById('p6_row_date_2')?.value||document.getElementById('p6_date_2')?.value||'').trim();
      const birthPos = rd1===dob ? first : (rd2===dob ? second : NaN);
      set(`p6_birth_${i}`,Number.isFinite(birthPos)?dms(birthPos):'');

      // Add the calculated total correction.
      const sum=Number.isFinite(total)?norm(birthPos+total):birthPos;
      set(`p6_add_${i}`,dms(sum));

      // Subtract complete rashi blocks: 0,30,60,90... degrees.
      const idx=Math.floor(sum/R30);
      const subtract=idx*R30;
      const remaining=sum-subtract;
      set(`p6_ayan_${i}`,dms(subtract));
      set(`p6_final_${i}`,dms(remaining)+(motion<0&&!isNode?' R':''));
      set(`p6_rashi_${i}`,Array.isArray(window.rashi)?window.rashi[idx%12]:(typeof rashi!=='undefined'?rashi[idx%12]:''));
    }
  }

  window.calculateTab6SunMethod=calc;
  document.addEventListener('DOMContentLoaded',()=>{
    ['dob','birthTime'].forEach(id=>{
      const e=document.getElementById(id); if(e){e.addEventListener('input',calc);e.addEventListener('change',calc);}
    });
    for(let i=0;i<N;i++){
      ['p6_d_'+i,'p6_t_'+i,'p6_hours_'+i,'p6_minutes_'+i].forEach(id=>{
        const e=document.getElementById(id); if(e){e.addEventListener('input',calc);e.addEventListener('change',calc);}
      });
    }
    setTimeout(calc,30);
    setTimeout(calc,150);
  });
})();

