
(() => {
  'use strict';
  const sections = {
    help: ['Help', 'Software tutorial and offline PDF guide.'],
    tutorial: ['Tutorial', 'Learn kundali interpretation, explain chart evidence and prepare teaching handouts.'],
    home: ['Home', 'Your kundali, calculations, dasha periods, and birth details together.'],
    basic: ['Birth details', 'A clear starting point for every chart. जन्माची अचूक माहिती येथे भरा.'],
    'basic-information': ['Basic Information', 'Native kundali facts and birth Panchang.'],
    'admin-calculations': ['Administrator calculations', 'PIN access to calculation worksheets.'],
    ayan: ['Longitude calculation', 'Compare the birthplace longitude with the standard meridian.'],
    lmt: ['Local mean time', 'Follow the longitude correction to your exact local birth time.'],
    stcalc: ['Sidereal time', 'Use automatic 05:30 sidereal time or enter your ephemeris value.'],
    raphael5: ['Raphael houses', 'Enter your Raphael table values to calculate the twelve house cusps.'],
    planet: ['Planet positions', 'Fill the 05:30 ephemeris rows automatically or enter them manually.'],
    mdcalc: ['DBA/MAP', 'Dasha, Bhukti and Antara periods from the native kundali.'],
    karyesh: ['Significators', 'Explore the connections between planets, houses, and sub-lords.'],
    prediction: ['Prediction', 'Review every cusp’s CSL, star lord and sub lord against your event house groups.'],
    muhurta: ['Muhurta', 'Traditional Panchang with KP support.'],
    gemstones: ['Gemstone guidance', 'Choose a rule and review its selected gemstones.'],
    'disease': ['Disease', 'Sixth cusp CSL, star and sub lord reference associations.'],
    'education-profession': ['Education & Profession', 'Automatic branch analysis from the 4th, 9th and 10th cusps.'],
    'dasha-promise': ['Dasha Promise', 'Dasha, Bhukti, event house criteria and Sun gochar.'],
    'resources': ['KP Resources', 'Your KP astrology topics, subtopics and reference material.'],
    'event-promise': ['Event Promise', 'Cusp and event house groups.'],
    'horary-results': ['Automatic Horary Results', 'Common significators, current ruling planets and fruitful DBA.'],
    'nadi-astrology': ['Nadi Astrology', 'Planet · star · sub.'],
    'matchmaking': ['Matchmaking', 'Ashtakoota + Manglik.'],
    aspects: ['Western aspects', 'Calculate planet-to-planet and planet-to-cusp aspects with your chosen orbs.'],
    transit: ['Transits', 'Find dated transit periods for events and MD, AD and PD relationships.'],
    'transit-chart': ['Transit Chart', 'View the selected moment in planet and cusp tables, with Rashi and Bhav charts.'],
    'transit-panchang': ['Transit Panchang', 'Calculate Panchang and solar times for a selected transit moment and place.'],
    ephemeris: ['Ephemeris', 'Generate daily sidereal planetary positions for your selected date range.'],
    'hit-theory': ['HIT Theory', 'Native DBA hits and direction-based remedies.'],
    'vedic-kundali': ['Vedic Kundali', 'Traditional Vedic chart and reports.'],
    south9: ['South Indian kundali', 'Your birth and bhav-chalit chart, with a clear view of every house.'],
    report: ['Your chart report', 'Review the complete worksheets, then print or save them as a PDF.'],
    about: ['About', 'Software developer and contact details.'],
    astrosettings: ['Astrologer settings', 'Configure your display, calculations and client report preferences.']
  };
  const byId = id => document.getElementById(id);
  const mobile = window.matchMedia('(max-width: 800px)');
  const navButtons = [...document.querySelectorAll('.app-sidebar nav button[data-tab]')];
  let toastTimer;
  let overviewTimer;
  let helpReturnFocus;

  window.showToast = (message, type = 'info') => {
    const toast = byId('workspace-toast');
    if (!toast) return;
    clearTimeout(toastTimer);
    toast.dataset.type = type;
    toast.replaceChildren();
    const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    icon.setAttribute('aria-hidden', 'true');
    const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', type === 'error' ? '#i-help' : '#i-check');
    icon.append(use);
    const text = document.createElement('span');
    text.textContent = message;
    toast.append(icon, text);
    toast.hidden = false;
    toastTimer = setTimeout(() => { toast.hidden = true; }, type === 'error' ? 6500 : 4000);
  };

  function setSaveState(text, saved = false) {
    const state = byId('save-state');
    state.replaceChildren(document.createElement('span'), document.createTextNode(text));
    state.classList.toggle('is-saved', saved);
  }

  function refreshOverview() {
    const value = id => byId(id)?.value || '—';
    byId('overview-name').textContent = byId('name').value.trim() || 'Untitled chart';
    const dateValue = byId('dob').value;
    const date = dateValue ? new Date(dateValue + 'T12:00:00') : null;
    const formatted = date && !Number.isNaN(date.getTime()) ? new Intl.DateTimeFormat('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }).format(date) : 'Date not set';
    byId('overview-date').textContent = formatted + ' · ' + value('birthTime');
    byId('overview-lmt').textContent = value('lmtFinal');
    byId('overview-ayan').textContent = value('ayanValue');
    byId('overview-longitude').textContent = value('lonDifference');
  }

  function activateSection(id, focusHeading = false) {
    if(id==='report')window.KPReportPages?.excludeMatchmaking();
    const details = id === 'south9' ? [(window.KPChartStyle?.getStyle() === 'north' ? 'North Indian' : 'South Indian') + ' kundali', sections.south9[1]] : sections[id];
    if (!details) return;
    byId('page-title').textContent = details[0];
    byId('page-description').textContent = details[1];
    byId('breadcrumb-current').textContent = details[0];
    document.title = details[0] + ' · KP MASTER';
    document.querySelectorAll('#workspace-main > .tab').forEach(panel => panel.classList.toggle('active', panel.id === id));
    document.body.classList.toggle('home-visible', id === 'home');
    if (id !== 'home') {
      document.body.classList.remove('home-expanded');
      const expand = byId('home-expand-workspace');
      if (expand) { expand.setAttribute('aria-pressed', 'false'); (expand.querySelector('span') || expand).textContent = 'Expand workspace'; }
    } else window.refreshHomeDashboard?.();
    if (id === 'transit-chart') window.KPTransitChart?.refresh();
    if (id === 'prediction') { window.KPPrediction?.refresh(); window.KPPersonalPredictions?.refresh(); }
    if (id === 'dasha-fal') window.KPDashaFal?.refresh();
    if (id === 'gemstones') window.KPGemstones?.refresh();
    if (id === 'south9') window.KPTimeSlices?.refresh();
    if (id === 'event-promise') window.KPEventPromise?.refresh();
    if (id === 'nadi-astrology') window.KPNadiAstrology?.refresh();
    else window.KPNadiAstrology?.stopRealTime();
    if (id === 'matchmaking') window.KPMatchmaking?.refresh();
    if (id === 'transit-panchang') window.KPTransitPanchang?.refresh();
    if (id === 'ephemeris') window.KPDailyEphemeris?.refresh();
    navButtons.forEach(button => {
      const selected = button.dataset.tab === id;
      button.classList.toggle('active', selected);
      if (selected) button.setAttribute('aria-current', 'page');
      else button.removeAttribute('aria-current');
    });
    closeNavigation();
    setTimeout(updateScrollHints, 0);
    if (focusHeading) byId('workspace-main').focus({ preventScroll: true });
    window.scrollTo({ top: 0, behavior: 'instant' });
  }
  window.addEventListener('kundali-style-changed', () => {
    if (!byId('south9')?.classList.contains('active')) return;
    const title = (window.KPChartStyle?.getStyle() === 'north' ? 'North Indian' : 'South Indian') + ' kundali';
    byId('page-title').textContent = title;
    byId('breadcrumb-current').textContent = title;
    document.title = title + ' · KP MASTER';
  });

  function goToSection(id) {
    navButtons.find(button => button.dataset.tab === id)?.click();
    byId('workspace-main').focus({ preventScroll: true });
  }

  function closeNavigation(restoreFocus = false) {
    const wasOpen = document.body.classList.contains('menu-open');
    document.body.classList.remove('menu-open');
    byId('sidebar-backdrop').hidden = true;
    byId('menu-toggle').setAttribute('aria-expanded', 'false');
    byId('app-sidebar').inert = mobile.matches;
    byId('workspace-main').inert = false;
    document.querySelector('.workspace-topbar').inert = false;
    if (wasOpen && restoreFocus) byId('menu-toggle').focus();
  }

  function openNavigation() {
    if (!mobile.matches) return;
    document.body.classList.add('menu-open');
    byId('sidebar-backdrop').hidden = false;
    byId('menu-toggle').setAttribute('aria-expanded', 'true');
    byId('app-sidebar').inert = false;
    byId('workspace-main').inert = true;
    document.querySelector('.workspace-topbar').inert = true;
    document.querySelector('.sidebar-close').focus();
  }

  function openHelp() {
    helpReturnFocus = mobile.matches && document.body.classList.contains('menu-open') ? byId('menu-toggle') : document.activeElement;
    closeNavigation();
    byId('workspace-help').showModal();
  }

  function fieldError(input) {
    if (['dob', 'birthTime'].includes(input.id) && !input.value) return 'Please enter ' + (input.id === 'dob' ? 'the birth date.' : 'the birth time.');
    if (['lat', 'lon', 'dayAyan', 'daySum'].includes(input.id)) {
      const match = /^([+-]?\d{1,3}):([0-5]?\d):([0-5]?\d)$/.exec(input.value.trim());
      if (!match) return 'Use D:M:S, for example ' + (input.id === 'lon' ? '80:15:00' : '13:04:00') + '.';
      if (input.id === 'lat' && Math.abs(Number(match[1])) > 90) return 'Latitude must be between −90° and 90°.';
      if (input.id === 'lon' && Math.abs(Number(match[1])) > 180) return 'Longitude must be between −180° and 180°.';
    }
    return '';
  }

  function showFieldError(input) {
    const message = fieldError(input);
    const errorId = input.id + '-error';
    let error = byId(errorId);
    if (message) {
      input.setAttribute('aria-invalid', 'true');
      input.setAttribute('aria-describedby', errorId);
      if (!error) { error = document.createElement('small'); error.id = errorId; error.className = 'field-error no-print'; input.after(error); }
      error.textContent = message;
    } else {
      input.removeAttribute('aria-invalid');
      input.removeAttribute('aria-describedby');
      error?.remove();
    }
    return !message;
  }

  function validateBasic() {
    const inputs = ['dob', 'birthTime', 'lat', 'lon', 'dayAyan', 'daySum'].map(byId);
    const invalid = inputs.filter(input => !showFieldError(input));
    if (!invalid.length) return true;
    goToSection('basic');
    invalid[0].focus();
    showToast('Check the highlighted birth details before calculating.', 'error');
    return false;
  }

  function calculateChart() {
    if (!validateBasic()) return false;
    try {
      window.calculateAll();
      refreshOverview();
      const full = (window.cuspResults || []).filter(item => item?.nir !== null && Number.isFinite(Number(item?.nir))).length === 12;
      showToast(full ? 'Chart calculations updated.' : 'Birth details calculated. Complete the worksheets for all twelve houses.', 'success');
      return true;
    } catch (error) {
      showToast('The calculation could not finish. Please check your worksheet entries.', 'error');
      console.error(error);
      return false;
    }
  }

  function exportChart() {
    const data = window.getChartData();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'KP-MASTER-' + (byId('name').value.trim().replace(/[^\p{L}\p{N}_-]+/gu, '-').slice(0, 60) || 'chart') + '.lkp';
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    showToast('Chart backup exported. Keep this file to restore your work.', 'success');
  }

  async function handleAction(action) {
    document.querySelector('.backup-menu').open = false;
    if (action === 'open-kundali' || action === 'save-kundali') {
      try {
        if (action === 'open-kundali') {
          const file = await window.KPChartFiles.open();
          if (!file) return;
          if (file.size > 12 * 1024 * 1024) throw Error('Choose a chart file smaller than 12 MB.');
          window.restoreChartData(JSON.parse(await file.text()));
          setSaveState('Opened ' + file.name, true);
        } else {
          const target = await window.KPChartFiles.directory();
          if (byId('basic').classList.contains('active')) window.KPComputerForms?.apply(byId('chart-kind').value === 'horary' ? 'horary' : 'natal');
          const message = await window.KPChartFiles.save(window.getChartData(), target);
          setSaveState(message, true);
        }
        refreshOverview();
      } catch (error) {
        if (error.name !== 'AbortError') showToast(error instanceof SyntaxError ? 'Choose a valid .lkp kundali file.' : error.message, 'error');
      }
    }
    else if (action === 'calculate') calculateChart();
    else if (action === 'save') window.saveData();
    else if (action === 'load') { if (window.loadData()) refreshOverview(); }
    else if (action === 'export') exportChart();
    else if (action === 'import') byId('import-chart-file').click();
    else if (action === 'print') {
      goToSection('report');
      window.KPReportPages?.refresh();
      byId('report-page-options')?.focus();
    }
  }

  function updateScrollHints() {
    document.querySelectorAll('#workspace-main > .tab:not(#report) .worksheet-scroll,#south9 .chart-scroll').forEach(wrapper => {
      if (!wrapper.scrollHint) return;
      wrapper.scrollHint.hidden = !wrapper.clientWidth || wrapper.scrollWidth <= wrapper.clientWidth + 2;
    });
  }

  function addScrollHint(wrapper) {
    const hint = document.createElement('small');
    hint.className = 'scroll-hint no-print';
    hint.innerHTML = '<svg aria-hidden="true"><use href="#i-arrow"/></svg><span>Scroll sideways to see all columns</span>';
    hint.hidden = true;
    wrapper.before(hint);
    wrapper.scrollHint = hint;
    scrollObserver.observe(wrapper);
  }

  const scrollObserver = new ResizeObserver(updateScrollHints);

  function initialize() {
    document.querySelectorAll('svg').forEach(icon => icon.setAttribute('aria-hidden', 'true'));
    document.querySelectorAll('.workspace-topbar [data-action]').forEach(button => button.setAttribute('aria-label', ({ 'open-kundali':'Open kundali', 'save-kundali':'Save kundali', load:'Load chart', save:'Save chart', calculate:'Calculate chart', export:'Export chart file', import:'Import chart file', print:'Print report or save PDF' })[button.dataset.action]));
    navButtons.forEach((button, index) => {
      const panel = byId(button.dataset.tab);
      if(button.dataset.tab==='tutorial'){button.setAttribute('aria-controls','kp-teaching-tools');button.setAttribute('aria-expanded','false');return;}
      button.id = 'navigation-' + button.dataset.tab;
      button.setAttribute('aria-controls', panel.id);
      panel.setAttribute('aria-labelledby', button.id);
      panel.setAttribute('role', 'region');
      button.addEventListener('click', () => activateSection(button.dataset.tab));
      button.addEventListener('keydown', event => {
        const direction = event.key === 'ArrowDown' ? 1 : event.key === 'ArrowUp' ? -1 : 0;
        if (direction) { event.preventDefault(); navButtons[(index + direction + navButtons.length) % navButtons.length].focus(); }
      });
    });
    navButtons[0].setAttribute('aria-current', 'page');
    document.querySelectorAll('[data-action]').forEach(button => button.addEventListener('click', () => handleAction(button.dataset.action)));
    document.querySelectorAll('[data-go]').forEach(button => button.addEventListener('click', () => goToSection(button.dataset.go)));
    document.querySelectorAll('main label').forEach(label => {
      if (label.htmlFor) return;
      const input = label.parentElement.querySelector('input[id],select[id],textarea[id]');
      if (input) label.htmlFor = input.id;
    });
    document.querySelectorAll('main > .tab:not(#report):not(#home) table').forEach(table => {
      if (table.closest('.calc-sink')) return;
      const wrapper = document.createElement('div');
      wrapper.className = 'worksheet-scroll';
      wrapper.tabIndex = 0;
      wrapper.setAttribute('role', 'region');
      wrapper.setAttribute('aria-label', 'Calculation worksheet — scroll horizontally to see all columns');
      table.before(wrapper);
      wrapper.append(table);
      addScrollHint(wrapper);
    });
    const chartScroll = document.createElement('div');
    chartScroll.className = 'chart-scroll';
    chartScroll.tabIndex = 0;
    chartScroll.setAttribute('role', 'region');
    chartScroll.setAttribute('aria-label', 'Kundali chart — scroll horizontally on small screens');
    byId('kundali').before(chartScroll);
    chartScroll.append(byId('kundali'));
    addScrollHint(chartScroll);
    byId('menu-toggle').addEventListener('click', openNavigation);
    document.querySelector('.sidebar-close').addEventListener('click', () => closeNavigation(true));
    byId('sidebar-backdrop').addEventListener('click', () => closeNavigation(true));
    mobile.addEventListener('change', () => closeNavigation());
    closeNavigation();
    byId('home-expand-workspace')?.addEventListener('click', () => {
      const expanded = document.body.classList.toggle('home-expanded');
      const expand = byId('home-expand-workspace');
      expand.setAttribute('aria-pressed', String(expanded));
      (expand.querySelector('span') || expand).textContent = expanded ? 'Restore navigation' : 'Expand workspace';
      window.refreshHomeDashboard?.();
    });
    byId('help-open').addEventListener('click', openHelp);
    byId('help-close').addEventListener('click', () => byId('workspace-help').close());
    byId('workspace-help').addEventListener('close', () => helpReturnFocus?.focus());
    byId('workspace-help').addEventListener('click', event => { if (event.target === byId('workspace-help')) { const box = event.target.getBoundingClientRect(); if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) event.target.close(); } });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') { closeNavigation(true); document.querySelector('.backup-menu').open = false; return; }
      if (document.body.classList.contains('menu-open') && event.key === 'Tab') {
        const focusable = [...byId('app-sidebar').querySelectorAll('button:not([disabled])')];
        const first = focusable[0], last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
      if (event.ctrlKey || event.metaKey) {
        if (event.key.toLowerCase() === 's') { event.preventDefault(); handleAction('save-kundali'); }
        if (event.key === 'Enter') { event.preventDefault(); handleAction('calculate'); }
      } else if (event.key === '?' && !event.target.isContentEditable && !event.target.closest('input,textarea,select') && !byId('workspace-help').open) { event.preventDefault(); openHelp(); }
    });
    document.addEventListener('click', event => { if (!event.target.closest('.backup-menu')) document.querySelector('.backup-menu').open = false; });
    document.addEventListener('input', event => {
      if (!event.target.matches('main input:not([readonly]),main select,main textarea') && !event.target.isContentEditable) return;
      setSaveState('Unsaved changes');
      if (event.target.hasAttribute('aria-invalid')) showFieldError(event.target);
      clearTimeout(overviewTimer);
      overviewTimer = setTimeout(refreshOverview, 60);
    });
    ['dob', 'birthTime', 'lat', 'lon', 'dayAyan', 'daySum'].map(byId).forEach(input => input.addEventListener('blur', () => showFieldError(input)));
    window.addEventListener('chart-saved', () => { setSaveState('Saved in this browser', true); refreshOverview(); });
    window.addEventListener('chart-manual-change', () => setSaveState('Unsaved changes'));
    byId('import-chart-file').addEventListener('change', async event => {
      const file = event.target.files[0];
      if (!file) return;
      try {
        if (file.size > 12 * 1024 * 1024) throw new Error('Choose a chart file smaller than 12 MB, including the cover photo.');
        const data = JSON.parse(await file.text());
        window.restoreChartData(data);
        document.querySelectorAll('#basic [aria-invalid]').forEach(input => showFieldError(input));
        setSaveState('Imported · not saved');
        refreshOverview();
        showToast('Chart imported. Save it to keep a copy in this browser.', 'success');
      } catch (error) { showToast('Unable to import: ' + (error instanceof SyntaxError ? 'Choose a valid .lkp chart backup.' : error.message), 'error'); }
      finally { event.target.value = ''; }
    });
    try { if (localStorage.getItem('kpRaphaelData')) setSaveState('Saved chart available', true); } catch (_) { setSaveState('Browser storage unavailable'); }
    const originalCalculate = window.calculateAll;
    window.calculateAll = function (...args) { try { return originalCalculate.apply(this, args); } finally { requestAnimationFrame(refreshOverview); } };
    activateSection('home');
    refreshOverview();
    setTimeout(refreshOverview, 120);
    setTimeout(refreshOverview, 1500);
  }
  initialize();
})();

