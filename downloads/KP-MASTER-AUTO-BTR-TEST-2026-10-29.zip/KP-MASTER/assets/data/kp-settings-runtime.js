
(function(){
  'use strict';
  const byId=id=>document.getElementById(id);
  const contactIds=['astroName','astroMobile','astroAddress'];
  let appliedContact=null;
  const contacts=()=>Object.fromEntries(contactIds.map(id=>[id,byId(id)?.value||'']));
  function currentDraft(){
    const draft=window.KPPreferences.get();
    draft.chartStyle=window.KPChartStyle?.getStyle()||draft.chartStyle;
    draft.homeView=window.KPHomeDashboard?.getView()||draft.homeView;
    const orb=Number(byId('kp-conjunction-orb')?.value);
    if(Number.isFinite(orb)&&orb>=0&&orb<=10)draft.conjunctionOrb=orb;
    if(['natal','transit'].includes(byId('tc-cusp-source')?.value))draft.transitCusps=byId('tc-cusp-source').value;
    return draft;
  }
  function syncDraft(){
    window.KPSettings?.setDraft(currentDraft());
    window.KPSettings?.setLanguage(window.KPPreferences.get().language);
  }
  function applyCalculationChoices(settings,previous,action){
    if(!window.KPPreferences.isConfigured())return;
    if(action==='saved'||action==='initialized'){
      const conjunction=byId('kp-conjunction-orb');if(conjunction)conjunction.value=String(settings.conjunctionOrb);
      byId('tc-cusp-source').value=settings.transitCusps;
      window.calculateAll();
      window.KPWesternAspects.render();
    }
    window.KPHomeDashboard?.setView(settings.homeView);
    window.KPTransit?.refresh();window.KPTransit?.renderResults();
    window.KPTransitChart?.refresh();window.KPChartStyle?.refresh();
    window.KPPreferences.decorate(document);window.renderReport();
  }
  function changed(event){
    const {settings,previous,action}=event.detail;
    applyCalculationChoices(settings,previous,action);
    syncDraft();
    if(action==='saved'){
      try{window.saveAstrologerSettings();appliedContact=contacts();window.KPSettings.setStatus('Settings saved. Chart, display and reports updated.');}
      catch(error){appliedContact=contacts();window.KPSettings.setStatus('Settings applied. Browser storage is unavailable; export your chart to keep a copy.');}
      window.dispatchEvent(new Event('chart-manual-change'));
    }
  }
  function initialize(){
    appliedContact=contacts();
    window.KPSettings.initialize(window.KPPreferences.defaults);
    syncDraft();
    if(window.KPPreferences.isConfigured())applyCalculationChoices(window.KPPreferences.get(),window.KPPreferences.defaults,'initialized');
    byId('settings-cancel').addEventListener('click',()=>{
      Object.entries(appliedContact||{}).forEach(([id,value])=>{byId(id).value=value;});
      syncDraft();window.renderReport();window.KPSettings.setStatus('Restored your saved settings.');
    });
    document.querySelector('.app-sidebar [data-tab="astrosettings"]').addEventListener('click',syncDraft);
    document.addEventListener('click',event=>{
      if(event.target.closest('button[onclick="saveAstrologerSettings()"],button[onclick="resetAstrologerSettings()"]'))appliedContact=contacts();
    });
    window.addEventListener('chart-saved',event=>{if(event.detail?.action==='loaded'){appliedContact=contacts();window.KPHomeDashboard?.setView(window.KPPreferences.get().homeView);syncDraft();}});
  }
  window.addEventListener('kp-preferences-changed',changed);
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

