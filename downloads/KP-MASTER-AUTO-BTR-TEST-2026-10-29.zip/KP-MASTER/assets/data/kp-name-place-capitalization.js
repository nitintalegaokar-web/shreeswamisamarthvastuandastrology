
(() => {'use strict';
  const isNamePlace=el=>el?.matches('input[type="text"],input:not([type]),textarea')&&/(?:^name$|birthPlace$|(?:^|[-_])(?:name|place)$)/i.test(el.id);
  const capitalize=text=>String(text).replace(/(^|[\s'’-])(\p{Ll})/gu,(_all,before,letter)=>before+letter.toLocaleUpperCase());
  function apply(event){const el=event.target;if(!isNamePlace(el)||event.isComposing)return;const next=capitalize(el.value);if(next===el.value)return;const a=el.selectionStart,b=el.selectionEnd;el.value=next;try{if(a!==null)el.setSelectionRange(a,b);}catch(_){} }
  document.addEventListener('input',apply,true);document.addEventListener('change',apply,true);
})();

