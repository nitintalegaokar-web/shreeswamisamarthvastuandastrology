
(() => {
  'use strict';
  const choices = new Map();
  let selectNewPages = true;
  let allowMatchmaking = false;
  let signature = '';
  const options = document.getElementById('report-page-options');
  const report = document.getElementById('printReport');
  const status = document.getElementById('report-page-selection-status');
  if (!options || !report || !status) return;
  options.tabIndex = -1;
  function pages() {
    const occurrences = new Map();
    return [...report.children].filter(page => page.classList.contains('report-page') && page.dataset.reportSection!=='basic').sort((a,b)=>{const rank=p=>p.dataset.reportSection==='cover'?0:p.dataset.reportSection==='vedic-information'?1:2;return rank(a)-rank(b);}).map((page, index) => {
      const section = page.dataset.reportSection || 'page-' + (index + 1);
      const occurrence = (occurrences.get(section) || 0) + 1;
      occurrences.set(section, occurrence);
      const key = occurrence === 1 ? section : section + '::' + occurrence;
      const title = section === 'cover' ? 'Front page · Ucchishta Mahaganpati' : (page.querySelector('.report-page-title')?.textContent || section).trim().replace(/^\d+\.\s*/, '');
      return {page, key, title, index};
    });
  }
  function updateStatus(current) {
    current=current.filter(item=>item.page.dataset.reportSection!=='matchmaking'||allowMatchmaking);
    const count = current.filter(item => choices.get(item.key)).length;
    if (count > 0) delete status.dataset.printError;
    status.textContent = count === 0 && status.dataset.printError === 'true' ? 'Select at least one page to print.' : count + ' of ' + current.length + ' pages selected.';
    status.dataset.empty = String(count === 0);
  }
  function refresh() {
    const current = pages();
    current.forEach(item => { if (!choices.has(item.key)) { const section=item.page.dataset.reportSection;choices.set(item.key,section!=='matchmaking'&&(choices.has(section)?choices.get(section):selectNewPages)); } });
    const nextSignature = JSON.stringify(current.map(item => [item.key, item.title]));
    if (signature !== nextSignature) {
      options.replaceChildren();
      const groups=new Map();current.filter(item=>item.page.dataset.reportSection!=='matchmaking').forEach(item=>{const id=item.page.dataset.reportSection;if(!groups.has(id))groups.set(id,[]);groups.get(id).push(item);});
      groups.forEach(group => {const item=group[0];
        const label = document.createElement('label');
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.dataset.reportPageKey = item.key;
        const text = document.createElement('span');
        text.textContent=item.title.replace(/ · \d+ \/ \d+$/, '');
        const count=document.createElement('span');count.className='report-page-count';count.textContent=String(group.length).padStart(2,'0');count.title='Minimum pages; long reports continue automatically.';checkbox.dataset.reportSection=item.page.dataset.reportSection;
        label.append(checkbox, text, count);
        options.appendChild(label);
      });
      signature = nextSignature;
    }
    options.querySelectorAll('input[data-report-page-key]').forEach(checkbox => { const group=current.filter(item=>item.page.dataset.reportSection===checkbox.dataset.reportSection);checkbox.checked=group.length>0&&group.every(item=>choices.get(item.key));checkbox.indeterminate=group.some(item=>choices.get(item.key))&&!checkbox.checked; });
    updateStatus(current);
    return current;
  }
  function setAll(selected) {
    delete status.dataset.printError;
    selectNewPages = selected;allowMatchmaking=false;
    pages().forEach(item => choices.set(item.key, selected&&item.page.dataset.reportSection!=='matchmaking'));
    refresh();
  }
  window.KPReportPages = {
    refresh,
    selected() { return refresh().filter(item => choices.get(item.key)).map(item => item.page); },
    html() { return this.selected().map(page => page.outerHTML).join('\n'); },
    selectAll() { setAll(true); },
    clear() { setAll(false); },
    excludeMatchmaking(){allowMatchmaking=false;pages().filter(item=>item.page.dataset.reportSection==='matchmaking').forEach(item=>choices.set(item.key,false));refresh();},
    selectSections(sections) {
      const selected = new Set(sections);allowMatchmaking=selected.has('matchmaking');
      selectNewPages = false;
      pages().forEach(item => choices.set(item.key, selected.has(item.page.dataset.reportSection)));
      refresh();
    }
  };
  options.addEventListener('input', event => event.stopPropagation());
  options.addEventListener('change', event => {
    const checkbox = event.target.closest('input[data-report-page-key]');
    if (!checkbox) return;
    pages().filter(item=>item.page.dataset.reportSection===checkbox.dataset.reportSection).forEach(item=>choices.set(item.key,checkbox.checked));
    delete status.dataset.printError;
    const current = pages();
    selectNewPages = current.length > 0 && current.every(item => choices.get(item.key));
    updateStatus(current);
    event.stopPropagation();
  });
  document.getElementById('report-select-all').addEventListener('click', () => setAll(true));
  document.getElementById('report-clear-pages').addEventListener('click', () => setAll(false));
  new MutationObserver(refresh).observe(report, {childList:true});
  refresh();
})();

