
(function(){
  const LOCK_VERSION='TABS_1_6_CALCULATION_LOCK_v22';
  window.KP_TABS_1_6_LOCKED=true;
  window.KP_TABS_1_6_LOCK_VERSION=LOCK_VERSION;

  // Outputs that must remain calculated, not manually editable.
  const calculatedIds = [
    // Tab 1
    'ayanValue',
    // Tab 2
    'placeStdLon','lonDifference',
    // Tab 3
    'lmtDeg','lmtDegMin','lmtKala','lmtKalaSec','lmtSecToMin','lmtTotalTime',
    'lmtClockTime','lmtSignedDifference','lmtFinal',
    // Tab 4 calculated outputs (manual fields remain editable)
    'stLmtDifference','stTenSixCorrection','stGrandTotal','st24Adjustment',
    'birthPlaceSiderealTime','stBirthTimeAgain','stSmallTimeAgain',
    'stDiff1','stDiffSeconds','stDiff2','stDiff2Seconds',
    // Tab 5 calculated outputs
    'r5_diff3_10','r5_diff3_11','r5_diff3_12','r5_diff3_1','r5_diff3_2','r5_diff3_3',
    'r5_small2_10','r5_small2_11','r5_small2_12','r5_small2_1','r5_small2_2','r5_small2_3',
    'r5_ishta_10','r5_ishta_11','r5_ishta_12','r5_ishta_1','r5_ishta_2','r5_ishta_3',
    'r5_smallplus_10','r5_smallplus_11','r5_smallplus_12','r5_smallplus_1','r5_smallplus_2','r5_smallplus_3',
    'r5_geoayan_10','r5_geoayan_11','r5_geoayan_12','r5_geoayan_1','r5_geoayan_2','r5_geoayan_3',
    'r5_nirayan_10','r5_nirayan_11','r5_nirayan_12','r5_nirayan_1','r5_nirayan_2','r5_nirayan_3',
    'r5_bhava_10','r5_bhava_11','r5_bhava_12','r5_bhava_1','r5_bhava_2','r5_bhava_3',
    'r5_rashi_10','r5_rashi_11','r5_rashi_12','r5_rashi_1','r5_rashi_2','r5_rashi_3',
    'r5_opposite_10','r5_opposite_11','r5_opposite_12','r5_opposite_1','r5_opposite_2','r5_opposite_3',
    'r5_calc_diff1_1','r5_calc_diff2_1','r5_calc_diff3_1','r5_calc_ishta_1',
    'r5_calc_diff1_2','r5_calc_diff2_2','r5_calc_diff3_2','r5_calc_ishta_2',
    'r5_calc_diff1_3','r5_calc_diff2_3','r5_calc_diff3_3','r5_calc_ishta_3',
    'r5_calc_diff1_10','r5_calc_diff2_10','r5_calc_diff3_10','r5_calc_ishta_10',
    'r5_calc_diff1_11','r5_calc_diff2_11','r5_calc_diff3_11','r5_calc_ishta_11',
    'r5_calc_diff1_12','r5_calc_diff2_12','r5_calc_diff3_12','r5_calc_ishta_12',
    // Tab 6 calculated outputs
    ...Array.from({length:9},(_,i)=>`p6_motion_${i}`),
    ...Array.from({length:9},(_,i)=>`p6_total_${i}`),
    ...Array.from({length:9},(_,i)=>`p6_birth_${i}`),
    ...Array.from({length:9},(_,i)=>`p6_add_${i}`),
    ...Array.from({length:9},(_,i)=>`p6_ayan_${i}`),
    ...Array.from({length:9},(_,i)=>`p6_final_${i}`),
    ...Array.from({length:9},(_,i)=>`p6_rashi_${i}`)
  ];

  function applyLock(){
    calculatedIds.forEach(id=>{
      const el=document.getElementById(id);
      if(el){
        el.readOnly=true;
        el.setAttribute('data-calculation-locked','true');
      }
    });
    ['basic','ayan','lmt','stcalc','raphael5','planet'].forEach(id=>{
      const sec=document.getElementById(id);
      if(sec) sec.setAttribute('data-calculation-lock',LOCK_VERSION);
    });
  }
  document.addEventListener('DOMContentLoaded',()=>{
    applyLock();
    setTimeout(applyLock,100);
    setTimeout(applyLock,500);
  });
})();

