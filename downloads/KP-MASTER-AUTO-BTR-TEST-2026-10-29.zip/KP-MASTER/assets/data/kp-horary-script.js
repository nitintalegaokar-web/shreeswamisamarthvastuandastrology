
/* The 249/2193 KP horary ranges are the 243/2187 nakshatra/sub[/sub-sub]
 * divisions, split at the six sign boundaries falling inside a division.
 * A selected range's start is the sidereal Ascendant. Planetary clocks keep
 * the real Prashna date/time; only the house orientation is solved below.
 */
(() => {
  'use strict';
  const FULL=1296000,SIGN=108000,NAK=48000,RAD=Math.PI/180;
  const ORDER=['Ke','Ve','Su','Mo','Ma','Ra','Ju','Sa','Me'];
  const YEARS={Ke:7,Ve:20,Su:6,Mo:10,Ma:7,Ra:18,Ju:16,Sa:19,Me:17};
  const SIGN_CODES=['Ar','Ta','Ge','Ca','Le','Vi','Li','Sc','Sg','Cp','Aq','Pi'];
  const SIGNS=['मेष','वृषभ','मिथुन','कर्क','सिंह','कन्या','तुला','वृश्चिक','धनु','मकर','कुंभ','मीन'];
  const SIGN_NAMES=['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
  const SIGN_LORDS=['Ma','Ve','Me','Mo','Su','Me','Ve','Ma','Ju','Sa','Sa','Ju'];
  const HOUSE_FIELDS=['nirayan','minus','bhava','rashi','opposite'];
  const HOUSE_IDS=[10,11,12,1,2,3];
  const PLANETS=['Su','Mo','Ma','Me','Ju','Ve','Sa','Ra','Ke'];
  const PLANET_NAMES=['रवी','चंद्र','मंगळ','बुध','गुरु','शुक्र','शनि','राहू','केतू'];
  const DEFAULT_CATEGORIES=['Personal','Marriage','Career','Education','Health','Property','Travel','Legal'];
  const byId=id=>document.getElementById(id),value=id=>String(byId(id)?.value||'').trim();
  const set=(id,text)=>{const field=byId(id);if(field)field.value=text;};
  const norm=degrees=>((degrees%360)+360)%360;
  const signed=degrees=>((degrees+540)%360)-180;
  let current=null,signature='',timer;
  function formatArcseconds(arcseconds){
    const total=((Math.round(arcseconds)%FULL)+FULL)%FULL;
    return Math.floor(total/3600)+':'+String(Math.floor(total%3600/60)).padStart(2,'0')+':'+String(total%60).padStart(2,'0');
  }
  const dms=degrees=>formatArcseconds(degrees*3600);
  function systemNumber(system=249){
    const selected=Number(system);
    if(selected!==249&&selected!==2193)throw new Error('Choose the 249 or 2193 KP Horary system.');
    return selected;
  }
  function makeCatalogue(system){
    const table=[];
    for(let nakshatra=0;nakshatra<27;nakshatra++){
      const starIndex=nakshatra%9,stl=ORDER[starIndex];let cursor=nakshatra*NAK*3;
      for(let part=0;part<9;part++){
        const subIndex=(starIndex+part)%9,sbl=ORDER[subIndex],subStart=cursor,subEnd=cursor+1200*YEARS[sbl];
        function add(start,end,ssl){
          let startUnit=start;
          while(startUnit<end){
            const signIndex=Math.floor(startUnit/(SIGN*3)),limit=Math.min(end,(signIndex+1)*SIGN*3);
            let subsub=ssl;
            if(!subsub){
              let boundary=subStart;
              for(let inner=0;inner<9;inner++){
                const lord=ORDER[(subIndex+inner)%9];boundary+=10*YEARS[sbl]*YEARS[lord];
                if(startUnit<boundary){subsub=lord;break;}
              }
            }
            table.push(Object.freeze({number:table.length+1,system,start:startUnit/10800,end:limit/10800,startArcseconds:startUnit/3,endArcseconds:limit/3,startThirdArcseconds:startUnit,endThirdArcseconds:limit,signIndex,sign:SIGN_CODES[signIndex],signName:SIGN_NAMES[signIndex],sgl:SIGN_LORDS[signIndex],stl,sbl,sl:sbl,ssl:subsub,nakshatraIndex:nakshatra}));
            startUnit=limit;
          }
        }
        if(system===249)add(subStart,subEnd,null);
        else{
          let start=subStart;
          for(let inner=0;inner<9;inner++){
            const ssl=ORDER[(subIndex+inner)%9],end=start+10*YEARS[sbl]*YEARS[ssl];
            add(start,end,ssl);start=end;
          }
        }
        cursor=subEnd;
      }
    }
    if(table.length!==system||table[0].startArcseconds!==0||table[system-1].endArcseconds!==FULL)throw new Error('The '+system+' horary ranges could not be initialized.');
    return Object.freeze(table);
  }
  const TABLES=Object.freeze({249:makeCatalogue(249),2193:makeCatalogue(2193)});
  function catalogue(system=249){return TABLES[systemNumber(system)].map(entry=>({...entry}));}
  function entry(number,system=249){
    const size=systemNumber(system);
    const text=String(number??'').trim(),index=Number(text);
    if(!/^\d+$/.test(text)||!Number.isInteger(index)||index<1||index>size)throw new Error('Choose a whole KP Horary number from 1 to '+size+'.');
    return TABLES[size][index-1];
  }
  function status(text,ready=null){
    const field=byId('horary-status');if(!field)return;
    field.textContent=text;
    if(ready===null)delete field.dataset.ready;else field.dataset.ready=String(ready);
  }
  function coordinate(text,label){
    const match=/^([+-]?)(\d+(?:\.\d+)?)(?::([0-5]?\d(?:\.\d+)?))?(?::([0-5]?\d(?:\.\d+)?))?$/.exec(String(text||'').trim());
    if(!match||Number(match[3]||0)>=60||Number(match[4]||0)>=60)throw new Error('Enter a valid '+label+' in decimal degrees or D:M:S.');
    return (match[1]==='-'?-1:1)*(Number(match[2])+Number(match[3]||0)/60+Number(match[4]||0)/3600);
  }
  function offset(){
    const input=value('birth-utc-offset');
    const result=input===''?coordinate(value('stdLon'),'standard meridian')/15:Number(input);
    if(!Number.isFinite(result)||Math.abs(result)>14)throw new Error('Use a standard time offset from UTC−14 to UTC+14.');
    return result;
  }
  function daylightSaving(){
    const text=value('birth-dst-minutes'),minutes=text===''?0:Number(text);
    if(!Number.isInteger(minutes)||Math.abs(minutes)>120)throw new Error('Enter daylight saving as whole minutes between −120 and +120.');
    return minutes;
  }
  function coordinateDms(degrees){
    const total=Math.round(Math.abs(degrees)*3600);
    return (degrees<0?'-':'')+Math.floor(total/3600)+':'+String(Math.floor(total%3600/60)).padStart(2,'0')+':'+String(total%60).padStart(2,'0');
  }
  function readMoment(){
    const date=value('dob'),time=value('birthTime');
    const calendar=new Date(date+'T00:00:00Z');
    if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(calendar.getTime())||calendar.toISOString().slice(0,10)!==date)throw new Error('Enter the Prashna date.');
    if(!/^([01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/.test(time))throw new Error('Enter the Prashna time, including hours and minutes.');
    const timezone=offset(),dstMinutes=daylightSaving(),utc=new Date(Date.parse(date+'T'+(time.length===5?time+':00':time)+'Z')-timezone*3600000-dstMinutes*60000);
    const latitude=coordinate(value('lat'),'latitude'),longitude=coordinate(value('lon'),'longitude');
    if(Math.abs(latitude)>=90||Math.abs(longitude)>180)throw new Error('Enter latitude within −90° to +90° and longitude within −180° to +180°.');
    return {date:window.KPEphemeris.dateValue(utc),latitude,longitude,timezone,dstMinutes,localDate:date,localTime:time,place:value('birthPlace')};
  }
  function ascendantAt(theta,latitude,eps){
    const angle=theta*RAD;
    return norm(Math.atan2(Math.cos(angle),-Math.sin(angle)*Math.cos(eps)-Math.tan(latitude*RAD)*Math.sin(eps))/RAD);
  }
  function solveSidereal(target,latitude,obliquity){
    if(!Number.isFinite(latitude)||Math.abs(latitude)>=90-obliquity)throw new Error('Placidus horary cusps are unavailable within the polar circles. Choose a location below '+(90-obliquity).toFixed(2)+'° latitude.');
    const eps=obliquity*RAD,origin=ascendantAt(0,latitude,eps),wanted=origin+norm(target-origin);
    if(Math.abs(wanted-origin)<1e-11)return 0;
    let previousAngle=origin,previousUnwrapped=origin,previousTheta=0;
    for(let theta=2;theta<=360;theta+=2){
      const angle=ascendantAt(theta,latitude,eps),unwrapped=previousUnwrapped+signed(angle-previousAngle);
      if(unwrapped>=wanted-1e-10){
        let left=previousTheta,right=theta,leftAngle=previousAngle,leftUnwrapped=previousUnwrapped;
        for(let iteration=0;iteration<65&&right-left>1e-11;iteration++){
          const middle=(left+right)/2,middleAngle=ascendantAt(middle,latitude,eps),middleUnwrapped=leftUnwrapped+signed(middleAngle-leftAngle);
          if(middleUnwrapped<wanted){left=middle;leftAngle=middleAngle;leftUnwrapped=middleUnwrapped;}else right=middle;
        }
        const solution=norm((left+right)/2);
        if(Math.abs(signed(ascendantAt(solution,latitude,eps)-target))<1e-7)return solution;
        break;
      }
      previousAngle=angle;previousUnwrapped=unwrapped;previousTheta=theta;
    }
    // Close to the polar-circle limit, a very short sidereal interval can
    // sweep more than 180 degrees of Ascendant. Select the rising analytic
    // root instead of mistaking that sweep for a descending wrap.
    const lambda=target*RAD,a=Math.cos(lambda),b=Math.cos(eps)*Math.sin(lambda),c=-Math.tan(latitude*RAD)*Math.sin(eps)*Math.sin(lambda);
    const radius=Math.hypot(a,b),phase=Math.atan2(b,a),angle=Math.acos(Math.max(-1,Math.min(1,c/radius)));
    for(const candidate of [norm((phase+angle)/RAD),norm((phase-angle)/RAD)]){
      if(Math.abs(signed(ascendantAt(candidate,latitude,eps)-target))<1e-7)return candidate;
    }
    throw new Error('The selected horary Ascendant could not be solved for this latitude.');
  }
  function calculate(number,dateValue,latitude,system=249){
    const selected=entry(number,system),date=window.KPEphemeris.dateValue(dateValue),lat=Number(latitude);
    if(latitude===null||String(latitude).trim()===''||!Number.isFinite(lat)||Math.abs(lat)>=90)throw new Error('Enter a valid horary latitude.');
    if(!window.KPTransitHouses)throw new Error('The Placidus house calculation is unavailable.');
    const obliquity=Astronomy.e_tilt(Astronomy.MakeTime(date)).tobl,ayanamsha=window.KPEphemeris.ayanamsha(date);
    const tropicalTarget=norm(selected.start+ayanamsha),theta=solveSidereal(tropicalTarget,lat,obliquity);
    const orientation=signed(theta-Astronomy.SiderealTime(date)*15);
    const houses=window.KPTransitHouses.calculate(date,lat,orientation);
    if(!Array.isArray(houses.cusps)||houses.cusps.length!==12||houses.cusps.some(cusp=>!Number.isFinite(cusp))||Math.abs(signed(houses.ascendant-selected.start))>1e-6)throw new Error('The calculated horary cusps could not be verified.');
    // The numbered Ascendant is an exact interval boundary. Numerical house
    // solving must not move it to the preceding sign/sub at the 0° seam.
    const cusps=houses.cusps.map(norm);cusps[0]=selected.start;cusps[6]=norm(selected.start+180);
    return {ready:true,number:selected.number,horarySystem:selected.system,entry:{...selected},utc:date.toISOString(),latitude:lat,ayanamsha,ascendant:selected.start,cusps,system:'Placidus',units:'degrees',method:'KP '+selected.system+' nakshatra/sub'+(selected.system===2193?'/sub-sub':'')+' ranges; selected range start Ascendant'};
  }
  function writeCusps(model){
    HOUSE_IDS.forEach(house=>{
      const absolute=Math.round(norm(model.cusps[house-1])*3600)%FULL,index=Math.floor(absolute/SIGN),remaining=absolute-index*SIGN;
      set('r5_nirayan_'+house,formatArcseconds(absolute));set('r5_minus_'+house,formatArcseconds(index*SIGN));
      set('r5_bhava_'+house,formatArcseconds(remaining));set('r5_rashi_'+house,SIGNS[index]);set('r5_opposite_'+house,SIGNS[(index+6)%12]);
    });
  }
  function clearCusps(){HOUSE_IDS.forEach(house=>HOUSE_FIELDS.forEach(field=>set('r5_'+field+'_'+house,'')));}
  function preview(){
    const field=byId('horary-preview');if(!field)return;
    try{
      const selected=entry(value('horary-number'),value('horary-system')||249);
      field.textContent='No. '+selected.number+' / '+selected.system+' · '+selected.signName+' '+formatArcseconds(selected.startArcseconds%SIGN)+' · SGL '+selected.sgl+' · STL '+selected.stl+' · SBL '+selected.sbl+' · SSL '+selected.ssl;
    }catch(error){field.textContent=error.message;}
  }
  function refreshControls(){
    const horary=value('chart-kind')==='horary',group=byId('horary-inputs');
    if(group)group.hidden=!horary;
    if(byId('birth-dst-minutes'))byId('birth-dst-minutes').disabled=!horary;
    const size=value('horary-system')==='2193'?2193:249,number=byId('horary-number');
    if(number){number.max=String(size);number.placeholder='1 to '+size;}
    if(byId('horary-number-label'))byId('horary-number-label').textContent='KP Horary number · 1 to '+size;
    preview();
    if(!horary){current=null;signature='';status('Birth chart: enter the native’s birth date, time and place below.');}
  }
  function apply(){
    refreshControls();
    if(value('chart-kind')!=='horary')return null;
    try{
      const moment=readMoment(),number=value('horary-number'),system=value('horary-system')||249;
      const key=JSON.stringify([number,system,moment.date.toISOString(),moment.latitude,moment.longitude,value('ayanValue'),value('kp-ayanamsha-source'),value('dob')]);
      if(!current||signature!==key){current=calculate(number,moment.date,moment.latitude,system);signature=key;}
      writeCusps(current);
      const selected=current.entry;
      status('Prashna No. '+selected.number+' / '+selected.system+' · Ascendant '+selected.signName+' '+formatArcseconds(selected.startArcseconds%SIGN)+' ('+selected.sgl+'–'+selected.stl+'–'+selected.sbl+'–'+selected.ssl+'). Placidus cusps use this numbered Ascendant; planets use the entered Prashna date/time, UTC offset and daylight saving.',true);
      return JSON.parse(JSON.stringify(current));
    }catch(error){
      current=null;signature='';clearCusps();status('Prashna calculation unavailable: '+error.message,false);return null;
    }
  }
  function now(){
    try{
      const local=new Date(Date.now()+offset()*3600000+daylightSaving()*60000);
      set('dob',local.toISOString().slice(0,10));set('birthTime',local.toISOString().slice(11,19));
      for(const id of ['p6_row_date_1','p6_row_date_2']){const field=byId(id);if(field)field.dataset.auto='1';}
      window.calculateAll?.();
    }catch(error){status(error.message,false);}
  }
  function validateCategories(text){
    try{
      if(typeof text!=='string'||text.length>10000)return false;
      const categories=JSON.parse(text);
      return Array.isArray(categories)&&categories.length>0&&categories.length<=50&&categories.every(item=>typeof item==='string'&&item.trim()===item&&item.length>0&&item.length<=100)&&new Set(categories.map(item=>item.toLocaleLowerCase())).size===categories.length;
    }catch(error){return false;}
  }
  function categories(){
    const text=value('chart-categories');
    if(!text)return DEFAULT_CATEGORIES.slice();
    if(!validateCategories(text))throw new Error('Saved chart categories are invalid.');
    return JSON.parse(text);
  }
  function refreshCategories(){
    const list=byId('chart-category-list');if(!list)return;
    try{list.replaceChildren(...categories().map(name=>{const item=document.createElement('option');item.value=name;return item;}));}catch(error){status(error.message,false);}
  }
  function addCategory(){
    try{
      const category=value('chart-category');
      if(!category){byId('chart-category')?.focus();status('Enter a category, then select Add new category.');return;}
      if(category.length>100)throw new Error('Keep a category within 100 characters.');
      const options=categories();
      if(!options.some(item=>item.toLocaleLowerCase()===category.toLocaleLowerCase())){
        if(options.length>=50)throw new Error('A chart can store up to 50 categories.');
        options.push(category);set('chart-categories',JSON.stringify(options));
      }
      refreshCategories();status('Category saved: '+category);window.renderReport?.();
    }catch(error){status(error.message,false);}
  }
  function toss(){
    try{
      const size=systemNumber(value('horary-system')||249),range=4294967296,limit=range-range%size;
      if(!window.crypto?.getRandomValues)throw new Error('Secure random numbers are unavailable in this browser. Enter a number manually.');
      const buffer=new Uint32Array(1);do{window.crypto.getRandomValues(buffer);}while(buffer[0]>=limit);
      set('horary-number',String(buffer[0]%size+1));preview();window.calculateAll?.();
    }catch(error){status(error.message,false);}
  }
  function clearQuestion(){
    set('horary-question','');set('chart-notes','');set('chart-category','');set('horary-number','');
    current=null;signature='';clearCusps();preview();status('Prashna question cleared. Enter a Horary number to calculate again.');window.calculateAll?.();
  }
  function applyPlanets(){
    if(value('chart-kind')!=='horary'&&value('instant-prashna')!=='1')return null;
    const allFields=['motion','hours','minutes','total','birth','add','ayan','final','rashi'];
    try{
      if(value('instant-prashna')!=='1')entry(value('horary-number'),value('horary-system')||249);
      const moment=readMoment(),date=moment.date,positions=window.KPEphemeris.positions(date);
      const low=Math.max(Date.parse('1900-01-01T00:00:00Z'),date.getTime()-21600000),high=Math.min(Date.parse('2101-01-01T00:00:00Z')-1,date.getTime()+21600000);
      const before=window.KPEphemeris.positions(new Date(low)),after=window.KPEphemeris.positions(new Date(high)),span=(high-low)/86400000,result={};
      PLANETS.forEach((id,index)=>{
        const absolute=Math.round(norm(positions[id])*3600)%FULL,signIndex=Math.floor(absolute/SIGN),motion=signed(after[id]-before[id])/span;
        if(!Number.isFinite(absolute)||!Number.isFinite(motion))throw new Error('The query planets could not be calculated.');
        const retro=motion<0&&index<7;
        set('p6_motion_'+index,dms(Math.abs(motion))+(retro?' R':''));
        for(const field of ['hours','minutes','total'])set('p6_'+field+'_'+index,'');
        set('p6_birth_'+index,formatArcseconds(absolute));set('p6_add_'+index,formatArcseconds(absolute));
        set('p6_ayan_'+index,formatArcseconds(signIndex*SIGN));set('p6_final_'+index,formatArcseconds(absolute%SIGN)+(retro?' R':''));set('p6_rashi_'+index,SIGNS[signIndex]);
        const final=byId('p6_final_'+index);if(final)final.dataset.rashi=SIGNS[signIndex];
        result[PLANET_NAMES[index]]=norm(positions[id])*3600;
      });
      if(byId('p6_birth_pos_date'))byId('p6_birth_pos_date').value=moment.localDate;
      const source=byId('p6-ephemeris-status');
      if(source){source.dataset.ready='true';source.textContent='Horary planets: exact Prashna moment '+moment.localDate+' '+moment.localTime+' · UTC'+(moment.timezone>=0?'+':'')+moment.timezone+' · DST '+moment.dstMinutes+' minutes. The final positions use this moment; 05:30 daily interpolation and its hour/minute corrections are not used.';}
      return result;
    }catch(error){
      PLANETS.forEach((id,index)=>allFields.forEach(field=>set('p6_'+field+'_'+index,'')));
      const source=byId('p6-ephemeris-status');if(source){source.dataset.ready='false';source.textContent='Horary planets unavailable: '+error.message;}
      return {};
    }
  }
  function initialize(){
    byId('horary-now')?.addEventListener('click',now);
    byId('horary-toss')?.addEventListener('click',toss);
    byId('horary-clear')?.addEventListener('click',clearQuestion);
    byId('chart-add-category')?.addEventListener('click',addCategory);
    const changed=event=>{
      const id=event.target?.id||'';
      if(!['chart-kind','horary-system','horary-number','horary-question','chart-category','chart-gender','chart-notes','dob','birthTime','lat','lon','stdLon','birth-utc-offset','birth-dst-minutes','dayAyan','daySum'].includes(id))return;
      if(id==='birth-utc-offset'){
        try{set('stdLon',coordinateDms(offset()*15));}catch(error){/* Calculation shows validation. */}
      }
      if(id==='stdLon'){
        try{set('birth-utc-offset',String(coordinate(value('stdLon'),'standard meridian')/15));}catch(error){/* Calculation shows validation. */}
      }
      if(id==='chart-kind'&&value('chart-kind')==='horary'){
        set('p6-ephemeris-source','automatic');set('st-ephemeris-source','automatic');
        for(const key of ['p6_row_date_1','p6_row_date_2']){const field=byId(key);if(field)field.dataset.auto='1';}
      }
      refreshControls();
      if(document.readyState!=='complete'&&!event.isTrusted)return;
      clearTimeout(timer);timer=setTimeout(()=>window.calculateAll?.(),100);
    };
    document.addEventListener('input',changed);document.addEventListener('change',changed);
    refreshControls();refreshCategories();
    if(value('chart-kind')==='horary')apply();
  }
  window.KPHorary=Object.freeze({catalogue,calculate,apply,applyPlanets,nativeMoment:readMoment,validateCategories,refresh:()=>{refreshControls();refreshCategories();},getData:()=>current?JSON.parse(JSON.stringify(current)):null});
  window.dispatchEvent(new CustomEvent('kp-horary-ready'));
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

