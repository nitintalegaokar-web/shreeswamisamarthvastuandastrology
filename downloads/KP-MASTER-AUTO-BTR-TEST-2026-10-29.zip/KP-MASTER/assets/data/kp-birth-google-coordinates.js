
(()=>{'use strict';function init(){const button=document.getElementById('birth-google-coordinates'),place=document.getElementById('birthPlace');if(!button||!place)return;button.onclick=()=>{const value=place.value.trim();if(!value){place.focus();window.showToast?.('Enter the birthplace first.','error');return;}const query=value+' latitude longitude coordinates';window.open('https://www.google.com/search?q='+encodeURIComponent(query),'_blank','noopener,noreferrer');};}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();})();

