
(() => {
  'use strict';
  const catalogue=JSON.parse(document.getElementById('kp-prediction-catalogue').textContent);
  const ROLES=['CSL','STL','SBL'],PAGE_SIZE=60;
  const STATUS={matched:'Matched house group',partial:'Partial house group',unmatched:'No house group match',review:'Additional rule review',incomplete:'Chart incomplete'};
  const ISSUE_LABELS={'support-house-language-difference':'English and Marathi supporting houses differ','main-house-language-difference':'English and Marathi main houses differ','support-operator-language-difference':'English and Marathi group operators differ','missing-translation':'Translation unavailable','missing-en-translation':'English translation unavailable','en-support-conditional':'English source includes additional supporting conditions','mr-support-conditional':'Marathi source includes additional supporting conditions','en-main-conditional':'English main-house entry includes conditions','mr-main-conditional':'Marathi main-house entry includes conditions','en-main-missing':'English main house is missing','mr-main-missing':'Marathi main house is missing','en-support-missing':'English supporting group is missing'};
  const $=id=>document.getElementById(id);
  const escape=text=>String(text??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const unique=values=>[...new Set((values||[]).filter(n=>Number.isInteger(n)&&n>=1&&n<=12))].sort((a,b)=>a-b);
  const housesText=values=>(values||[]).join(', ')||'—';
  const issueText=issue=>ISSUE_LABELS[issue]||String(issue).replace(/-/g,' ');
  let initialized=false,cache=null,signature=null,timer=null,pageIndex=0,selectedEvent=null,snapshotKey=null,snapshotHTML='';
  function normalizeOptions(options={}){
    const layers=ROLES.filter(role=>Array.isArray(options.layers)?options.layers.includes(role):true);
    return {method:options.method==='sixfold'?'sixfold':'fourfold',chainMode:options.chainMode==='cusp-lords'?'cusp-lords':'csl-chain',layers:layers.length?layers:['CSL'],requireMain:Boolean(options.requireMain),language:options.language==='marathi'?'marathi':'english'};
  }
  function analyze(model,configuration={}){
    const options=normalizeOptions(configuration),source=configuration.catalogue||catalogue,events=Array.isArray(source.events)?source.events:[];
    const fields=options.method==='sixfold'?['A','B','C','D','E','F']:['A','B','C','D'];
    const planets=Array.isArray(model?.planets)?model.planets:[],houses=Array.isArray(model?.houses)?model.houses:[];
    const byId=Object.fromEntries(planets.map(p=>[p.id,p])),methodRows=Object.fromEntries((model?.[options.method]?.planets||[]).map(row=>[row.id,row]));
    let ready=Boolean(model?.ready&&houses.length===12&&planets.length===9),reason=ready?'':model?.reason||'Complete all twelve natal cusps and all natal planet positions.';
    const chains=houses.map(cusp=>{
      const csl=byId[cusp.sl],ids=options.chainMode==='csl-chain'?{CSL:cusp.sl,STL:csl?.stl,SBL:csl?.sl}:{CSL:cusp.sl,STL:cusp.stl,SBL:cusp.sl};
      const layers=ROLES.map(role=>{
        const id=ids[role],row=methodRows[id],levels=Object.fromEntries(fields.map(field=>[field,unique(row?.[field]||[])]));
        if(!byId[id]||!row){ready=false;reason='Complete the natal cusps and planet significators before calculating predictions.';}
        return {role,id:id||null,levels,houses:unique(fields.flatMap(field=>levels[field])),selected:options.layers.includes(role)};
      });
      return {cusp:cusp.id,CSL:ids.CSL||null,STL:ids.STL||null,SBL:ids.SBL||null,layers,houses:unique(layers.filter(layer=>layer.selected).flatMap(layer=>layer.houses))};
    });
    const results=events.map(event=>{
      const mains=unique(event.mainHouses),groups=(event.supportingGroups||[]).map(unique).filter(group=>group.length);
      const eligible=event.automaticEligible===true&&mains.length>0&&groups.length>0;
      const proofs=mains.flatMap(main=>{
        const chain=chains.find(chain=>chain.cusp===main);if(!chain)return [];
        const selectedLayers=chain.layers.filter(layer=>layer.selected);
        return (groups.length?groups:[unique(event.supportingHouses)]).map(group=>{
          const required=unique([...group,...(options.requireMain?[main]:[])]),matched=required.filter(h=>chain.houses.includes(h)),missing=required.filter(h=>!chain.houses.includes(h));
          const contributions=required.map(house=>({house,sources:selectedLayers.flatMap(layer=>Object.keys(layer.levels).filter(level=>layer.levels[level].includes(house)).map(level=>({role:layer.role,planet:layer.id,level})))}));
          return {cusp:main,chain: {CSL:chain.CSL,STL:chain.STL,SBL:chain.SBL},layers:selectedLayers,requiredHouses:required,signifiedHouses:[...chain.houses],matchedHouses:matched,missingHouses:missing,contributions,complete:required.length>0&&missing.length===0};
        });
      });
      const best=[...proofs].sort((a,b)=>Number(b.complete)-Number(a.complete)||(b.matchedHouses.length/Math.max(b.requiredHouses.length,1))-(a.matchedHouses.length/Math.max(a.requiredHouses.length,1))||b.matchedHouses.length-a.matchedHouses.length)[0]||null;
      const status=!ready?'incomplete':!eligible?'review':proofs.some(proof=>proof.complete)?'matched':best?.matchedHouses.length?'partial':'unmatched';
      return {id:event.id,event:event.event,mainHouses:mains,supportingHouses:unique(event.supportingHouses),supportingGroups:groups,automaticEligible:eligible,status,proof:best,proofs,sources:event.sources||{},issues:[...(event.issues||[])]};
    });
    const counts=Object.fromEntries(Object.keys(STATUS).map(status=>[status,results.filter(row=>row.status===status).length]));
    return {ready,reason,options,fields,chains,results,counts,metadata:source.metadata||{},issues:source.issues||[]};
  }
  function uiOptions(){return normalizeOptions({method:$('pred-method')?.value,chainMode:$('pred-chain-mode')?.value,layers:[...document.querySelectorAll('#pred-layers input:checked')].map(input=>input.value),requireMain:$('pred-require-main')?.checked,language:window.KPPreferences?.get().language});}
  function label(row,language=uiOptions().language){const key=language==='marathi'?'mr':'en',fallback=key==='mr'?'en':'mr';return row.event?.[key]||row.event?.[fallback]||('Event '+row.id);}
  function sourceFor(row,language=uiOptions().language){return row.sources?.[language==='marathi'?'mr':'en']||row.sources?.[language==='marathi'?'en':'mr']||{};}
  function planetLabel(id,model=window.currentKPModel){
    if(!id)return '—';const markers=window.KPPreferences?.get().notationMarkers===false?[]:window.KPDisplay?.getNotations(id,model)||[];
    return '<span class="kp-planet-reference" data-planet-ref="'+escape(id)+'"><span class="kp-planet-label">'+escape(id)+'</span>'+markers.map(marker=>'<small class="kp-notation-marker" data-marker="'+escape(marker)+'">'+escape(marker)+'</small>').join('')+'</span>';
  }
  function chainTable(data,print=false){
    if(!data.ready)return '<p>'+escape(data.reason)+'</p>';
    return '<table'+(print?' data-pred-print-chains="true"':' id="pred-chain-table"')+' aria-label="All twelve cusp lord chains"><colgroup><col style="width:7%"><col style="width:25%"><col style="width:25%"><col style="width:25%"><col style="width:18%"></colgroup><thead><tr><th>Cusp</th><th>CSL · significators</th><th>STL · significators</th><th>SBL · significators</th><th>Selected union</th></tr></thead><tbody>'+data.chains.map(chain=>'<tr data-pred-cusp="'+chain.cusp+'"><td>'+chain.cusp+'</td>'+chain.layers.map(layer=>'<td class="pred-chain-cell" data-pred-role="'+layer.role+'" data-pred-planet="'+escape(layer.id)+'">'+planetLabel(layer.id)+'<span class="pred-evidence">Houses: '+housesText(layer.houses)+(layer.selected?'':' · excluded')+'</span><small>'+data.fields.map(field=>field+': '+housesText(layer.levels[field])).join(' · ')+'</small></td>').join('')+'<td>'+housesText(chain.houses)+'</td></tr>').join('')+'</tbody></table>';
  }
  function forCusp(row,cusp,data=cache){
    if(!cusp)return row;
    const proofs=row.proofs.filter(proof=>proof.cusp===cusp);
    const best=[...proofs].sort((a,b)=>Number(b.complete)-Number(a.complete)||(b.matchedHouses.length/Math.max(b.requiredHouses.length,1))-(a.matchedHouses.length/Math.max(a.requiredHouses.length,1))||b.matchedHouses.length-a.matchedHouses.length)[0]||null;
    const status=!data.ready?'incomplete':!row.automaticEligible?'review':proofs.some(proof=>proof.complete)?'matched':best?.matchedHouses.length?'partial':'unmatched';
    return {...row,mainHouses:[cusp],proofs,proof:best,status};
  }
  function filtered(data=cache){
    if(!data)return [];const query=($('pred-search')?.value||'').trim().toLocaleLowerCase(),main=Number($('pred-main-house')?.value)||0,filter=$('pred-match-filter')?.value||'all';
    return data.results.filter(row=>!main||row.mainHouses.includes(main)).map(row=>forCusp(row,main,data)).filter(row=>(row.status==='matched'&&row.automaticEligible&&row.proof?.complete)&&(!query||[row.id,row.event?.en,row.event?.mr,...Object.values(row.sources).flatMap(source=>[source.main,source.supporting])].join(' ').toLocaleLowerCase().includes(query)));
  }
  function groupText(row){return row.supportingGroups.length?row.supportingGroups.map(housesText).join(' OR '):String(sourceFor(row).supporting??'—');}
  function eventRows(rows,print=false){return rows.map((row,i)=>'<tr data-pred-event="'+row.id+'" data-match-status="'+row.status+'"><td>'+(i+1+(print?0:pageIndex*PAGE_SIZE))+'</td><td>'+escape(label(row))+'</td></tr>').join('');}
  const EVENT_HEAD='<colgroup><col style="width:6%"><col style="width:94%"></colgroup><thead><tr><th>#</th><th>Prediction</th></tr></thead>';
  function showRows(){
    if(!cache)return;const rows=filtered(),pages=Math.max(1,Math.ceil(rows.length/PAGE_SIZE));pageIndex=Math.min(pageIndex,pages-1);
    const offset=pageIndex*PAGE_SIZE,mount=$('pred-event-rows');if(!mount)return;
    mount.innerHTML=rows.length?eventRows(rows.slice(offset,offset+PAGE_SIZE)):'<tr><td colspan="2">No event house groups match this kundali and the selected cusp.</td></tr>';
    $('pred-page-label').textContent=rows.length?'Rows '+(offset+1)+'–'+Math.min(offset+PAGE_SIZE,rows.length)+' of '+rows.length+' · Page '+(pageIndex+1)+' / '+pages:'0 events';
    $('pred-page-prev').disabled=pageIndex===0;$('pred-page-next').disabled=pageIndex>=pages-1;
    $('pred-print').disabled=!cache.ready||!Number($('pred-main-house').value);$('prediction-chains-preview').disabled=!cache.ready;
    $('pred-print-count').textContent=Number($('pred-main-house').value)?'Preview includes '+rows.length+' events for cusp '+$('pred-main-house').value+'.':'Choose a main cusp for the prediction report.';
    if(cache.ready){const main=Number($('pred-main-house').value),subset=cache.results.filter(row=>!main||row.mainHouses.includes(main)).map(row=>forCusp(row,main)),counts=Object.fromEntries(Object.keys(STATUS).map(status=>[status,subset.filter(row=>row.status===status).length]));$('pred-status').textContent=(main?'Cusp '+main:'All cusps')+' · '+counts.matched+' matched · '+counts.partial+' partial · '+counts.unmatched+' unmatched · '+counts.review+' review · '+cache.options.method+' · '+cache.options.layers.join(' + ');}
    window.KPPersonalPredictions?.refresh();
    window.KPPreferences?.decorate($('pred-chain-mount'));window.KPPreferences?.decorate($('pred-event-mount'));
    showDetail();
  }
  function showDetail(){
    const original=cache?.results.find(row=>row.id===selectedEvent),row=original?forCusp(original,Number($('pred-main-house')?.value)||0):null,mount=$('pred-event-detail');if(!mount)return;
    mount.hidden=!row;if(!row)return;
    const proof=row.proof,language=uiOptions().language;
    mount.innerHTML='<h4>#'+row.id+' · '+escape(label(row,language))+'</h4><p>'+escape(STATUS[row.status])+'. Main cusp: '+housesText(row.mainHouses)+'. Workbook group: '+escape(groupText(row))+'.</p>'+(proof?'<p>Selected significator union: '+housesText(proof.signifiedHouses)+'. Matched houses: '+housesText(proof.matchedHouses)+'. Missing houses: '+housesText(proof.missingHouses)+'.</p><table><thead><tr><th>Required house</th><th>Contributing lord and significator level</th></tr></thead><tbody>'+proof.contributions.map(contribution=>'<tr><td>'+contribution.house+'</td><td>'+(contribution.sources.length?contribution.sources.map(source=>escape(source.role)+' '+planetLabel(source.planet)+' · '+source.level).join('; '):'Missing from the selected layers')+'</td></tr>').join('')+'</tbody></table>':'')+'<button type="button" id="pred-detail-close">Close details</button>';
    $('pred-detail-close').addEventListener('click',()=>{selectedEvent=null;showDetail();});
    window.KPPreferences?.decorate(mount);
  }
  function metadataHTML(){
    const metadata=catalogue.metadata,differences=catalogue.issues.filter(issue=>/-house-language-difference$/.test(issue.type)),missing=catalogue.issues.filter(issue=>issue.type==='missing-translation');
    return '<p>'+metadata.eventCount+' workbook entries · '+metadata.automaticEligibleCount+' numeric house groups · '+metadata.conditionalCount+' entries need additional rule review. '+differences.length+' house-group language differences and '+missing.length+' missing translation are preserved for review. Repeated event labels remain separate entries with their original serial numbers.</p><p>Source: '+escape(metadata.sourceFilename)+'. English and Marathi entries are joined by serial number, preserving the worksheet name, row and original wording.</p><details><summary>Workbook differences</summary><div class="pred-table-wrap"><table><thead><tr><th>Event</th><th>Issue</th><th>English source</th><th>Marathi source</th></tr></thead><tbody>'+[...differences,...missing].map(issue=>'<tr><td>'+issue.id+'</td><td>'+escape(issueText(issue.type))+'</td><td>'+escape(issue.en??'—')+'</td><td>'+escape(issue.mr??'—')+'</td></tr>').join('')+'</tbody></table></div></details>';
  }
  function refresh(force=false){
    if(!initialized)return analyze(window.currentKPModel||{},normalizeOptions());
    [['pred-method',['fourfold','sixfold'],'fourfold'],['pred-chain-mode',['csl-chain','cusp-lords'],'csl-chain'],['pred-match-filter',['all',...Object.keys(STATUS)],'matched'],['pred-main-house',Array.from({length:13},(_,index)=>String(index)),'1']].forEach(([id,allowed,fallback])=>{if(!allowed.includes($(id).value))$(id).value=fallback;});
    if(![...$('pred-layers').querySelectorAll('input')].some(input=>input.checked))$('pred-layer-CSL').checked=true;
    const options=uiOptions(),model=window.currentKPModel;
    const next=JSON.stringify({options,ready:model?.ready,reason:model?.reason,planets:model?.planets?.map(p=>[p.id,p.longitude,p.stl,p.sl]),houses:model?.houses?.map(h=>[h.id,h.sl,h.stl]),fourfold:model?.fourfold?.planets,sixfold:model?.sixfold?.planets,preferences:window.KPPreferences?.get(),motion:(window.KPDisplay?.ids||[]).map((_,index)=>[$('p6_motion_'+index)?.value,$('p6_final_'+index)?.value])});
    if(force||signature!==next){signature=next;cache=analyze(model,options);$('pred-chain-mount').innerHTML=chainTable(cache);const counts=cache.counts;
      $('pred-status').dataset.ready=String(cache.ready);$('pred-status').textContent=cache.ready?counts.matched+' matched · '+counts.partial+' partial · '+counts.unmatched+' unmatched · '+counts.review+' additional rule review. '+(options.method==='sixfold'?'Six-fold A–F':'Four-fold A–D')+' · '+options.layers.join(' + ')+'.':cache.reason;
      showRows();
    }
    return cache;
  }
  function schedule(){clearTimeout(timer);timer=setTimeout(()=>refresh(),100);}
  function snapshot(){
    const data=refresh(),main=Number($('pred-main-house')?.value);
    if(!data.ready)return '<div class="pred-report"><p>'+escape(data.reason)+'</p></div>';
    if(!main)return '<div class="pred-report"><p>Select one main cusp to preview its results.</p></div>';
    const rows=filtered(data);
    return '<div class="pred-report pred-plain-report" data-main-cusp="'+main+'" data-pred-print-count="'+rows.length+'"><h2>Kundali Analysis</h2><p data-no-localize>'+escape($('name')?.value||'')+' · '+escape($('dob')?.value||'')+' · '+escape($('birthTime')?.value||'')+'</p><h3>Cusp '+main+' · Kundali results</h3><ol class="pred-plain-results">'+rows.map(row=>'<li data-pred-event="'+row.id+'" data-match-status="matched">'+escape(label(row))+'</li>').join('')+'</ol>'+(rows.length?'':'<p>No matched results for this cusp.</p>')+'</div>';

  }
  function chainSnapshot(){
    const data=refresh(),main=Number($('pred-main-house')?.value)||0,selected={...data,chains:data.chains.filter(chain=>!main||chain.cusp===main)};
    return '<div class="pred-report pred-chain-report" data-main-cusp="'+main+'"><h3>'+(main?'Cusp '+main+' lord chain':'All twelve cusp lord chains')+'</h3><p>'+escape(data.options.method)+' · '+escape(data.options.layers.join(' + '))+'</p>'+chainTable(selected,true)+'</div>';
  }
  function csvCell(value){const text=String(value??'');const safe=/^[\s\u0000-\u001f]*[=+@-]/.test(text)?"'"+text:text;return '"'+safe.replace(/"/g,'""')+'"';}
  function csv(){
    const data=refresh(),rows=filtered(data),heading=['Serial','Event','Main cusp','Workbook support / conditions','CSL','STL','SBL','Method','Selected layers','Signified houses','Matched houses','Missing houses','Analysis','Source sheet','Source row','Original main','Original support','Review notes'];
    const records=rows.map(row=>{const proof=row.proof,source=sourceFor(row);return [row.id,label(row),housesText(row.mainHouses),groupText(row),proof?.chain.CSL||'',proof?.chain.STL||'',proof?.chain.SBL||'',data.options.method,data.options.layers.join(', '),housesText(proof?.signifiedHouses),housesText(proof?.matchedHouses),housesText(proof?.missingHouses),STATUS[row.status],source.sheet,source.row,source.main,source.supporting,row.issues.map(issueText).join('; ')];});
    return '\uFEFF'+[heading,...records].map(record=>record.map(csvCell).join(',')).join('\r\n');
  }
  function exportCSV(){const blob=new Blob([csv()],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download='KP_Prediction_Sheet.csv';document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  function initialize(){
    const section=$('prediction');if(!section)return;const mount=$('prediction-mount')||section;
    mount.innerHTML='<div class="pred-card"><h2>Prediction · Kundali house-group analysis</h2><p class="pred-intro">Choose a main cusp, filter its event results and preview the selected cusp. Cusp chains have a separate preview. Source conditions remain available for review.</p><div class="pred-grid"><div><label for="pred-method">Significator method</label><select id="pred-method"><option value="fourfold">Four-fold · A–D</option><option value="sixfold">Six-fold · A–F</option></select></div><div><label for="pred-chain-mode">Lord interpretation</label><select id="pred-chain-mode"><option value="csl-chain">CSL → its star lord → its sub lord</option><option value="cusp-lords">Cusp sub lord → cusp star lord → cusp sub lord</option></select></div><div><label for="pred-main-house">Main cusp filter</label><select id="pred-main-house"><option value="0">All cusps · browse</option>'+Array.from({length:12},(_,index)=>'<option value="'+(index+1)+'"'+(index===0?' selected':'')+'>Cusp '+(index+1)+'</option>').join('')+'</select></div><div><label for="pred-search">Search events, serial or source text</label><input id="pred-search" type="search" placeholder="Health, marriage, career…"></div><input id="pred-match-filter" type="hidden" value="matched"></div><div class="pred-choice-line"><fieldset id="pred-layers" class="pred-layers"><legend>Include significator layers</legend>'+ROLES.map(role=>'<label><input type="checkbox" id="pred-layer-'+role+'" value="'+role+'" checked>'+role+'</label>').join('')+'</fieldset><label><input type="checkbox" id="pred-require-main">Also require main house in significators</label></div><p id="pred-status" class="pred-summary" role="status" aria-live="polite"></p><details><summary>Cusp chains · CSL–STL–SBL</summary><button id="prediction-chains-preview" type="button">Cusp chains preview</button><div id="pred-chain-mount" class="pred-table-wrap"></div></details><h3>Prediction sheet</h3><div class="pred-actions"><button type="button" id="pred-page-prev">Previous</button><span id="pred-page-label"></span><button type="button" id="pred-page-next">Next</button><button type="button" id="pred-print">Preview selected cusp</button><span id="pred-print-count" class="pred-catalogue-info"></span></div><div id="pred-event-mount" class="pred-table-wrap"><table aria-label="Prediction house-group analysis">'+EVENT_HEAD+'<tbody id="pred-event-rows"></tbody></table></div><div id="pred-event-detail" class="pred-detail" hidden></div></div>';
    $('prediction-chains-preview').addEventListener('click',()=>window.KPReportPreview?.open('prediction-chains'));
    initialized=true;const preferences=window.KPPreferences?.get();if(preferences?.homeView==='sixfold')$('pred-method').value='sixfold';
    ['pred-method','pred-chain-mode','pred-require-main'].forEach(id=>$(id).addEventListener('change',()=>{pageIndex=0;refresh(true);}));
    $('pred-layers').addEventListener('change',event=>{if(![...$('pred-layers').querySelectorAll('input')].some(input=>input.checked))event.target.checked=true;pageIndex=0;refresh(true);});
    ['pred-main-house','pred-match-filter'].forEach(id=>$(id).addEventListener('change',()=>{pageIndex=0;showRows();}));
    $('pred-search').addEventListener('input',()=>{pageIndex=0;showRows();});
    $('pred-page-prev').addEventListener('click',()=>{pageIndex--;showRows();});$('pred-page-next').addEventListener('click',()=>{pageIndex++;showRows();});
    $('pred-event-mount').addEventListener('click',event=>{const button=event.target.closest('[data-pred-detail]');if(button){selectedEvent=Number(button.dataset.predDetail);showDetail();}});
    window.addEventListener('kp-preferences-changed',()=>{schedule();});['chart-saved','chart-manual-change'].forEach(name=>window.addEventListener(name,schedule));document.addEventListener('input',event=>{if(!event.target.closest('#prediction'))schedule();});document.addEventListener('change',event=>{if(!event.target.closest('#prediction'))schedule();});
    const source=$('kp-basic-planet');if(source)new MutationObserver(schedule).observe(source,{childList:true,subtree:true,characterData:true});
    const card=mount.querySelector('.pred-card'),grid=card.querySelector('.pred-grid'),compact=document.createElement('div');compact.className='pred-consultation-controls';
    for(const id of ['pred-main-house','pred-search'])compact.append($(id).closest('.pred-grid>div'));
    card.prepend(compact);const drawer=document.createElement('details');drawer.id='pred-analysis-options';drawer.innerHTML='<summary>Analysis options</summary>';compact.append(drawer);drawer.append(grid,card.querySelector('.pred-choice-line'),$('pred-status'));
    const chainDetails=$('pred-chain-mount').closest('details');drawer.append(chainDetails);$('prediction-chains-preview').hidden=true;$('pred-print').hidden=true;$('pred-print-count').hidden=true;
    $('pred-search').labels[0].textContent='Search predictions';
    refresh(true);
  }
  window.KPPrediction=Object.freeze({analyze,refresh,getData:()=>refresh(),snapshot,chainSnapshot,getCatalogue:()=>catalogue,csv});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

