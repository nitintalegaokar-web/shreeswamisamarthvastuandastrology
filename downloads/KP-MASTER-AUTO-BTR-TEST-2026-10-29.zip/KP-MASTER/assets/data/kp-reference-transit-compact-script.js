
(() => {
  'use strict';
  function initialize(){
    const section=document.getElementById('transit-chart');
    const mounts=['tc-rashi-chart','tc-bhav-chart'].map(id=>document.getElementById(id)).filter(Boolean);
    if(!section||!mounts.length||section.dataset.referenceCompact)return;
    section.dataset.referenceCompact='true';
    const desktop=window.matchMedia('(min-width:901px)');let scheduled=false;
    function resize(){
      scheduled=false;
      const mount=mounts.find(candidate=>candidate.querySelector('svg')&&candidate.clientWidth>0),svg=mount?.querySelector('svg');
      if(!desktop.matches||!svg){section.classList.remove('tc-reference-compact-ready');return;}
      const width=mount.clientWidth,box=svg.viewBox.baseVal,nativeHeight=width*box.height/box.width;
      if(!Number.isFinite(nativeHeight)||nativeHeight<=0)return;
      const height=Math.max(240,Math.min(280,width*.6)),scale=Math.min(1,(height-3)/nativeHeight);
      // The section is not cloned into the report; the original SVG and its mount stay unchanged.
      section.style.setProperty('--tc-reference-diagram-height',height+'px');
      section.style.setProperty('--tc-reference-diagram-scale',String(scale));
      section.style.setProperty('--tc-reference-text-scale',String(1/scale));
      section.classList.add('tc-reference-compact-ready');
    }
    function schedule(){if(!scheduled){scheduled=true;requestAnimationFrame(resize);}}
    const observer=new ResizeObserver(schedule);
    for(const mount of mounts){observer.observe(mount);new MutationObserver(schedule).observe(mount,{childList:true});}
    window.addEventListener('resize',schedule);desktop.addEventListener('change',schedule);schedule();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

