
/* ================= v27: TAB 8 / TAB 9 / PRINT REPAIR ================= */
(function(){
  const P=["रवी","चंद्र","मंगळ","बुध","गुरु","शुक्र","शनि","राहू","केतू"];
  const PL={"रवी":"रवी","चंद्र":"चंद्र","मंगळ":"मंगळ","बुध":"बुध","गुरु":"गुरु","शुक्र":"शुक्र","शनि":"शनि","राहू":"राहू","राहु":"राहू","केतू":"केतू","केतु":"केतू"};
  const SL={"मेष":"मंगळ","वृषभ":"शुक्र","मिथुन":"बुध","कर्क":"चंद्र","सिंह":"रवी","कन्या":"बुध","तुळ":"शुक्र","वृश्चिक":"मंगळ","धनु":"गुरु","मकर":"शनि","कुंभ":"शनि","मीन":"गुरु"};
  const NL=["केतू","शुक्र","रवी","चंद्र","मंगळ","राहू","गुरु","शनि","बुध"];
  const Y={"केतू":7,"शुक्र":20,"रवी":6,"चंद्र":10,"मंगळ":7,"राहू":18,"गुरु":16,"शनि":19,"बुध":17};
  const canon=x=>PL[String(x||'').trim()]||String(x||'').trim();
  const norm=x=>((Number(x)||0)%1296000+1296000)%1296000;
  const signIdx=lon=>Math.min(11,Math.floor(norm(lon)/108000));
  const star=lon=>NL[Math.floor(norm(lon)/48000)%9];
  const sub=lon=>{const x=norm(lon), n=Math.floor(x/48000), within=x-n*48000, s=NL[n%9], start=NL.indexOf(s);let a=0;for(let j=0;j<9;j++){let l=NL[(start+j)%9], span=48000*Y[l]/120;if(within<a+span||j===8)return l;a+=span;}return s;};
  function houseAt(cusps,lon){
    const x=norm(lon); for(let i=0;i<12;i++){const a=norm(cusps[i]),b=norm(cusps[(i+1)%12]);const span=norm(b-a),rel=norm(x-a);if(rel<span || (span===0&&rel===0)) return i+1;} return 12;
  }
  function data(){
    const cr=Array.isArray(window.cuspResults)?window.cuspResults:[];
    const cusps=cr.map(x=>x&&x.nir!=null&&x.nir!==""?Number(x.nir):NaN);
    if(cusps.length!==12||cusps.some(x=>!Number.isFinite(x))) return null;
    const lp=window.lastPlanetPositions||{}; const pd={};
    P.forEach(p=>{let v=Number(lp[p]);if(Number.isFinite(v)){v=norm(v);let si=signIdx(v);pd[p]={lon:v,house:houseAt(cusps,v),signLord:SL[(window.rashi||["मेष","वृषभ","मिथुन","कर्क","सिंह","कन्या","तुळ","वृश्चिक","धनु","मकर","कुंभ","मीन"])[si]],starLord:star(v),sublord:sub(v)};}});
    if(Object.keys(pd).length===0) return null;
    const H={}; const rashi=window.rashi||["मेष","वृषभ","मिथुन","कर्क","सिंह","कन्या","तुळ","वृश्चिक","धनु","मकर","कुंभ","मीन"];
    for(let h=1;h<=12;h++){const c=norm(cusps[h-1]),r=rashi[signIdx(c)];H[h]={cusp:c,sign:r,owner:SL[r],occupants:[]};}
    Object.entries(pd).forEach(([p,d])=>{if(H[d.house])H[d.house].occupants.push(p);});
    const owned={};P.forEach(p=>owned[p]=[]);for(let h=1;h<=12;h++){let o=canon(H[h].owner);if(owned[o])owned[o].push(h);}
    const sig={};
    Object.entries(pd).forEach(([p,d])=>{const s=new Set(); const sl=canon(d.starLord); if(sl){for(let h=1;h<=12;h++)if(H[h].occupants.includes(sl))s.add(h);(owned[sl]||[]).forEach(h=>s.add(h));} if(d.house)s.add(d.house);(owned[p]||[]).forEach(h=>s.add(h)); if(p==='राहू'||p==='केतू'){const so=canon(d.signLord);if(so){for(let h=1;h<=12;h++)if(H[h].occupants.includes(so))s.add(h);(owned[so]||[]).forEach(h=>s.add(h));}} sig[p]=s;});
    const byH={};for(let h=1;h<=12;h++)byH[h]=Object.keys(sig).filter(p=>sig[p].has(h));
    const subH={};for(let h=1;h<=12;h++){let s=canon(H[h].sublord);subH[h]=s&&sig[s]?[...sig[s]]:[];}
    const subP={};Object.entries(pd).forEach(([p,d])=>{let s=canon(d.sublord);subP[p]=s&&sig[s]?[...sig[s]]:[];});
    return {cusps,pd,H,sig,byH,subH,subP};
  }
  const fmt=set=>[...(set||[])].sort((a,b)=>a-b).join(', ');

  window.updateKaryeshTables=function(){
    const d=data();
    const ids=[];
    for(let h=1;h<=12;h++)ids.push([`karyesh_bhava_graha_${h}`,d?fmt(d.byH[h]):'']);
    const gp=["रवी","चंद्र","मंगळ","राहू","गुरु","शनि","बुध","केतू","शुक्र"];
    gp.forEach((p,i)=>ids.push([`karyesh_graha_bhava_${i+1}`,d?fmt(d.sig[p]):'']));
    for(let h=1;h<=12;h++)ids.push([`karyesh_sublord_bhava_${h}`,d?fmt(d.subH[h]):'']);
    gp.forEach((p,i)=>ids.push([`karyesh_sublord_graha_${i+1}`,d?fmt(d.subP[p]):'']));
    ids.forEach(([id,v])=>{const e=document.getElementById(id);if(e)e.value=v||'—';});
    const box=document.querySelector('#karyesh .karyesh-page');
    if(box){let n=box.querySelector('.karyesh-note');if(!n){n=document.createElement('div');n.className='karyesh-note';box.insertBefore(n,box.querySelector('.karyesh-grid'));}n.innerHTML=d?'✓ <b>KP कार्येश गणना पूर्ण.</b> Tab 5 निरयन भाव + Tab 6 निरयन ग्रहस्थिती + नक्षत्रस्वामी/उपनक्षत्रस्वामी यांच्या आधारे भावेश, ग्रहकार्येश आणि उपनक्षत्रस्वामी कार्येश भरले आहेत.':'⚠ <b>गणना उपलब्ध नाही.</b> प्रथम Tab 5 आणि Tab 6 मधील निरयन गणना पूर्ण करा.';}
  };

  window.renderChart=function(force){
    if(window.kundaliManual&&!force)return;
    const chart=document.getElementById('kundali');if(!chart)return;
    const signs=["मेष","वृषभ","मिथुन","कर्क","सिंह","कन्या","तुळ","वृश्चिक","धनु","मकर","कुंभ","मीन"];
    const pos={11:[1,1],0:[1,2],1:[1,3],2:[1,4],3:[2,4],4:[3,4],5:[4,4],6:[4,3],7:[4,2],8:[4,1],9:[3,1],10:[2,1]};
    const boxes=Array.from({length:12},()=>[]);
    const add=(lon,kind,label)=>{if(!Number.isFinite(Number(lon)))return;let a=norm(lon),i=signIdx(a);boxes[i].push({d:a%108000,k:kind,l:label});};
    (window.cuspResults||[]).forEach(x=>add(Number(x.nir),'cusp','भाव '+x.i));
    Object.entries(window.lastPlanetPositions||{}).forEach(([p,v])=>add(Number(v),'planet',p));
    boxes.forEach(b=>b.sort((a,b)=>a.d-b.d));
    let out='';
    for(let i=0;i<12;i++){let [r,c]=pos[i];let ent=boxes[i].map(x=>`<div class="s9-entry ${x.k}">${x.l} — ${typeof fmtLong==='function'?fmtLong(x.d):x.d}</div>`).join('');out+=`<div class="s9-cell" style="grid-row:${r};grid-column:${c}">${ent}</div>`;}
    const v=id=>document.getElementById(id)?.value||'';const lag=(window.cuspResults||[]).find(x=>x.i===1);let lt='';if(lag&&Number.isFinite(Number(lag.nir))){let a=norm(lag.nir);lt=`<div style="margin-top:7px;text-align:center;font-weight:800">लग्न: ${signs[signIdx(a)]} ${typeof fmtLong==='function'?fmtLong(a%108000):''}</div>`;}
    out+=`<div class="s9-center"><div style="width:100%"><div class="s9-center-title">कृष्णमूर्ती पद्धतीची लग्न व भावचलित कुंडली</div><div class="s9-data"><b>नाव:</b> ${v('name')}<br><b>जन्मतारीख:</b> ${v('dob')}<br><b>जन्मवेळ:</b> ${v('birthTime')}<br><b>अक्षांश:</b> ${v('lat')}<br><b>रेखांश:</b> ${v('lon')}<br><b>जन्मवेळी असलेली भोग्य महादशा:</b> ${v('mdBirthDasha')} ${v('mdBhogyaDuration')?'— '+v('mdBhogyaDuration'):''}</div>${lt}</div></div>`;
    const labels=['मीन','मेष','वृषभ','मिथुन','कर्क','सिंह','कन्या','तुळ','वृश्चिक','धनु','मकर','कुंभ'];
    out+=`<span class="s9-label s9-top0">मीन</span><span class="s9-label s9-top1">मेष</span><span class="s9-label s9-top2">वृषभ</span><span class="s9-label s9-top3">मिथुन</span><span class="s9-label s9-right0">कर्क</span><span class="s9-label s9-right1">सिंह</span><span class="s9-label s9-right2">कन्या</span><span class="s9-label" style="right:-38px;bottom:-24px;width:35px;text-align:left">तुळ</span><span class="s9-label" style="left:50%;bottom:-24px;width:25%;text-align:center">वृश्चिक</span><span class="s9-label" style="left:25%;bottom:-24px;width:25%;text-align:center">धनु</span><span class="s9-label s9-left2">मकर</span><span class="s9-label s9-left1">कुंभ</span><span class="s9-label s9-left3">मीन</span>`;
    chart.innerHTML=out;
    const val=document.getElementById('chartAscValidation');if(val){const lag=(window.cuspResults||[]).find(x=>x.i===1);val.innerHTML=lag&&Number.isFinite(Number(lag.nir))?`<b>लग्न:</b> ${signs[signIdx(lag.nir)]} ${typeof fmtLong==='function'?fmtLong(norm(lag.nir)%108000):''}`:'रॅफेल टेबलची निरयन भावस्थिती उपलब्ध झाल्यावर कुंडली automatic भरेल.';}
  };

  window.renderReport=function(){
    const pages=[['1. मूलभूत माहिती','basic'],['2. स्थळ रेखांश गणना','ayan'],['3. स्थानिक जन्मवेळ (L.M.T.) गणना','lmt'],['4. सांपत्तिक काळ गणना','stcalc'],['5. रॅफेल टेबल ऑफ हाऊसेस','raphael5'],['6. ग्रहस्थिती गणना','planet'],['7. महादशा (MD) गणना','mdcalc'],['8. कार्येश','karyesh'],['9. South Indian Kundali','south9']];
    const c=document.getElementById('printReport');if(!c)return;
    c.innerHTML='';
    pages.forEach(([title,id])=>{const src=document.getElementById(id);if(!src)return;const page=document.createElement('div');page.className='report-page';const t=document.createElement('div');t.className='report-page-title';t.textContent=title;page.appendChild(t);const clone=document.createElement('div');clone.className='report-cover';clone.innerHTML=snapshotSection(id);page.appendChild(clone);
      const rf=document.createElement('div');
      rf.className='report-developer-footer';
      const rs={name:document.getElementById('astroName')?.value||'Astro.Nitin Talegaonkar',mobile:document.getElementById('astroMobile')?.value||'8412098690'};
      rf.textContent='Software developer Name: '+(rs.name||'Astro.Nitin Talegaonkar')+' | Mob: '+(rs.mobile||'8412098690');
      page.appendChild(rf);
      c.appendChild(page);
    });
  };
  window.printReport=function(){
    if(typeof calculateAll==='function')calculateAll();
    window.updateKaryeshTables();window.renderChart(true);window.renderReport();
    document.querySelectorAll('main>.tab').forEach(x=>x.classList.remove('printTarget'));
    const r=document.getElementById('report');if(r)r.classList.add('printTarget');
    setTimeout(()=>window.print(),100);
    setTimeout(()=>{if(r)r.classList.remove('printTarget');},1500);
  };

  function refresh(){
    try{window.updateKaryeshTables();window.renderChart(true);}catch(e){console.error(e);}
  }
  document.addEventListener('DOMContentLoaded',()=>{
    setTimeout(refresh,100);setTimeout(refresh,500);setTimeout(refresh,1000);
    document.querySelectorAll('nav button[data-tab]').forEach(b=>b.addEventListener('click',()=>{if(b.dataset.tab==='karyesh'||b.dataset.tab==='south9'){setTimeout(refresh,50);setTimeout(refresh,300);}if(b.dataset.tab==='report'){setTimeout(()=>{refresh();window.renderReport();},100);}}));
  });
})();

