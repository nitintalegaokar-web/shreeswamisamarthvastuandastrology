
(function () {
  'use strict';
  const MAX_BYTES = 8 * 1024 * 1024;
  const STORAGE_KEY = 'kpReportCoverPhoto';
  let currentPhoto = '';
  let selectionVersion = 0;
  const notify = (message, type) => {
    if (typeof window.showToast === 'function') window.showToast(message, type);
  };

  function imageBytes(source) {
    if (typeof source !== 'string' || source.length > Math.ceil(MAX_BYTES / 3) * 4 + 64) return null;
    const match = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(source);
    if (!match || match[2].length % 4 !== 0) return null;
    let bytes;
    try { bytes = atob(match[2]); } catch (_) { return null; }
    if (!bytes.length || bytes.length > MAX_BYTES) return null;
    const at = index => bytes.charCodeAt(index);
    if (match[1] === 'png') {
      if (bytes.length < 33 || bytes.slice(1, 4) !== 'PNG' || at(0) !== 137 || at(4) !== 13 || at(5) !== 10 || at(6) !== 26 || at(7) !== 10 || bytes.slice(12, 16) !== 'IHDR' || bytes.slice(-8, -4) !== 'IEND') return null;
    } else if (match[1] === 'jpeg') {
      if (bytes.length < 4 || at(0) !== 255 || at(1) !== 216 || at(bytes.length - 2) !== 255 || at(bytes.length - 1) !== 217) return null;
    } else {
      if (bytes.length < 20 || bytes.slice(0, 4) !== 'RIFF' || bytes.slice(8, 12) !== 'WEBP') return null;
      const declaredLength = at(4) + at(5) * 256 + at(6) * 65536 + at(7) * 16777216;
      if (declaredLength + 8 !== bytes.length) return null;
    }
    return bytes;
  }

  function refreshStatus(saved = true) {
    const status = document.getElementById('report-cover-photo-status');
    if (status) {
      status.dataset.ready = String(Boolean(currentPhoto));
      status.textContent = currentPhoto
        ? (saved ? 'Cover photo ready for the report.' : 'Cover photo ready for this session. Export a chart backup to keep a copy. Browser storage is full or unavailable.')
        : 'Choose the supplied Mahaganpati photo for the report front page.';
    }
    const button = document.getElementById('choose-report-cover-photo');
    if (button) button.textContent = currentPhoto ? 'Replace cover photo' : 'Choose cover photo';
  }

  function apply(source, options = {}) {
    if (source !== '' && !imageBytes(source)) return false;
    selectionVersion++;
    currentPhoto = source;
    window.KP_REPORT_COVER_IMAGE = source;
    let saved = true;
    if (options.persist !== false) {
      try {
        localStorage.setItem(STORAGE_KEY, source);
      } catch (_) { saved = false; }
    }
    refreshStatus(saved);
    if (typeof window.renderReport === 'function') window.renderReport();
    window.dispatchEvent(new CustomEvent('report-cover-photo-change', {detail: {ready: Boolean(source)}}));
    return true;
  }

  function decodeImage(source) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => image.naturalWidth > 0 && image.naturalHeight > 0 ? resolve() : reject(new Error('This image cannot be read.'));
      image.onerror = () => reject(new Error('This image cannot be read. Choose a valid PNG, JPG or WebP photo.'));
      image.src = source;
    });
  }

  async function selectPhoto(event) {
    const input = event.target;
    const file = input.files?.[0];
    const version = ++selectionVersion;
    if (!file) return;
    try {
      if (file.size > MAX_BYTES) throw new Error('Choose a cover photo smaller than 8 MB.');
      if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) throw new Error('Choose a PNG, JPG or WebP cover photo.');
      const source = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error('The cover photo could not be read. Try selecting it again.'));
        reader.readAsDataURL(file);
      });
      if (!imageBytes(source)) throw new Error('This file is not a valid PNG, JPG or WebP photo.');
      await decodeImage(source);
      if (version !== selectionVersion) return;
      apply(source);
      notify('Cover photo added to the report.', 'success');
    } catch (error) {
      if (version === selectionVersion) notify(error.message, 'error');
    } finally { input.value = ''; }
  }

  window.KPReportPhoto = Object.freeze({
    isValid: source => source === '' || Boolean(imageBytes(source)),
    get: () => currentPhoto,
    apply
  });

  async function initialize() {
    document.getElementById('choose-report-cover-photo')?.addEventListener('click', () => document.getElementById('report-cover-photo-input').click());
    document.getElementById('report-cover-photo-input')?.addEventListener('change', selectPhoto);
    let stored = null;
    try { stored = localStorage.getItem(STORAGE_KEY); } catch (_) { /* Photo selection also works without storage. */ }
    if (stored === '') { apply('', {persist: false}); return; }
    const embedded = window.KP_REPORT_COVER_IMAGE;
    const candidates = [stored, embedded].filter(source => source && imageBytes(source));
    for (const source of candidates) {
      try {
        await decodeImage(source);
        if (selectionVersion === 0) apply(source, {persist: false});
        return;
      } catch (_) { /* An unreadable saved image must not block the software. */ }
    }
    refreshStatus();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize);
  else initialize();
})();

