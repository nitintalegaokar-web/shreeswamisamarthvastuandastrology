
(function () {
  'use strict';
  const byId = id => document.getElementById(id);
  const IDS = ['Su', 'Mo', 'Ma', 'Me', 'Ju', 'Ve', 'Sa', 'Ra', 'Ke'];
  const QUALITY = Object.freeze({
    'very-good':{name:'Very good', label:'बहुत अच्छा', color:'#008000'},
    good:{name:'Good', label:'अच्छा', color:'#00a800'},
    bad:{name:'Bad', label:'बुरा', color:'#e57900'},
    'very-bad':{name:'Very bad', label:'बहुत बुरा', color:'#d92424'},
    conjunction:{name:'Conjunction', label:'कंजंक्शन', color:'#2455e8'}
  });
  const CATALOG = Object.freeze([
    {angle:0, name:'Conjunction', marathiName:'कंजंक्शन', code:'कंज.', quality:'conjunction'},
    {angle:22.5, name:'Semi-octile', marathiName:'सेमी-ऑक्टाइल', code:'से.ऑक्ट', quality:'bad'},
    {angle:30, name:'Semisextile', marathiName:'सेमी-सेक्सटाइल', code:'से.सेक', quality:'good'},
    {angle:36, name:'Semi-quintile', marathiName:'सेमी-क्वाइन्टाइल', code:'सेक्यूटी', quality:'very-good'},
    {angle:40, name:'Novile', marathiName:'नोवाइल', code:'नोवा', quality:'good'},
    {angle:45, name:'Semisquare', marathiName:'सेमी-स्क्वायर', code:'से.स्क', quality:'bad'},
    {angle:60, name:'Sextile', marathiName:'सेक्सटाइल', code:'सेक.', quality:'good'},
    {angle:67.5, name:'Sesquioctile', marathiName:'सेसक्वी-ऑक्टाइल', code:'सेस.ऑ.', quality:'bad'},
    {angle:72, name:'Quintile', marathiName:'क्वाइन्टाइल', code:'क्यूटी', quality:'very-good'},
    {angle:80, name:'Binovile', marathiName:'बिनोवाइल', code:'बिनोवा', quality:'good'},
    {angle:90, name:'Square', marathiName:'स्क्वायर', code:'स्क्वा', quality:'very-bad'},
    {angle:120, name:'Trine', marathiName:'ट्राइन', code:'ट्राइन', quality:'very-good'},
    {angle:135, name:'Sesquiquadrate', marathiName:'सेसक्यू-क्वाड्रेट', code:'सेसक्व', quality:'bad'},
    {angle:144, name:'Biquintile', marathiName:'बाई-क्वाइन्टाइल', code:'बाइक्यू', quality:'very-good'},
    {angle:150, name:'Quincunx', marathiName:'क्युनिन्स', code:'क्युनि', quality:'bad'},
    {angle:160, name:'Quadranovile', marathiName:'क्वाड्रानोवाइल', code:'क्वाड्रा', quality:'good'},
    {angle:180, name:'Opposition', marathiName:'अपोझिशन', code:'अपो.', quality:'very-bad'}
    ,{angle:18,name:'Semi-decile / Vigintile',marathiName:'सेमी-डेसाइल',code:'से.डे.',quality:'good'}
    ,{angle:24,name:'Quindecile',marathiName:'क्विनडेसाइल',code:'क्विनडे.',quality:'good'}
    ,{angle:108,name:'Tridecile',marathiName:'ट्रायडेसाइल',code:'ट्रायडे.',quality:'good'}
  ].sort((a,b)=>a.angle-b.angle).map(aspect => Object.freeze(aspect)));
  const ASPECTS_BY_ANGLE = Object.fromEntries(CATALOG.map(aspect => [aspect.angle, aspect]));
  const MAJOR = [0, 60, 90, 120, 180];
  const ANGLES = CATALOG.map(aspect => aspect.angle);
  const WEEKDAY_LORDS = ['Su', 'Mo', 'Ma', 'Me', 'Ju', 'Ve', 'Sa'];
  const HOUR_SEQUENCE = ['Sa', 'Ju', 'Ma', 'Su', 'Ve', 'Me', 'Mo'];
  const normalizeDegrees = longitude => ((longitude % 360) + 360) % 360;
  const angularSeparation = (a, b) => Math.abs(((normalizeDegrees(a) - normalizeDegrees(b) + 540) % 360) - 180);
  const plainObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);
  const numberInRange = (value, minimum, maximum) => typeof value === 'number' && Number.isFinite(value) && value >= minimum && value <= maximum;
  const element = (tag, text, className) => {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = String(text);
    if (className) node.className = className;
    return node;
  };

  // Public calculations accept absolute zodiac degrees by default. Pass
  // {unit:'arcseconds'} for KPDisplay models; aspect angles/orbs remain degrees.
  function calculate(planets, cusps, configuration) {
    const unit = configuration?.unit || 'degrees';
    if (unit !== 'degrees' && unit !== 'arcseconds') throw new Error('Use degrees or arcseconds for longitude units.');
    const divisor = unit === 'arcseconds' ? 3600 : 1;
    const aspects = configuration?.aspects || MAJOR.map(angle => ({angle, orb:3}));
    if (!Array.isArray(aspects)) throw new Error('Select a valid list of Western aspects.');
    const checked = aspects.map(aspect => {
      if (!plainObject(aspect) || !Object.hasOwn(ASPECTS_BY_ANGLE, aspect.angle) || !numberInRange(aspect.orb, 0, 15)) throw new Error('Select a listed aspect and an orb between 0° and 15°.');
      const quality = aspect.quality ?? ASPECTS_BY_ANGLE[aspect.angle].quality;
      if (!Object.hasOwn(QUALITY, quality)) throw new Error('Select a listed aspect color category.');
      return {angle:Number(aspect.angle), orb:aspect.orb, quality};
    });
    if (new Set(checked.map(aspect => aspect.angle)).size !== checked.length) throw new Error('Each aspect angle must appear once.');
    function positions(input, houses) {
      if (!Array.isArray(input)) throw new Error('Provide an array of longitude positions.');
      const entries = input.map((position, index) => {
        if (!plainObject(position) || typeof position.longitude !== 'number' || !Number.isFinite(position.longitude)) throw new Error('Each position needs a finite longitude.');
        const id = position.id ?? (houses ? index + 1 : null);
        if (id === null || (typeof id !== 'string' && typeof id !== 'number') || String(id).length > 40) throw new Error('Each position needs a valid identifier.');
        return {id, longitude:normalizeDegrees(position.longitude / divisor)};
      });
      if (new Set(entries.map(position => String(position.id))).size !== entries.length) throw new Error('Position identifiers must be unique.');
      return entries;
    }
    const sources = positions(planets, false), targets = positions(cusps, true);
    function matches(source, target) {
      const separation = angularSeparation(source.longitude, target.longitude);
      return checked.flatMap(aspect => {
        const orb = Math.abs(separation - aspect.angle);
        const metadata = ASPECTS_BY_ANGLE[aspect.angle];
        return orb <= aspect.orb + 1e-10 ? [{source:source.id, target:target.id, angle:aspect.angle, name:metadata.name, marathiName:metadata.marathiName, code:metadata.code, quality:aspect.quality, qualityName:QUALITY[aspect.quality].name, qualityLabel:QUALITY[aspect.quality].label, color:QUALITY[aspect.quality].color, separation, orb, allowedOrb:aspect.orb, sourceLongitude:source.longitude, targetLongitude:target.longitude}] : [];
      });
    }
    const planetToPlanet = [], planetToCusp = [];
    sources.forEach((source, index) => {
      sources.slice(index + 1).forEach(target => planetToPlanet.push(...matches(source, target)));
      targets.forEach(target => planetToCusp.push(...matches(source, target)));
    });
    return {planetToPlanet, planetToCusp, settings:{unit, aspects:checked}};
  }
  const STANDARD_ORBS=Object.freeze({"0": 6.0, "22.5": 3.0, "30": 2.0, "36": 2.0, "40": 3.0, "45": 2.0, "60": 3.0, "67.5": 3.0, "72": 2.0, "80": 3.0, "90": 5.0, "120": 5.0, "135": 2.0, "144": 3.0, "150": 2.0, "160": 3.0, "180": 3.0, "18": 2.0, "24": 2.0, "108": 2.0});
  function readAspectSettings(){return {unit:'arcseconds',aspects:CATALOG.map(a=>({...a,orb:STANDARD_ORBS[a.angle],color:QUALITY[a.quality].color,qualityName:QUALITY[a.quality].name,qualityLabel:QUALITY[a.quality].label}))};}
  function aspectTable(id, rows, cusp, message) {
    const body = byId(id)?.querySelector('tbody');
    if (!body) return;
    const nodes = rows.map(result => {
      const row = element('tr');
      row.dataset.source = result.source;
      row.dataset.target = result.target;
      row.dataset.angle = result.angle;
      row.dataset.separation = result.separation;
      row.dataset.orb = result.orb;
      row.dataset.quality = result.quality;
      const source = element('th', result.source); source.scope = 'row';
      const description = element('td', result.name, 'western-aspect-description');
      description.append(element('span', result.marathiName, 'western-marathi-name'), element('small', result.qualityName + ' · ' + result.qualityLabel, 'western-quality-label'));
      description.style.color = result.color;
      const code = element('td', result.code, 'western-aspect-code');
      code.style.color = result.color;
      row.append(source, element('td', cusp ? 'Cusp ' + result.target : result.target), description, code, element('td', result.angle + '°'), element('td', result.separation.toFixed(3) + '°'), element('td', result.orb.toFixed(3) + '°'));
      return row;
    });
    if (!nodes.length) { const row = element('tr'), cell = element('td', message || 'No aspects within the selected orbs.'); cell.colSpan = 7; row.append(cell); nodes.push(row); }
    body.replaceChildren(...nodes);
  }
  function renderAspects() {
    const status = byId('western-aspect-status');
    if (!status) return;
    const model = window.currentKPModel;
    let output = {planetToPlanet:[], planetToCusp:[]}, message = '', ready = false;
    try {
      const settings = readAspectSettings();
      if (!model?.ready) message = 'Complete all twelve cusps in Raphael houses and all planet positions to calculate Western aspects.';
      else if (!settings.aspects.length) message = 'Select at least one aspect above.';
      else { output = calculate(model.planets, model.houses, settings); ready = true; message = 'Western aspects · ' + settings.aspects.length + ' selected angles · Separations and orbs shown in degrees.'; }
    } catch (error) { message = error.message; }
    status.textContent = message;
    status.dataset.ready = String(ready);
    aspectTable('western-planet-aspects', output.planetToPlanet, false, ready ? '' : message);
    aspectTable('western-cusp-aspects', output.planetToCusp, true, ready ? '' : message);
    byId('western-planet-count').textContent = '(' + output.planetToPlanet.length + ')';
    byId('western-cusp-count').textContent = '(' + output.planetToCusp.length + ')';
    return output;
  }
  window.KPWesternAspects = Object.freeze({calculate, render:renderAspects, normalizeDegrees, angularSeparation, getCatalog:() => CATALOG.map(aspect => ({...aspect})), getSettings:readAspectSettings, getPalette:() => Object.fromEntries(Object.entries(QUALITY).map(([key, value]) => [key, {...value}]))});


  let aspectFrame=null;
  function dirty(){window.dispatchEvent(new CustomEvent('chart-manual-change'));}
  function scheduleAspects(){if(aspectFrame!==null)return;aspectFrame=requestAnimationFrame(()=>{aspectFrame=null;renderAspects();});}
  function initialize(){
    const section=byId('aspects');
    section?.addEventListener('input',event=>{event.stopPropagation();if(event.target.id==='western-orb'&&event.target.value.trim()&&numberInRange(Number(event.target.value),0,15))ANGLES.forEach(angle=>{byId('western-orb-'+angle).value=event.target.value;});renderAspects();dirty();});
    section?.addEventListener('change',event=>{event.stopPropagation();renderAspects();dirty();});
    section?.addEventListener('click',event=>{const button=event.target.closest('[data-western-select]');if(!button)return;ANGLES.forEach(angle=>{byId('western-angle-'+angle).checked=button.dataset.westernSelect==='all'||MAJOR.includes(angle);});renderAspects();dirty();});
    ['chart-saved','chart-manual-change'].forEach(name=>window.addEventListener(name,scheduleAspects));
    document.addEventListener('input',scheduleAspects);document.addEventListener('change',scheduleAspects);
    const source=byId('kp-basic-planet');if(source)new MutationObserver(scheduleAspects).observe(source,{childList:true,subtree:true,characterData:true});renderAspects();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

