
/* v17 FINAL: Tab 6 जन्मवेळची स्थिती must copy the birth-date planetary position.
   The first planetary row (दि:) is always the birth-date 05:30 position.
   Do NOT interpolate or replace this row with the second date's position.
   Keep all earlier Tab 6 motion/total calculations unchanged. */
(function(){
  function dmsToSec(v){
    if(!v) return NaN;
    let t=String(v).trim().replace(/\s*R\s*$/i,'');
    let neg=/^-/.test(t); t=t.replace(/^[-+]/,'');
    let p=t.split(':').map(Number);
    if(p.length!==3 || p.some(x=>!Number.isFinite(x))) return NaN;
    let s=Math.abs(p[0])*3600+Math.abs(p[1])*60+Math.abs(p[2]);
    return neg?-s:s;
  }
  function norm(s){ return ((s%1296000)+1296000)%1296000; }
  function fmt(s){
    if(!Number.isFinite(s)) return '';
    s=Math.round(s);
    s=norm(s);
    const d=Math.floor(s/3600), m=Math.floor((s%3600)/60), x=s%60;
    return String(d).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(x).padStart(2,'0');
  }
  function copyBirthDatePositions(){
    if(document.getElementById('chart-kind')?.value==='horary')return;
    const dob=(document.getElementById('dob')?.value||'').trim();
    const rd1=(document.getElementById('p6_row_date_1')?.value||document.getElementById('p6_date_1')?.value||'').trim();
    const rd2=(document.getElementById('p6_row_date_2')?.value||document.getElementById('p6_date_2')?.value||'').trim();
    const sourcePrefix=rd1===dob?'p6_d_':(rd2===dob?'p6_t_':'');
    if(!sourcePrefix) return;
    for(let i=0;i<9;i++){
      const source=document.getElementById(sourcePrefix+i);
      const birth=document.getElementById('p6_birth_'+i);
      if(!source||!birth) continue;
      const v=source.value.trim();
      birth.value=v;

      // Keep the downstream calculation consistent: बेरीज = birth-date position + एकूण.
      const total=document.getElementById('p6_total_'+i);
      const add=document.getElementById('p6_add_'+i);
      const bs=dmsToSec(v), ts=dmsToSec(total?.value||'');
      if(add){ add.value=(Number.isFinite(bs)&&Number.isFinite(ts)) ? fmt(bs+ts) : ''; }

      // Row after बेरीज: subtract completed 30-degree rashi blocks.
      const sum=dmsToSec(add?.value||'');
      const ay=document.getElementById('p6_ayan_'+i);
      const fin=document.getElementById('p6_final_'+i);
      const rash=document.getElementById('p6_rashi_'+i);
      if(Number.isFinite(sum)){
        const idx=Math.floor(norm(sum)/108000);
        const rem=norm(sum)-idx*108000;
        if(ay) ay.value=fmt(idx*108000);
        if(fin) fin.value=fmt(rem);
        const names=['मेष','वृषभ','मिथुन','कर्क','सिंह','कन्या','तुला','वृश्चिक','धनु','मकर','कुंभ','मीन'];
        if(rash) rash.value=names[idx%12]||'';
      }
    }
  }
  window.copyBirthDatePositions=copyBirthDatePositions;
  document.addEventListener('DOMContentLoaded',function(){
    ['dob','birthTime','p6_date_1','p6_date_2','p6_time_1','p6_time_2','p6_ampm_1','p6_ampm_2'].forEach(id=>{
      const e=document.getElementById(id);
      if(e){ e.addEventListener('input',()=>setTimeout(copyBirthDatePositions,0)); e.addEventListener('change',()=>setTimeout(copyBirthDatePositions,0)); }
    });
    for(let i=0;i<9;i++){
      const e=document.getElementById('p6_d_'+i);
      if(e){ e.addEventListener('input',copyBirthDatePositions); e.addEventListener('change',copyBirthDatePositions); }
    }
    setTimeout(copyBirthDatePositions,50);
    setTimeout(copyBirthDatePositions,250);
  });
})();

