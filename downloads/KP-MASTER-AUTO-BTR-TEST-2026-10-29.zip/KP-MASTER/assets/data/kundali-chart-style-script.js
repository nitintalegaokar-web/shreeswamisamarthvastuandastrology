
(function () {
  'use strict';
  const byId = id => document.getElementById(id);
  const NS = 'http://www.w3.org/2000/svg';
  const ROMAN = ['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];
  const POLYGONS = [
    [[240,0],[360,120],[240,240],[120,120]], [[0,0],[240,0],[120,120]], [[0,0],[120,120],[0,240]],
    [[0,240],[120,120],[240,240],[120,360]], [[0,240],[120,360],[0,480]], [[0,480],[120,360],[240,480]],
    [[240,240],[360,360],[240,480],[120,360]], [[240,480],[360,360],[480,480]], [[360,360],[480,240],[480,480]],
    [[240,240],[360,120],[480,240],[360,360]], [[480,0],[480,240],[360,120]], [[240,0],[480,0],[360,120]]
  ];
  const CENTRES = [[240,120],[120,40],[40,120],[120,240],[40,360],[120,440],[240,360],[360,440],[440,360],[360,240],[440,120],[360,40]];
  let renderSignature = '', queued = false, menu = null, returnFocus = null;
  const getStyle = () => byId('kundali-chart-style')?.value === 'north' ? 'north' : 'south';
  const getSourceId = () => getStyle() === 'north' ? 'kundali-north' : 'kundali';
  function svgNode(name, attributes, text) {
    const node = document.createElementNS(NS,name);
    Object.entries(attributes || {}).forEach(([key,value]) => node.setAttribute(key,String(value)));
    if (text !== undefined) node.textContent = text;
    return node;
  }
  function horizontalBounds(polygon,y) {
    const intersections = [];
    polygon.forEach((a,index) => {
      const b = polygon[(index + 1) % polygon.length];
      if (a[1] === b[1]) { if (Math.abs(y - a[1]) < 1e-6) intersections.push(a[0],b[0]); }
      else if (y >= Math.min(a[1],b[1]) && y <= Math.max(a[1],b[1])) intersections.push(a[0] + (y - a[1]) * (b[0] - a[0]) / (b[1] - a[1]));
    });
    return [Math.min(...intersections),Math.max(...intersections)];
  }
  function renderNorth() {
    const target = byId('kundali-north'), model = window.currentKPModel;
    if (!target) return;
    if(window.KPPairedNorth){window.KPPairedNorth.render(target,model,window.KPHomeChartReference?.getHouse()||1);return;}
    const fortuna = window.KPFortuna?.getNatal();
    const signature = JSON.stringify({ready:model?.ready,planets:model?.planets?.map(p => [p.id,p.longitude,byId('p6_motion_' + p.index)?.value]),houses:model?.houses?.map(h => [h.id,h.longitude]),fortuna:fortuna?[fortuna.longitude,fortuna.formulaUsed]:null});
    if (signature === renderSignature) return;
    renderSignature = signature;
    if (!model?.ready) {
      const message = document.createElement('p'); message.className = 'north9-empty';
      message.textContent = 'Complete the twelve house cusps and planet positions to view the North Indian kundali.';
      target.replaceChildren(message); return;
    }
    const ascSign = model.houses[0].signIndex;
    const sectors = Array.from({length:12},() => ({cusps:[],planets:[]}));
    model.houses.forEach(cusp => sectors[(cusp.signIndex - ascSign + 12) % 12].cusps.push(cusp));
    [...model.planets,...(fortuna?[fortuna]:[])].forEach(planet => sectors[(planet.signIndex - ascSign + 12) % 12].planets.push(planet));
    const svg = svgNode('svg',{viewBox:'0 0 480 480',role:'img','aria-label':'North Indian natal kundali, cusps on the left and planets on the right',preserveAspectRatio:'xMidYMid meet'});
    svg.append(svgNode('title',{},'North Indian kundali · natal Rashi chart'));
    svg.append(svgNode('desc',{},'Signs run counterclockwise from the Ascendant in the upper diamond. Each cusp and planet retains its calculated sidereal longitude. Blue entries are house cusps; green entries are planets.'));
    svg.append(svgNode('rect',{x:1,y:1,width:478,height:478,fill:'#fff',stroke:'#a3a0b5','stroke-width':2}));
    svg.append(svgNode('path',{d:'M0 0L480 480M480 0L0 480M240 0L480 240L240 480L0 240Z',fill:'none',stroke:'#b7b2c6','stroke-width':1.2}));
    sectors.forEach((sector,index) => {
      const sign = (ascSign + index) % 12 + 1, [,cy] = CENTRES[index];
      const group = svgNode('g',{'data-sign':sign,'data-rashi-house':index + 1});
      const labelY = cy - 22, labelBounds = horizontalBounds(POLYGONS[index],labelY);
      group.append(svgNode('text',{x:(labelBounds[0] + labelBounds[1]) / 2,y:labelY,'text-anchor':'middle',fill:'#6c598d','font-size':11,'font-weight':650},sign + (index === 0 ? ' · Lagna' : '')));
      const count = Math.max(sector.cusps.length,sector.planets.length);
      const lineHeight = Math.min(17,56 / Math.max(1,count));
      const addEntry = (point,kind,row) => {
        const y = cy - 5 + row * lineHeight;
        const bounds = horizontalBounds(POLYGONS[index],y - lineHeight / 3), centre = (bounds[0] + bounds[1]) / 2;
        const retro = kind === 'planet' && /R/i.test(byId('p6_motion_' + point.index)?.value || '');
        const label = (kind === 'cusp' ? ROMAN[point.id - 1] : point.id) + (retro ? 'ᴿ' : '') + ' ' + point.degree;
        const laneWidth = Math.max(5,(bounds[1] - bounds[0]) / 2 - 9);
        const size = Math.min(10.5,lineHeight * .72,laneWidth / Math.max(1,label.length * .61));
        const attributes = {x:kind === 'cusp' ? centre - 4 : centre + 4,y,'text-anchor':kind === 'cusp' ? 'end' : 'start',fill:kind === 'cusp' ? '#778ad0' : '#597332','font-size':size,'font-weight':600,'data-longitude':point.longitude,'data-original-name':kind==='cusp'?ROMAN[point.id-1]:point.id,'data-original-degree':point.degree+(retro?' R':'')};
        attributes[kind === 'cusp' ? 'data-cusp' : 'data-planet'] = point.id;
        const entry = svgNode('text',attributes,label);
        entry.append(svgNode('title',{},(kind === 'cusp' ? 'House ' + ROMAN[point.id - 1] : point.name) + ' · ' + point.sign + ' ' + point.degree));
        group.append(entry);
      };
      sector.cusps.forEach((point,row) => addEntry(point,'cusp',row));
      sector.planets.forEach((point,row) => addEntry(point,'planet',row));
      svg.append(group);
    });
    target.replaceChildren(svg);
  }
  function syncControls() {
    const style = getStyle(), title = style === 'north' ? 'North Indian kundali' : 'South Indian kundali';
    ['kundali','kundali-north'].forEach(id => {
      const chart = byId(id), alternate = id !== getSourceId();
      if (!chart) return;
      chart.hidden = alternate;
      if (alternate) chart.dataset.kundaliAlternate = 'true'; else delete chart.dataset.kundaliAlternate;
    });
    document.querySelectorAll('[data-kundali-style-control]').forEach(select => { select.value = style; });
    if (byId('home-kundali-title')) byId('home-kundali-title').textContent = title;
    byId('home-kundali')?.setAttribute('aria-label',title + ' overview');
    const edit = document.querySelector('#south9 button[onclick="enableKundaliEdit()"]');
    if (edit) { edit.disabled = style === 'north'; edit.title = style === 'north' ? 'Switch to South Indian kundali to edit the chart notes.' : ''; }
    menu?.querySelectorAll('[data-kundali-style]').forEach(button => {
      const selected = button.dataset.kundaliStyle === style;
      button.setAttribute('aria-checked',String(selected));
      button.querySelector('.kundali-menu-mark').textContent = selected ? '✓' : '';
    });
  }
  function refresh() {
    const input = byId('kundali-chart-style');
    if (input && !['south','north'].includes(input.value)) input.value = 'south';
    renderNorth(); syncControls(); window.KPFortuna?.updateInfo('kundali-fortuna-info',window.KPFortuna.getNatal()); window.refreshHomeDashboard?.();
  }
  function setStyle(style) {
    if (!['south','north'].includes(style)) return false;
    const input = byId('kundali-chart-style'); if (!input) return false;
    const changed = getStyle() !== style; input.value = style; refresh();
    if (changed) {
      window.dispatchEvent(new CustomEvent('kundali-style-changed',{detail:{style}}));
      window.dispatchEvent(new Event('chart-manual-change'));
    }
    return true;
  }
  function scheduleRefresh() {
    if (queued) return; queued = true;
    requestAnimationFrame(() => { queued = false; refresh(); });
  }
  function closeMenu(restoreFocus) {
    if (!menu || menu.hidden) return;
    menu.hidden = true;
    if (restoreFocus && returnFocus?.isConnected) {
      const focusTarget = ['home-kundali','na-native-chart'].includes(returnFocus.id) ? returnFocus : byId(getSourceId());
      focusTarget?.focus({preventScroll:true});
    }
  }
  function openMenu(x,y,origin) {
    returnFocus = origin.closest('#home-kundali,#na-native-chart') || origin.closest('#kundali,#kundali-north');
    syncControls(); menu.hidden = false;
    const rect = menu.getBoundingClientRect();
    menu.style.left = Math.max(8,Math.min(x,window.innerWidth - rect.width - 8)) + 'px';
    menu.style.top = Math.max(8,Math.min(y,window.innerHeight - rect.height - 8)) + 'px';
    (menu.querySelector('[aria-checked="true"]') || menu.querySelector('button')).focus({preventScroll:true});
  }
  function initialize() {
    menu = document.createElement('div'); menu.id = 'kundali-style-menu'; menu.className = 'kundali-context-menu no-print'; menu.hidden = true;
    menu.setAttribute('role','menu'); menu.setAttribute('aria-label','Kundali chart style');
    ['north','south'].forEach(style => {
      const button = document.createElement('button'); button.type = 'button'; button.id = 'kundali-style-' + style;
      button.dataset.kundaliStyle = style; button.setAttribute('role','menuitemradio'); button.setAttribute('aria-checked','false');
      const mark = document.createElement('span'); mark.className = 'kundali-menu-mark'; mark.setAttribute('aria-hidden','true');
      const label = document.createElement('span'); label.textContent = style === 'north' ? 'North Indian kundali' : 'South Indian kundali';
      button.append(mark,label); button.addEventListener('click',() => { setStyle(style); closeMenu(true); }); menu.append(button);
    });
    document.body.append(menu);
    document.querySelectorAll('[data-kundali-style-control]').forEach(select => {
      select.addEventListener('input',event => event.stopPropagation());
      select.addEventListener('change',event => { event.stopPropagation(); setStyle(select.value); });
    });
    document.addEventListener('contextmenu',event => {
      const chart = event.target.closest('#kundali,#kundali-north,#home-kundali,#na-native-chart');
      if (!chart) return; event.preventDefault(); openMenu(event.clientX,event.clientY,chart);
    });
    document.addEventListener('keydown',event => {
      const chart = event.target.closest('#kundali,#kundali-north,#home-kundali,#na-native-chart');
      if (chart && (event.key === 'ContextMenu' || event.key === 'F10' && event.shiftKey)) {
        event.preventDefault(); const rect = chart.getBoundingClientRect(); openMenu(rect.left + rect.width / 2,rect.top + Math.min(rect.height / 2,80),chart); return;
      }
      if (menu.hidden) return;
      if (event.key === 'Escape') { event.preventDefault(); closeMenu(true); }
      else if (['ArrowDown','ArrowUp','Home','End'].includes(event.key)) {
        event.preventDefault(); const buttons = [...menu.querySelectorAll('button')], current = buttons.indexOf(document.activeElement);
        const next = event.key === 'Home' ? 0 : event.key === 'End' ? buttons.length - 1 : (current + (event.key === 'ArrowUp' ? -1 : 1) + buttons.length) % buttons.length;
        buttons[next].focus();
      } else if (event.key === 'Tab') closeMenu(false);
    });
    document.addEventListener('pointerdown',event => { if (!menu.contains(event.target)) closeMenu(false); });
    window.addEventListener('resize',() => closeMenu(false));
    // Close for a user's scroll gesture. A queued automatic chart scroll can
    // finish just after right-click, and must not immediately dismiss the menu.
    document.addEventListener('wheel',() => closeMenu(false),{passive:true});
    document.addEventListener('touchmove',() => closeMenu(false),{passive:true});
    ['chart-saved','kp-ephemeris-ready'].forEach(name => window.addEventListener(name,scheduleRefresh));
    const observer = new MutationObserver(scheduleRefresh);
    ['kundali','kp-basic-planet','kp-basic-house'].forEach(id => { const node = byId(id); if (node) observer.observe(node,{childList:true,subtree:true,characterData:true}); });
    refresh();
  }
  window.KPChartStyle = Object.freeze({getSourceId,getStyle,setStyle,refresh});
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',initialize); else initialize();
})();

