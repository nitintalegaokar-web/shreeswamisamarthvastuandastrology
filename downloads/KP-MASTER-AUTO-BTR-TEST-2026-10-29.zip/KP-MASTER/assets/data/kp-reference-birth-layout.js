
(() => {
 'use strict';
 function mount(){
  const byId=id=>document.getElementById(id),grid=document.querySelector('#basic .birth-card>.grid');
  if(!grid||grid.dataset.referenceLayout)return;grid.dataset.referenceLayout='true';
  const make=className=>{const node=document.createElement('div');node.className=className;return node;};
  const field=id=>byId(id)?.closest('div');
  const identity=make('birth-reference-identity'),columns=make('birth-reference-columns'),left=make('birth-reference-left'),right=make('birth-reference-right'),comments=make('birth-reference-comments'),calculations=make('birth-reference-calculations');
  const old=document.querySelector('#basic .horary-controls');
  [field('name'),field('chart-gender'),field('chart-category'),field('chart-add-category')].forEach(node=>{if(node)identity.append(node);});
  ['dob','birthTime','birth-utc-offset','birth-dst-minutes','birthPlace','lat','lon'].forEach(id=>{const node=field(id);if(node)left.append(node);});
  const placePicker=grid.querySelector('.kp-india-picker[data-place-for="birthPlace"]');
  if(placePicker)left.querySelector('#birthPlace').closest('div').after(placePicker);
  const kind=field('chart-kind');if(kind)right.append(kind);
  if(byId('horary-inputs'))right.append(byId('horary-inputs'));
  if(byId('horary-status'))right.append(byId('horary-status'));
  const notes=byId('chart-notes'),notesLabel=document.querySelector('label[for="chart-notes"]');
  if(notesLabel)comments.append(notesLabel);if(notes)comments.append(notes);
  columns.append(left,right);
  [...grid.children].filter(node=>node!==old&&!node.classList.contains('form-divider')).forEach(node=>calculations.append(node));
  grid.replaceChildren(identity,columns,comments,calculations);
  const picker=left.querySelector('.kp-india-picker');
  if(picker){const disclosure=document.createElement('details');disclosure.className='birth-reference-place-picker no-print';const summary=document.createElement('summary');summary.textContent='Choose Indian city / village';picker.before(disclosure);disclosure.append(summary,picker);byId('birthPlace').addEventListener('focus',()=>{disclosure.open=true;});}
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
})();

