
(() => {
  'use strict';
  const byId=id=>document.getElementById(id);
  const source=window.updateRaphaelTable5;
  if(typeof source==='function')window.updateRaphaelTable5=function(...args){const result=source.apply(this,args);window.KPHorary?.apply();return result;};
  function go(id){document.querySelector('.app-sidebar [data-tab="'+id+'"]')?.click();}
  function selectPrint(id){window.renderReport?.();go('report');window.KPReportPages?.selectSections([id]);byId('report-page-options')?.focus();}
  window.addEventListener('kp-matchmaking-print-request',()=>selectPrint('matchmaking'));
  document.addEventListener('click',event=>{
    if(!event.target.closest('#na-open-transit'))return;
    const mapping={'tc-date':'na-date','tc-time':'na-time','tc-timezone':'na-timezone','tc-place':'na-place','tc-latitude':'na-latitude','tc-longitude':'na-longitude'};
    for(const [target,source] of Object.entries(mapping))if(byId(target)&&byId(source))byId(target).value=byId(source).value;
    if(byId('tc-cusp-source'))byId('tc-cusp-source').value=byId('na-cusp-source')?.value||'natal';
    window.KPTransitChart?.calculate();go('transit-chart');
  });
  function initialize(){
    for(const id of ['home-dasha-date','home-dasha-time','home-chart-reference'])if(byId(id))byId(id).dataset.calculationLocked='true';
    const natalName=byId('name');if(natalName)natalName.maxLength=99;
    setTimeout(()=>{window.renderReport?.();window.KPReportPages?.refresh();},0);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

