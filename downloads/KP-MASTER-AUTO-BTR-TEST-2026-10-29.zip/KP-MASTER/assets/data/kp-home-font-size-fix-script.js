
(function(){
  'use strict';
  function refresh(){
    const preferences=window.KPPreferences;
    if(!document.body||!preferences)return;
    const configured=Boolean(preferences.isConfigured());
    document.body.dataset.kpTableSizeConfigured=String(configured);
    const settings=preferences.get();
    const ratio=({small:.9,medium:1,large:1.08})[settings.tableSize]||1;
    document.body.style.setProperty('--kp-table-size-ratio',String(ratio));
    if(!configured)return;
    const planet=({small:.85,medium:1,large:1.2})[settings.planetSize]||1;
    const degree=({small:.85,medium:1,large:1.15})[settings.degreeSize]||1;
    document.querySelectorAll('#home .north9-chart svg text[data-longitude]').forEach(point=>{
      const capacity=Number(point.dataset.kpOriginalSize||point.dataset.kpHomeFontCapacity||point.getAttribute('font-size'));
      if(!Number.isFinite(capacity)||capacity<=0)return;
      if(!point.dataset.kpHomeFontCapacity)point.dataset.kpHomeFontCapacity=String(capacity);
      const rendered=[...point.childNodes].filter(node=>node.nodeType===3||node.nodeType===1&&node.matches?.('[data-kp-degree-label]')).map(node=>node.textContent).join('');
      const original=point.dataset.kpOriginalLabel||rendered;
      const fit=Math.min(1,Math.max(1,original.length)/Math.max(1,rendered.length));
      // The renderer's original font is its maximum safe lane size. Reserve
      // growth space at Medium so Large is visibly larger without collisions.
      const nameSize=capacity*fit*(point.dataset.cusp?degree:planet)*(settings.fontSize/12)/1.2+'px';
      const degreeSize=capacity*fit*degree*(settings.fontSize/12)/1.2+'px';
      if(point.style.getPropertyValue('--kp-home-north-point-size')!==nameSize)point.style.setProperty('--kp-home-north-point-size',nameSize);
      if(point.style.getPropertyValue('--kp-home-north-degree-size')!==degreeSize)point.style.setProperty('--kp-home-north-degree-size',degreeSize);
    });
  }
  function initialize(){
    refresh();
    window.addEventListener('kp-preferences-changed',refresh);
    window.addEventListener('chart-saved',refresh);
    const style=document.getElementById('kp-preference-values');
    if(style)new MutationObserver(refresh).observe(style,{childList:true,characterData:true,subtree:true});
    const chart=document.getElementById('home-kundali');
    if(chart)new MutationObserver(refresh).observe(chart,{childList:true,subtree:true,attributes:true,attributeFilter:['font-size','data-kp-original-size']});
  }
  window.KPTableFontSizes=Object.freeze({refresh});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

