
(() => {
  'use strict';
  const byId = id => document.getElementById(id);
  const shell = byId('kp-settings-shell');
  if (!shell) return;
  const controls = [...shell.querySelectorAll('[data-setting]')];
  const tabs = [...shell.querySelectorAll('[data-settings-tab]')];
  const clone = value => JSON.parse(JSON.stringify(value));
  let defaults = {};
  let activeLanguage = 'english';

  function setStatus(message) {
    const status = byId('settings-status');
    if (status) status.textContent = String(message || '');
  }

  function getDraft() {
    const output = clone(defaults);
    controls.forEach(control => {
      output[control.dataset.setting] = control.type === 'checkbox' ? control.checked :
        control.type === 'number' ? control.valueAsNumber : control.hasAttribute('data-number-setting') ? Number(control.value) : control.value;
    });
    return output;
  }

  function setDraft(settings) {
    const values = {...defaults, ...(settings || {})};
    controls.forEach(control => {
      const value = values[control.dataset.setting];
      if (value === undefined) return;
      if (control.type === 'checkbox') control.checked = Boolean(value);
      else control.value = String(value);
    });
    setStatus('');
    shell.querySelectorAll('[data-settings-preset]').forEach(button=>button.setAttribute('aria-pressed','false'));
    updateContext();
    shell.dispatchEvent(new CustomEvent('settings-draft-restored'));
  }

  function updateContext() {
    const summary = byId('settings-ayan-summary');
    if (!summary) return;
    const value = byId('ayanValue')?.value || '—';
    const year = byId('ayanYear')?.value || '';
    summary.textContent = value + (year ? ' · ' + year : '');
  }

  function activate(category, focus = false) {
    const selected = tabs.find(tab => tab.dataset.settingsTab === category);
    if (!selected) return;
    tabs.forEach(tab => {
      const isSelected = tab === selected;
      tab.setAttribute('aria-selected', String(isSelected));
      tab.tabIndex = isSelected ? 0 : -1;
      const panel = byId(tab.getAttribute('aria-controls'));
      if (panel) panel.hidden = !isSelected;
    });
    updateContext();
    if (focus) selected.focus();
  }

  function setLanguage(language) {
    activeLanguage = ['english','marathi','bilingual'].includes(language) ? language : 'english';
    shell.querySelectorAll('[data-settings-en]').forEach(element => {
      const en = element.dataset.settingsEn;
      const mr = element.dataset.settingsMr || en;
      element.textContent = activeLanguage === 'marathi' ? mr :
        activeLanguage === 'bilingual' && mr !== en ? en + ' · ' + mr : en;
    });
    shell.querySelector('[role="tablist"]')?.setAttribute('aria-label',
      activeLanguage === 'marathi' ? 'सेटिंग्ज विभाग' : 'Settings categories');
  }

  function initialize(values) {
    defaults = clone(values || {});
    setDraft(defaults);
  }

  function markDraft() {
    const message = activeLanguage === 'marathi' ? 'बदल लागू करण्यासाठी जतन करा.' :
      activeLanguage === 'bilingual' ? 'Save to apply your changes. · बदल लागू करण्यासाठी जतन करा.' :
      'Save to apply your changes.';
    setStatus(message);
  }

  tabs.forEach(tab => {
    tab.addEventListener('click', () => activate(tab.dataset.settingsTab));
    tab.addEventListener('keydown', event => {
      const index = tabs.indexOf(tab);
      let next = index;
      if (event.key === 'ArrowDown' || event.key === 'ArrowRight') next = (index + 1) % tabs.length;
      else if (event.key === 'ArrowUp' || event.key === 'ArrowLeft') next = (index - 1 + tabs.length) % tabs.length;
      else if (event.key === 'Home') next = 0;
      else if (event.key === 'End') next = tabs.length - 1;
      else return;
      event.preventDefault();
      activate(tabs[next].dataset.settingsTab, true);
    });
  });

  shell.addEventListener('input', event => {
    if (event.target.matches('[data-setting],#astroName,#astroMobile,#astroAddress')) markDraft();
    if(event.target.matches('[data-setting]'))event.stopPropagation();
  });
  shell.addEventListener('change', event => {
    if (event.target.matches('[data-setting],#astroName,#astroMobile,#astroAddress')) markDraft();
    if(event.target.matches('[data-setting]'))event.stopPropagation();
  });
  shell.addEventListener('click', event => {
    const opener = event.target.closest('[data-settings-open]');
    if (opener) document.querySelector('.app-sidebar nav button[data-tab="' + opener.dataset.settingsOpen + '"]')?.click();


    const preset = event.target.closest('[data-settings-preset]');
    if (!preset) return;
    const presets={classic:{chartStyle:'south',planetSize:'medium',degreeSize:'medium',tableSize:'medium',interpretiveSize:'medium',resolution:'auto',planetNotation:'full',aspectSet:'major',homeView:'basic',fontSize:12},compact:{planetSize:'small',degreeSize:'small',tableSize:'small',interpretiveSize:'small',resolution:'compact',planetNotation:'short',fontSize:11},presentation:{planetSize:'large',degreeSize:'large',tableSize:'large',interpretiveSize:'large',resolution:'wide',planetNotation:'short',fontSize:16}};
    const name=preset.dataset.settingsPreset;if(!presets[name])return;
    setDraft({...getDraft(),...presets[name]});
    shell.querySelectorAll('[data-settings-preset]').forEach(button=>button.setAttribute('aria-pressed',String(button===preset)));
    setStatus(preset.querySelector('strong').textContent+' selected. Review the options, then Save to apply.');
  });

  byId('settings-save')?.addEventListener('click', async () => {
    const invalid = controls.find(control => !control.checkValidity());
    if (invalid) {
      const panel = invalid.closest('[role="tabpanel"]');
      if (panel) activate(panel.id.replace('settings-pane-',''));
      setStatus(invalid.validationMessage);
      invalid.reportValidity();
      invalid.focus();
      return;
    }
    if (!window.KPPreferences?.save) {
      setStatus('Settings are loading. Please try Save again.');
      return;
    }
    try { await window.KPPreferences.save(getDraft()); }
    catch (error) { setStatus(error?.message || 'Could not save these settings.'); }
  });

  byId('settings-cancel')?.addEventListener('click', () => {
    setDraft(window.KPPreferences?.get?.() || defaults);
    setStatus(activeLanguage === 'marathi' ? 'जतन केलेले पर्याय पुन्हा लावले.' : 'Restored your saved settings.');
  });

  window.KPSettings = Object.freeze({initialize,getDraft,setDraft,setStatus,setLanguage,activate});
})();

