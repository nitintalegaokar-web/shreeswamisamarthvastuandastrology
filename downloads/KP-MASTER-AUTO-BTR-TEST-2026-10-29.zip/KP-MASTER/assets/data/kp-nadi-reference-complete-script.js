
(()=>{
'use strict';const $=id=>document.getElementById(id),el=(tag,text)=>{const n=document.createElement(tag);if(text)n.textContent=text;return n;};
const ROMAN=['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];
function table(headers,rows,id){const t=el('table');t.className='na-table';if(id)t.id=id;const head=el('thead'),hr=el('tr');headers.forEach(h=>hr.append(el('th',h)));head.append(hr);const body=el('tbody');rows.forEach(values=>{const tr=el('tr');values.forEach(v=>tr.append(el('td',String(v??'—'))));body.append(tr);});t.append(head,body);return t;}
function detail(point){return window.KPDisplay.longitudeDetails(point.longitude);}
function initialize(){
 const root=document.querySelector('#nadi-astrology .na-ref-window');if(!root||$('na-cuspal-positions'))return;
 $('na-native-chart').dataset.selectedNadiChart='true';
 const positions=root.querySelector('.na-ref-positions'),controls=root.querySelector('.na-ref-controls'),coordinates=root.querySelector('.na-ref-coordinates');
 const cuspMount=el('div');cuspMount.id='na-cuspal-positions';positions.append(el('h3','CUSPAL POSITION'),cuspMount);
 root.querySelector('.na-ref-chart>h3').textContent='RASHI CHART';
 const main=el('div');main.className='na-reference-main';main.append(positions,root.querySelector('.na-ref-chart'),coordinates);root.prepend(main);
 const side=el('div');side.className='na-reference-side';const dasha=el('section');dasha.className='na-reference-dasha';dasha.append(el('h3','Vimshottari Dasha · Native'));const dashaMount=el('div');dashaMount.id='na-reference-dasha';dasha.append(dashaMount);
 const rp=el('section');rp.className='na-reference-rp';rp.append(el('h3','RULING PLANETS'));const rpMount=el('div');rpMount.id='na-reference-rp';rp.append(rpMount);
 side.append(dasha,rp,controls);root.append(side);
 const advanced=el('details');advanced.open=true;advanced.className='na-reference-options';advanced.append(el('summary','Chart options'));const fields=el('div');for(const id of ['na-source','na-method','na-cusp-source']){const input=$(id);if(input)fields.append(input.parentElement);}advanced.append(fields);controls.querySelector('.na-ref-inputs').append(advanced);
 const eventOptions=el('details');eventOptions.className='na-reference-options';eventOptions.append(el('summary','Find event'));const eventFields=el('div');for(const id of ['na-category','na-search'])if($(id))eventFields.append($(id).parentElement);eventOptions.append(eventFields);coordinates.querySelector('.na-ref-query').append(eventOptions);
 $('na-event').previousElementSibling.textContent='Event';
 const picker=controls.querySelector('.kp-india-picker');if(picker){const disclosure=el('details');disclosure.className='na-reference-options';disclosure.append(el('summary','Find Indian city / village'),picker);controls.querySelector('.na-ref-inputs').append(disclosure);}
 for(const selector of ['.na-ref-criteria','.na-ref-notes']){const section=root.querySelector(selector);if(!section)continue;const disclosure=el('details');disclosure.append(el('summary',selector.endsWith('criteria')?'Event criteria':'Event notes'));while(section.firstChild)disclosure.append(section.firstChild);section.append(disclosure);}

 function synchronize(){
  const data=window.KPNadiAstrology.getData();if(!data?.ready){cuspMount.replaceChildren(el('p',data?.reason||'Complete the selected chart.'));$('na-native-chart').replaceChildren(el('p',data?.reason||'Complete the selected chart.'));rpMount.replaceChildren();return;}
  const houses=data.model.houses,planets=data.model.planets;
  const rows=houses.map((p,i)=>{const d=detail(p);return [ROMAN[i],d.signCode,d.degree,d.sgl,d.stl,d.sl,d.ssl];});cuspMount.replaceChildren(table(['Cusp','Sign','D-M-S','RL','STL','SL','SSL'],rows,'na-cusp-table'));
  const planetRows=planets.map(p=>{const d=detail(p);return [p.id,d.signCode,d.degree,[p.retrograde?'R':'',p.combust?'C':''].filter(Boolean).join('/'),d.sgl,d.stl,d.sl,d.ssl,p.occ??'—'];});$('na-positions').replaceChildren(table(['Planet','Sign','D-M-S','R/C','RL','STL','SL','SSL','Hse'],planetRows,'na-reference-planet-table'));
  const chart=KPSouthChart.fromModel(data);chart.classList.add('na-reference-rashi');if(window.KPChartStyle?.getStyle()==='north'){window.KPNadiChartStyle.renderNorth(data,chart);chart.classList.remove('v38-chart');delete chart.dataset.reportId;}$('na-native-chart').replaceChildren(chart);
  const rpRows=[['Asc',houses[0]],...['Mo','Ra','Ke'].map(id=>[id,planets.find(p=>p.id===id)])].map(([name,p])=>{const d=detail(p);return [name,d.sgl,d.stl,d.sl,d.ssl];});const caption=el('p',data.moment.date+' · '+data.moment.time+' · '+(data.source==='moment'?'Selected Nadi chart':'Native chart'));caption.className='na-reference-rp-caption';rpMount.replaceChildren(caption,table(['RP','SGL','STL','SL','SSL'],rpRows));
 }
 let scheduled=false;function schedule(){if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;synchronize();});}
 // Observe the calculator's results, not this screen's generated tables.
 new MutationObserver(schedule).observe($('na-grid'),{childList:true});$('na-update').addEventListener('click',schedule);window.addEventListener('chart-saved',schedule);window.addEventListener('kundali-style-changed',schedule);
 function mirrorDasha(){const source=$('home-vimshottari');if(!source)return;const clone=source.cloneNode(true);clone.querySelector('.home-panel-heading')?.remove();[clone,...clone.querySelectorAll('[id]')].forEach(n=>{if(n.id){n.dataset.nadiDashaSource=n.id;n.id='na-mirror-'+n.id;}n.removeAttribute('data-bridge-id');});clone.querySelectorAll('input,select').forEach(n=>{const original=$(n.dataset.nadiDashaSource);n.dataset.calculationLocked='true';if(original)n.value=original.value;});dashaMount.replaceChildren(clone);}
 dashaMount.addEventListener('change',event=>{const original=$(event.target.dataset.nadiDashaSource);if(original){original.value=event.target.value;original.dispatchEvent(new Event('change',{bubbles:true}));mirrorDasha();}});
 dashaMount.addEventListener('click',event=>{const button=event.target.closest('button');if(!button)return;let original;if(button.dataset.nadiDashaSource)original=$(button.dataset.nadiDashaSource);else if(button.dataset.dashaChoice!==undefined)original=$('home-vimshottari').querySelector('[data-dasha-choice="'+button.dataset.dashaChoice+'"]');else if(button.dataset.dashaDepth!==undefined)original=$('home-vimshottari').querySelector('[data-dasha-depth="'+button.dataset.dashaDepth+'"]');if(original){original.click();mirrorDasha();}});
 if($('home-dasha-table'))new MutationObserver(mirrorDasha).observe($('home-dasha-table'),{childList:true,subtree:true});mirrorDasha();synchronize();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

