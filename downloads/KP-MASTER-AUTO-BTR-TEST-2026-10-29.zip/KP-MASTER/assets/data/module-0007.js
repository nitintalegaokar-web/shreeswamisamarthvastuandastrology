
/* v19 FINAL — Tab 6: date selectors only on planetary rows + birth-position selector.
   - First planetary row date = birth date (editable/checkable date selector).
   - Second planetary row date = next day when birth is 05:30 AM or later;
     preceding day when birth is before 05:30 AM.
   - Daily motion is chronological: later 05:30 position minus earlier 05:30 position.
   - Birth-time position is interpolated from the BIRTH-DATE 05:30 position:
       after 05:30 -> first row + daily motion × elapsed fraction;
       before 05:30 -> first row + (birth date - preceding date) motion × elapsed fraction.
   - The date selectors are shown directly beside the planetary-position row labels.
   - Tabs 1–5 calculations are untouched.
*/
(function(){
  const N=9, DAY=86400, FIVE30=19800, FULL=1296000;
  const names=['रवी','चंद्र','मंगळ','बुध','गुरु','शुक्र','शनि','राहु','केतु'];
  const rashiNames=['मेष','वृषभ','मिथुन','कर्क','सिंह','कन्या','तुला','वृश्चिक','धनु','मकर','कुंभ','मीन'];
  const pad=n=>String(Math.abs(Math.trunc(n))).padStart(2,'0');
  const parse=v=>{
    if(v==null || String(v).trim()==='') return NaN;
    const a=String(v).trim().replace(/\s*R\s*$/i,'').replace(/^[-+]/,'').split(':').map(Number);
    if(a.length<2 || a.some(x=>!Number.isFinite(x))) return NaN;
    return a[0]*3600+(a[1]||0)*60+(a[2]||0);
  };
  const norm=s=>((s%FULL)+FULL)%FULL;
  const fmt=s=>{
    if(!Number.isFinite(s)) return '';
    s=Math.round(norm(s));
    const d=Math.floor(s/3600); s%=3600; const m=Math.floor(s/60), x=s%60;
    return `${d}:${pad(m)}:${pad(x)}`;
  };
  const fmtSigned=s=>{
    if(!Number.isFinite(s)) return '';
    const neg=s<0; s=Math.abs(Math.round(s));
    const d=Math.floor(s/3600); s%=3600; const m=Math.floor(s/60), x=s%60;
    return `${d}:${pad(m)}:${pad(x)}${neg?' R':''}`;
  };
  const get=id=>(document.getElementById(id)?.value||'').trim();
  const set=(id,v)=>{const e=document.getElementById(id); if(e)e.value=v??'';};
  function isoFromDateInput(v){return v||'';}
  function addDays(iso,delta){
    if(!iso) return '';
    const [y,m,d]=iso.split('-').map(Number); if(!y||!m||!d) return '';
    const x=new Date(y,m-1,d); x.setDate(x.getDate()+delta);
    return `${x.getFullYear()}-${pad(x.getMonth()+1)}-${pad(x.getDate())}`;
  }
  function birthSeconds(){ return parse(get('birthTime')||'05:30:00'); }
  function before0530(){ const s=birthSeconds(); return Number.isFinite(s)&&s<FIVE30; }

  function installRowDateSelectors(){
    const labels=document.querySelectorAll('#planet .planet6-table td.rowlabel');
    if(!labels.length) return;
    const make=(label,id,title)=>{
      if(!label || label.dataset.v19==='1') return;
      label.dataset.v19='1';
      const text=label.textContent.trim();
      label.innerHTML='';
      const span=document.createElement('span'); span.textContent=text; label.appendChild(span);
      const input=document.createElement('input');
      input.type='date'; input.id=id; input.title=title;
      input.style.cssText='display:block;width:132px;margin:4px auto 0;font-size:12px;padding:2px 4px;box-sizing:border-box;';
      label.appendChild(input);
    };
    // Date selectors ONLY for the two planetary-position rows.
    // No date selector is added to the दैनिक गती row.
    make(labels[0],'p6_row_date_1','पहिली ग्रहस्थिती — तारीख निवडा');
    make(labels[1],'p6_row_date_2','दुसरी ग्रहस्थिती — तारीख निवडा');
    // Optional/checkable date for the planetary position used as the birth-time base.
    make(labels[6],'p6_birth_pos_date','जन्मवेळची स्थिती — ग्रहस्थितीची तारीख निवडा');
  }

  function syncRowDates(forceFirst){
    if(document.getElementById('p6-ephemeris-source')?.value==='manual')return;
    const dob=get('dob');
    const d1=document.getElementById('p6_row_date_1');
    const d2=document.getElementById('p6_row_date_2');
    const db=document.getElementById('p6_birth_pos_date');
    if(!d1||!d2) return;
    const before=before0530();
    // Always keep the two rows chronological: preceding day -> birth day for
    // pre-05:30 births; birth day -> following day for 05:30+ births.
    const first=before ? addDays(dob,-1) : dob;
    const second=before ? dob : addDays(dob,1);
    if(forceFirst || !d1.value || d1.dataset.auto==='1') { d1.value=first; d1.dataset.auto='1'; }
    if(forceFirst || !d2.value || d2.dataset.auto==='1') { d2.value=second; d2.dataset.auto='1'; }
    if(db && (forceFirst || !db.value || db.dataset.auto==='1')) {
      // Base planetary position: birth-date 05:30 for normal births;
      // preceding-date 05:30 for births before 05:30.
      db.value=before ? addDays(dob,-1) : dob;
      db.dataset.auto='1';
    }
    set('p6_date_1',d1.value); set('p6_date_2',d2.value);
    set('p6_time_1','05:30:00'); set('p6_time_2','05:30:00');
    set('p6_ampm_1','AM'); set('p6_ampm_2','AM');
  }

  function loadRowPositions(){
    const d1=get('p6_row_date_1'), d2=get('p6_row_date_2');
    if(!d1||!d2 || typeof findEph!=='function') return;
    const a=findEph(d1), b=findEph(d2);
    for(let i=0;i<N;i++){
      if(a) set(`p6_d_${i}`,a[i+1]||'');
      if(b) set(`p6_t_${i}`,b[i+1]||'');
    }
  }

  function calculateV18(){
    installRowDateSelectors();
    syncRowDates(false);
    loadRowPositions();
    const bt=birthSeconds(); if(!Number.isFinite(bt)) return;
    const before=bt<FIVE30;
    const firstDate=get('p6_row_date_1'), secondDate=get('p6_row_date_2');
    const birthPosDate=get('p6_birth_pos_date');
    const elapsed=before ? bt : (bt-FIVE30);
    const fraction=Math.max(0,Math.min(1,elapsed/DAY));
    const birthBaseRowDate=before ? firstDate : firstDate;
    for(let i=0;i<N;i++){
      const first=parse(get(`p6_d_${i}`));
      const second=parse(get(`p6_t_${i}`));
      if(!Number.isFinite(first)||!Number.isFinite(second)) continue;
      // Daily motion is always chronological: second date − first date.
      const daily=second-first;
      set(`p6_motion_${i}`,fmtSigned(daily));
      const h=parse(get(`p6_hours_${i}`)), m=parse(get(`p6_minutes_${i}`));
      if(Number.isFinite(h)&&Number.isFinite(m)) set(`p6_total_${i}`,fmt(h+m));
      else set(`p6_total_${i}`, '');

      // जन्मवेळची स्थिती = जन्मतारखेच्या 05:30 ग्रहस्थितीची थेट प्रत.
      // कोणतीही interpolation / daily-motion गणना येथे वापरायची नाही.
      const dob=get('dob');
      const rd1=get('p6_row_date_1') || get('p6_date_1');
      const rd2=get('p6_row_date_2') || get('p6_date_2');
      const birthPos = rd1===dob ? first : (rd2===dob ? second : NaN);
      set(`p6_birth_${i}`,Number.isFinite(birthPos)?fmt(birthPos):'');
      const total=parse(get(`p6_total_${i}`));
      if(Number.isFinite(total)){
        const sum=norm(birthPos+total); set(`p6_add_${i}`,fmt(sum));
        const idx=Math.floor(sum/108000); const rem=sum-idx*108000;
        set(`p6_ayan_${i}`,fmt(idx*108000)); set(`p6_final_${i}`,fmt(rem)+(daily<0&&i<7?' R':'')); set(`p6_rashi_${i}`,rashiNames[idx%12]);
      }
    }
  }

  document.addEventListener('DOMContentLoaded',()=>{
    installRowDateSelectors();
    syncRowDates(true);
    loadRowPositions();
    ['dob','birthTime'].forEach(id=>{
      const e=document.getElementById(id); if(!e) return;
      e.addEventListener('change',()=>{syncRowDates(true);loadRowPositions();calculateV18();});
      e.addEventListener('input',()=>setTimeout(()=>{syncRowDates(true);loadRowPositions();calculateV18();},0));
    });
    ['p6_row_date_1','p6_row_date_2'].forEach(id=>{
      const el=document.getElementById(id);
      if(el) el.addEventListener('change',()=>{el.dataset.auto='0';loadRowPositions();calculateV18();});
    });
    const bp=document.getElementById('p6_birth_pos_date');
    if(bp) bp.addEventListener('change',()=>{bp.dataset.auto='0';calculateV18();});
    setTimeout(()=>{installRowDateSelectors();syncRowDates(true);loadRowPositions();calculateV18();},100);
    setTimeout(()=>{installRowDateSelectors();loadRowPositions();calculateV18();},500);
  });
})();

