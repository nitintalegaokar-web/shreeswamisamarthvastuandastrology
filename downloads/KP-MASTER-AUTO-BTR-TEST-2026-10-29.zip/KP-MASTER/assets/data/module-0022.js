
/* v30: reliable A4 print */
(function(){
  window.printReport=function(){
    try{
      if(typeof calculateAll==='function') calculateAll();
      if(typeof window.updateKaryeshTables==='function') window.updateKaryeshTables();
      if(typeof window.renderChart==='function') window.renderChart(true);
      if(typeof window.renderReport==='function') window.renderReport();
      const src=document.getElementById('printReport');
      if(!src || !src.innerHTML.trim()){ alert('Print report तयार झालेला नाही. कृपया आधी गणना पूर्ण करा.'); return; }
      const reportHTML=window.KPReportPages ? window.KPReportPages.html() : src.innerHTML;
      if(!reportHTML.trim()){
        const status=document.getElementById('report-page-selection-status');
        if(status){status.textContent='Select at least one page to print.';status.dataset.empty='true';status.dataset.printError='true';status.focus();}
        return;
      }
      const w=window.open('','_blank','width=1000,height=800');
      if(!w){ alert('Print window उघडता आली नाही. Browser मध्ये pop-up allow करा.'); return; }
      // Report snapshots deliberately remove IDs and live event handlers.
      // Keep the legacy chart's ID-based print rules targeting its data marker.
      const styles=Array.from(document.querySelectorAll('style')).map(x=>'<style>'+x.textContent.replace(/#kundali\b/g,'[data-report-id="kundali"]')+'</style>').join('\n')+'<style>@media print{body>.report-page{display:block!important}}</style>';
      w.document.open();
      w.document.write('<!doctype html><html lang="mr"><head><meta charset="UTF-8"><title>KP MASTER Report</title>'+styles+'<style>@page{size:A4 portrait;margin:0}html,body{margin:0!important;padding:0!important;background:#fff!important}body{font-family:"Noto Sans Devanagari","Mangal",Arial,sans-serif}.report-page{width:190mm!important;height:277mm!important;min-height:277mm!important;max-height:277mm!important;margin:0!important;padding:6mm!important;box-sizing:border-box!important;page-break-after:always!important;break-after:page!important;overflow:hidden!important;background:#fff!important}.report-page:last-child{page-break-after:auto!important;break-after:auto!important}.report-page-title{font-size:14px!important;margin:0 0 5mm!important;font-weight:800}.no-print{display:none!important}.south9-chart.v29-chart{width:170mm!important;height:170mm!important;margin:12mm auto 20mm!important}.v29-chart .v29-entry{font-size:8px!important}.v29-chart .s9-center-title{font-size:11px!important}.v29-chart .s9-data{font-size:8px!important}.v29-chart .v29-label{display:none!important}.report-developer-footer{text-align:center!important;font-size:9px!important;font-weight:700!important;border-top:1px solid #777!important;padding-top:3mm!important;margin-top:3mm!important}</style></head><body>'+reportHTML+'</body></html>');
      w.document.close();
      window.KPBookReport?.enhance(w.document);
      if(window.KPA4Preview)w.document.querySelectorAll('[data-report-section="gemstones"],[data-report-section="nadi-astrology"],[data-report-section="kp-fourfold"],[data-report-section="kp-sixfold"],[data-report-section="kp-fourstep-section"]').forEach(page=>window.KPA4Preview.normalize(w.document,page));
      w.focus();
      setTimeout(function(){w.print();},700);
    }catch(e){ console.error(e); alert('Print report मध्ये त्रुटी: '+e.message); }
  };
})();

