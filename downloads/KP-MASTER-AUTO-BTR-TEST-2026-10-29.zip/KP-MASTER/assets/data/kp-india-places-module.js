
(function(){
'use strict';
const source=JSON.parse(document.getElementById('kp-india-places-metadata').textContent);
const fields=new Map(),states=source.states,districts=source.districts,stateByCode=new Map(states.map((s,i)=>[s.code,i]));
const featureLabels={PPL:'Populated place',PPLA:'State / territory seat',PPLA2:'District seat',PPLA3:'Administrative seat (level 3)',PPLA4:'Administrative seat (level 4)',PPLA5:'Administrative seat (level 5)',PPLC:'National capital',PPLX:'Section / neighbourhood',PPLL:'Locality',PPLQ:'Abandoned populated place',PPLH:'Historical populated place',PPLF:'Farm village',PPLR:'Religious populated place',PPLS:'Populated places',PPLW:'Destroyed populated place'};
const $=id=>document.getElementById(id),pause=()=>new Promise(resolve=>setTimeout(resolve,0));
const normal=value=>String(value??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim().replace(/\s+/g,' ');
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let loading=null,table=null,wordPrefix=null,loadError='',observer=null;
const progress=message=>{for(const item of fields.values())if(item.busy)item.status.textContent=message;};
async function ready(){
 if(table)return metadata();if(loading)return loading;
 loading=(async()=>{
  if(typeof DecompressionStream==='undefined')throw new Error('Offline place lookup needs a current browser with gzip support. You can enter place and coordinates manually.');
  await pause();progress('Opening the offline India place index…');
  const dataElement=$('kp-india-places-packed'),base64=dataElement.textContent.trim();
  const binary=atob(base64),bytes=new Uint8Array(binary.length);
  for(let i=0;i<binary.length;i++){bytes[i]=binary.charCodeAt(i);if(i&&i%1048576===0)await pause();}
  if(globalThis.crypto?.subtle){const digest=await crypto.subtle.digest('SHA-256',bytes);const actual=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');if(actual!==source.embeddedSHA256)throw new Error('The embedded India place index failed its integrity check. Enter coordinates manually or reopen the original software file.');}
  const text=await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text();
  const count=source.recordCount,names=new Array(count),normalized=new Array(count),latitude=new Float64Array(count),longitude=new Float64Array(count),state=new Uint8Array(count),district=new Uint16Array(count),population=new Uint32Array(count),feature=new Uint8Array(count),prefixes=new Map();
  const lines=text.split('\n');if(lines.length!==count)throw new Error('The offline India place index is incomplete. Manual coordinate entry remains available.');
  for(let i=0;i<count;i++){
   const row=lines[i].split('\t');if(row.length!==7)throw new Error('The offline India place index contains an invalid row.');
   names[i]=row[0];normalized[i]=normal(row[0]);latitude[i]=Number(row[1]);longitude[i]=Number(row[2]);state[i]=Number(row[3]);district[i]=Number(row[4]);population[i]=Number(row[5]);feature[i]=Number(row[6]);
   for(const prefix of new Set(normalized[i].split(' ').filter(word=>word.length>=3).map(word=>word.slice(0,3)))){let bucket=prefixes.get(prefix);if(!bucket)prefixes.set(prefix,bucket=[]);bucket.push(i);}
   if(!Number.isFinite(latitude[i])||!Number.isFinite(longitude[i])||latitude[i]<-90||latitude[i]>90||longitude[i]<-180||longitude[i]>180||!states[state[i]]||!districts[district[i]]||!source.featureCodes[feature[i]])throw new Error('The offline India place index contains invalid coordinates or administrative codes.');
   if(i&&i%12000===0){progress('Indexing India places · '+Math.round(i/count*100)+'%');await pause();}
  }
  table={names,normalized,latitude,longitude,state,district,population,feature};wordPrefix=prefixes;loadError='';return metadata();
 })().catch(error=>{loadError=error.message||String(error);loading=null;throw error;});
 return loading;
}
function metadata(){return {ready:!!table,recordCount:source.recordCount,mappedStateCount:source.mappedStateCount,states:states.map(s=>({...s})),districts:districts.map(d=>({...d})),source:{...source,states:undefined,districts:undefined},error:loadError};}
function indexOf(id){if(typeof id==='number'&&Number.isInteger(id))return id;const m=/^INP-(\d+)$/.exec(String(id??''));return m?Number(m[1]):-1;}
function record(id){const i=indexOf(id);if(!table||i<0||i>=source.recordCount)return null;const s=states[table.state[i]],d=districts[table.district[i]],code=source.featureCodes[table.feature[i]];return {id:'INP-'+i,name:table.names[i],latitude:table.latitude[i],longitude:table.longitude[i],latitudeText:String(table.latitude[i]),longitudeText:String(table.longitude[i]),stateCode:s.code,stateName:s.name,stateKnown:s.known,districtCode:d.code,districtName:d.name,districtKnown:d.known,featureCode:code,featureName:featureLabels[code]||code,population:table.population[i],country:'India',source:'GeoNames',mirrorCommit:source.mirrorCommit};}
function stateIndex(code){const text=String(code??'');return stateByCode.get(text.startsWith('IN.')?text.slice(3):text);}
async function search(query,options={}){
 const needle=normal(query);if(needle.length<3)return [];await ready();await pause();
 const limit=Math.max(1,Math.min(30,Number(options.limit)||30)),stateRequested=options.state!==undefined&&options.state!==null&&options.state!=='*',stateId=stateRequested?stateIndex(options.state):undefined;
 if(stateRequested&&stateId===undefined)return [];
 let districtId=null;if(options.district!==undefined&&options.district!==null&&options.district!=='*'){const text=String(options.district);districtId=districts.findIndex(d=>((stateId===undefined||states[stateId].code===d.state)&&(d.code===text||'IN.'+d.state+'.'+d.code===text)));if(districtId<0)return [];}
 const candidates=[];const tokens=needle.split(' '),indexed=wordPrefix?.get(tokens[0].slice(0,3)),pool=indexed||null,total=pool?.length||source.recordCount;
 function sort(a,b){return a.rank-b.rank||b.population-a.population||a.name.localeCompare(b.name)||a.index-b.index;}
 for(let cursor=0;cursor<total;cursor++){
  const i=pool?pool[cursor]:cursor;if(cursor&&cursor%20000===0)await pause();
  if(stateId!==undefined&&table.state[i]!==stateId||districtId!==null&&table.district[i]!==districtId)continue;
  const name=table.normalized[i];if(!tokens.every(token=>name.includes(token)))continue;
  let rank=name===needle?0:name.startsWith(needle)?1:name.split(' ').some(token=>token.startsWith(needle))?2:3;
  const feature=source.featureCodes[table.feature[i]];if(['PPLQ','PPLH','PPLW'].includes(feature))rank+=4;
  const candidate={index:i,rank,population:table.population[i],name:table.names[i]};
  if(candidates.length<limit){candidates.push(candidate);candidates.sort(sort);}else if(sort(candidate,candidates[candidates.length-1])<0){candidates[candidates.length-1]=candidate;candidates.sort(sort);}
 }
 return candidates.map(x=>record(x.index));
}
function getData(id){return id===undefined?metadata():record(id);}
function dms(degrees){const total=Math.round(Math.abs(degrees)*3600),deg=Math.floor(total/3600),min=Math.floor(total/60)%60,sec=total%60;return (degrees<0?'-':'')+String(deg).padStart(2,'0')+':'+String(min).padStart(2,'0')+':'+String(sec).padStart(2,'0');}
function coordinateSummary(row){return dms(row.latitude)+' N / '+dms(row.longitude)+' E';}
function districtOptions(item){
 const state=item.state.value,select=item.district;select.innerHTML='<option value="*">All districts</option>';
 if(state!=='*'){for(const district of districts.filter(d=>d.state===state&&d.count>0)){const option=document.createElement('option');option.value=district.code;option.textContent=district.name+(district.known?'':' (source code)');select.appendChild(option);}}
 select.disabled=state==='*';
}
async function choose(id,target){
 await ready();const row=record(id);if(!row)throw new Error('Choose a valid place from the India index.');
 const config=typeof target==='string'?fields.get(target)?.config:target;if(!config)throw new Error('A place field is required for selecting an India location.');
 const place=$(config.placeId),lat=$(config.latId),lon=$(config.lonId);if(!place||!lat||!lon)throw new Error('The selected chart location fields are not available.');
 const name=[row.name,row.districtKnown?row.districtName:'',row.stateKnown?row.stateName:'','India'].filter(Boolean).join(', ');
 place.value=place.maxLength>0?name.slice(0,place.maxLength):name;lat.value=config.format==='dms'?dms(row.latitude):row.latitudeText;lon.value=config.format==='dms'?dms(row.longitude):row.longitudeText;
 const offset=config.offsetId?$(config.offsetId):null;if(offset)offset.value=config.offsetUnit==='minutes'?'330':'5.5';
 const item=fields.get(config.placeId);if(item){item.sequence++;item.results.replaceChildren();item.results.hidden=true;item.state.value=row.stateCode;districtOptions(item);item.district.value=row.districtCode;item.status.textContent=row.name+' · '+row.stateName+' · '+row.districtName+' · '+coordinateSummary(row)+' · '+row.featureName;item.status.dataset.state='selected';item.selectedId=row.id;}
 for(const element of [place,lat,lon,offset].filter(Boolean)){element.dispatchEvent(new Event('input',{bubbles:true}));element.dispatchEvent(new Event('change',{bubbles:true}));}
 // Own change events may queue a new search; retain the selected summary.
 if(item){clearTimeout(item.timer);item.sequence++;item.results.replaceChildren();item.results.hidden=true;item.status.textContent=row.name+' · '+row.stateName+' · '+row.districtName+' · '+coordinateSummary(row)+' · '+row.featureName;item.status.dataset.state='selected';}
 document.dispatchEvent(new CustomEvent('kp-india-place-selected',{detail:{...row,placeId:config.placeId}}));return {...row,formattedPlace:place.value};
}
function attach(config){
 if(!config||!config.placeId||fields.has(config.placeId))return fields.get(config?.placeId)||null;
 const place=$(config.placeId),lat=$(config.latId),lon=$(config.lonId);if(!place||!lat||!lon)return null;
 const panel=document.createElement('div');panel.className='kp-india-picker no-print';panel.dataset.placeFor=config.placeId;
 const suffix=config.placeId.replace(/[^a-zA-Z0-9_-]/g,'-');
 panel.innerHTML='<div class="kp-india-picker-head"><span class="kp-india-picker-title">India · city / town / village lookup</span><span class="kp-india-picker-count">557,995 places · 36 states / UTs</span><button class="kp-india-picker-toggle" type="button" aria-expanded="true" aria-label="Hide India place lookup" title="Hide / show place lookup">▾</button></div><div class="kp-india-picker-filters"><label for="india-'+suffix+'-state">State / Union Territory<select data-calculation-locked="true" id="india-'+suffix+'-state"><option value="*">All states / Union Territories</option></select></label><label for="india-'+suffix+'-district">District<select data-calculation-locked="true" id="india-'+suffix+'-district" disabled><option value="*">All districts</option></select></label></div><p class="kp-india-picker-status" role="status" aria-live="polite">Type at least 3 letters in the place field above. Select a result to fill latitude, longitude and India UTC +05:30. Manual entry remains available.</p><button class="kp-india-picker-google" type="button">Search Google for village DMS</button><div class="kp-india-picker-results" hidden aria-label="Matching India places"></div><div class="kp-india-picker-source">Location data © <a href="https://www.geonames.org/" target="_blank" rel="noopener noreferrer">GeoNames</a> · <a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noopener noreferrer">CC BY 4.0</a> · offline index.<details><summary>Coverage and source</summary><p>'+esc(source.coverage)+' ASCII source names are searchable; alternate names are not included in this mirror. Administrative labels retain source codes where a district or state is missing.</p><p>36 mapped states / UTs, 761 represented district mappings. '+source.unknownStateRecords+' records have an unmapped state; '+source.missingDistrictRecords+' omit districts and '+source.unmappedDistrictRecords+' use unmapped district codes. Abandoned and historical places are marked.</p><p><a href="'+esc(source.pinnedDataURL)+'" target="_blank" rel="noopener noreferrer">Pinned GeoNames mirror</a> · archive 28 August 2026. The original GeoNames retrieval date is not supplied by the mirror.</p><dl><dt>Mirror commit</dt><dd><code>'+esc(source.mirrorCommit)+'</code></dd><dt>Mirror source TSV SHA-256</dt><dd><code>'+esc(source.sourceTSVSHA256)+'</code></dd><dt>Embedded gzip SHA-256</dt><dd><code>'+esc(source.embeddedSHA256)+'</code></dd></dl></details></div>';
 const toggle=panel.querySelector('.kp-india-picker-toggle');toggle.addEventListener('click',()=>{const collapsed=panel.dataset.collapsed!=='true';panel.dataset.collapsed=String(collapsed);toggle.setAttribute('aria-expanded',String(!collapsed));toggle.setAttribute('aria-label',collapsed?'Show India place lookup':'Hide India place lookup');});
 let wrapper=place.closest('label');if(!wrapper||!wrapper.contains(place))wrapper=place.parentElement;wrapper.after(panel);
 const item={config:{...config,format:config.format||'decimal'},panel,place,state:panel.querySelector('select'),district:panel.querySelectorAll('select')[1],status:panel.querySelector('.kp-india-picker-status'),results:panel.querySelector('.kp-india-picker-results'),sequence:0,timer:null,busy:false,selectedId:null};
 for(const state of states){const option=document.createElement('option');option.value=state.code;option.textContent=state.name+' · '+state.count.toLocaleString('en-IN');item.state.appendChild(option);}
 fields.set(config.placeId,item);
 panel.querySelector('.kp-india-picker-google').addEventListener('click',()=>{const village=place.value.trim();if(!village){place.focus();item.status.textContent='Type the village or place name first, then use Google DMS search.';item.status.dataset.state='error';return;}const state=item.state.value==='*'?'':item.state.selectedOptions[0]?.textContent.replace(/\s*·.*$/,'')||'',district=item.district.value==='*'?'':item.district.selectedOptions[0]?.textContent||'',query=[village,district,state,'India latitude longitude DMS degrees minutes seconds'].filter(Boolean).join(' ');window.open('https://www.google.com/search?q='+encodeURIComponent(query),'_blank','noopener,noreferrer');});
 const run=async()=>{
  const query=place.value,token=++item.sequence;item.results.replaceChildren();item.results.hidden=true;
  if(normal(query).length<3){item.status.textContent='Type at least 3 letters in the place field above to search India. You can also enter a place and coordinates manually.';item.status.dataset.state='idle';return;}
  item.busy=true;item.status.textContent=table?'Searching the offline India index…':'Opening the offline India index…';item.status.dataset.state='loading';
  try{
   const matches=await search(query,{state:item.state.value,district:item.district.value,limit:30});if(token!==item.sequence)return;
   item.busy=false;item.status.textContent=matches.length?matches.length+' matches shown · select a place to fill its coordinates. Narrow the state or district for repeated names.':'No matching place in the selected filters. Try a source spelling or another state / district, or enter coordinates manually.';item.status.dataset.state=matches.length?'ready':'empty';
   for(const row of matches){const button=document.createElement('button');button.type='button';button.className='kp-india-picker-result';button.dataset.placeId=row.id;button.dataset.obsolete=String(['PPLQ','PPLH','PPLW'].includes(row.featureCode));button.innerHTML='<strong>'+esc(row.name)+'</strong><small>'+esc(row.stateName)+' · '+esc(row.districtName)+' · '+esc(row.featureName)+'</small><small>'+esc(coordinateSummary(row))+'</small>';button.addEventListener('click',()=>choose(row.id,item.config).catch(error=>{item.status.textContent=error.message;item.status.dataset.state='error';}));item.results.appendChild(button);}
   item.results.hidden=!matches.length;
  }catch(error){if(token!==item.sequence)return;item.busy=false;item.status.textContent=error.message||String(error);item.status.dataset.state='error';}
 };
 const schedule=()=>{item.sequence++;item.selectedId=null;clearTimeout(item.timer);item.timer=setTimeout(run,200);};
 place.addEventListener('input',schedule);place.addEventListener('focus',()=>{ready().catch(error=>{item.status.textContent=error.message;item.status.dataset.state='error';});});
 item.state.addEventListener('change',()=>{districtOptions(item);schedule();});item.district.addEventListener('change',schedule);
 return item;
}
function scan(){
 attach({placeId:'birthPlace',latId:'lat',lonId:'lon',format:'dms',offsetId:'birth-utc-offset'});
 for(const [prefix,offset] of [['tc','timezone'],['tp','timezone'],['na','timezone']])attach({placeId:prefix+'-place',latId:prefix+'-latitude',lonId:prefix+'-longitude',format:'decimal',offsetId:prefix+'-'+offset});
 for(const kind of ['boy','girl'])attach({placeId:'mm-'+kind+'-place',latId:'mm-'+kind+'-latitude',lonId:'mm-'+kind+'-longitude',format:'decimal',offsetId:'mm-'+kind+'-timezone'});
 if($('rpw-latitude')&&!$('rpw-place')){const label=document.createElement('label');label.className='kp-india-place-added';label.htmlFor='rpw-place';label.append('Query place');const input=document.createElement('input');input.id='rpw-place';input.type='text';input.maxLength=160;input.placeholder='Search an India city, town or village';label.appendChild(input);const latitude=$('rpw-latitude');(latitude.closest('label')||latitude.parentElement).before(label);}
}
function mount(){scan();const warm=()=>ready().catch(()=>{});if('requestIdleCallback'in window)requestIdleCallback(warm,{timeout:2500});else setTimeout(warm,1200);const root=document.querySelector('main')||document.body;let queued=false;observer=new MutationObserver(records=>{if(queued||!records.some(r=>Array.from(r.addedNodes).some(n=>n.nodeType===1&&(n.matches('input[id]')||n.querySelector?.('input[id]')))))return;queued=true;setTimeout(()=>{queued=false;scan();},0);});observer.observe(root,{childList:true,subtree:true});}
window.KPIndiaPlaces=Object.freeze({ready,search,getData,choose,attach,source:()=>JSON.parse(JSON.stringify(source))});
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount);else mount();
})();


