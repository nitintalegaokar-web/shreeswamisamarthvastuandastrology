
(()=>{
 function initialize(){
  const mount=document.querySelector('#home .home-chart-mount');if(!mount)return;
  let fitTimer=0;
  function fit(){fitTimer=0;if(!mount.clientWidth)return;
   for(const lane of mount.querySelectorAll('.v38-lane')){
    if(!lane.dataset.homeBaseScale)lane.dataset.homeBaseScale=lane.style.getPropertyValue('--v38-lane-scale')||'1';
    let scale=Number(lane.dataset.homeBaseScale)||1;
    for(let attempt=0;attempt<28;attempt++){
     lane.style.setProperty('--v38-lane-scale',String(scale));
     const clipped=[...lane.querySelectorAll('.v38-item')].some(item=>{
      const box=item.getBoundingClientRect();return [...item.querySelectorAll('.v38-name,.v38-degree,.v38-lords')].some(label=>{
       const range=document.createRange();range.selectNodeContents(label);const text=range.getBoundingClientRect();
       return text.left<box.left-.25||text.right>box.right+.25||text.top<box.top-.25||text.bottom>box.bottom+.25;
      });
     });
     if(!clipped)break;scale*=.9;
    }
   }
  }
  // Chart rendering produces a burst of mutations. Measure once after it settles
  // instead of forcing layout again for every intermediate DOM update.
  function schedule(){clearTimeout(fitTimer);fitTimer=setTimeout(fit,80);}
  new MutationObserver(schedule).observe(mount,{childList:true,subtree:true});new ResizeObserver(schedule).observe(mount);
  window.addEventListener('resize',schedule);document.addEventListener('change',schedule);schedule();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialize);else initialize();
})();

