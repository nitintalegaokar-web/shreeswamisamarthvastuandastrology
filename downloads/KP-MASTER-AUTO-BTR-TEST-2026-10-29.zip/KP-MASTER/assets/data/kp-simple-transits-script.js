(()=>{'use strict';const $=id=>document.getElementById(id),events=[...KPHandbook.getCatalogue().events.map(e=>({...e,transitCatalogue:'handbook'})),...KPPrediction.getCatalogue().events.map(e=>({...e,id:'prediction:'+e.id,transitCatalogue:'prediction',relevantHouses:e.supportingHouses||[...new Set(e.supportingGroups.flat())]}))],byId=new Map(events.map(e=>[String(e.id),e]));
function eventLabel(event){return KPPreferences.get().language==='marathi'?(event.event.mr||KPLanguage.translate(event.event.en||'')):(event.event.en||event.event.mr);}
function selection(){const event=byId.get($('tr-event').value);if(!event)throw Error('Select an event.');return event;}
function eventOptions(){const selected=$('tr-event').value,cusp=Number($('tr-main-cusp')?.value)||0,available=events.filter(e=>!cusp||e.mainHouses?.includes(cusp));const select=$('tr-event');select.replaceChildren();for(const [name,source] of [['KP Handbook','handbook'],['Prediction catalogue','prediction']]){const group=document.createElement('optgroup');group.label=KPLanguage.translate(name);for(const event of available.filter(e=>e.transitCatalogue===source)){const option=new Option(eventLabel(event),String(event.id));option.dataset.noLocalize='true';group.append(option);}select.append(group);}if(available.some(e=>String(e.id)===selected))select.value=selected;else if(available.length)select.value=String((available.find(e=>e.automaticEligible)||available[0]).id);}
function restoreSelection(data){const cusp=$('tr-main-cusp'),saved=data?.fields||{};if(saved['tr-main-cusp']&&[...cusp.options].some(o=>o.value===saved['tr-main-cusp'].value))cusp.value=saved['tr-main-cusp'].value;else cusp.value='all';eventOptions();const id=saved['tr-event']?.value;if(id&&[...$('tr-event').options].some(o=>o.value===id))$('tr-event').value=id;apply();}
function view(){const mode=$('tr-mode').value;$('tr-simple-event-choice').hidden=false;$('tr-simple-cusp-choice').hidden=false;if($('tr-event-search-scope'))$('tr-event-search-scope').parentElement.hidden=mode!=='event';$('tr-simple-rule-note').textContent=mode==='event'?($('tr-event-search-scope')?.value==='supported'?'Event significators · transit matches within supporting natal promise and DBA windows':'Transit intervals for the selected event houses and dates. These are transit conditions, not a confirmed event prediction.'):mode==='dasha'?'MD / AD / PD through each other · six directions, Rashi / star / sub':'Sun through MD and AD · MD Rashi + AD star, or AD Rashi + MD star';}
function apply(){const event=selection();$('tr-houses').value=(event.relevantHouses||event.supportingGroups?.[0]||[]).join(',');view();KPTransit.refresh();}
function criteria(data){
 if($('tr-mode').value!=='event')return null;
 if($('tr-event-search-scope')?.value==='transits')return null;
 const event=selection();if(!event.automaticEligible||!event.mainHouses?.length||!event.supportingGroups?.length)throw Error('This event requires review of its source conditions before automatic transit dates can be calculated.');const method=$('tr-significator-method').value,analysis=KPEventPromise.analyze(currentKPModel,{event,cusp:Number($('tr-main-cusp').value)||event.mainHouses[0],method,layers:['CSL','STL','SBL'],inputMode:'automatic'}),verdict=KPEventOutcome.assess(analysis);
 if(!verdict.promised)throw Error('Event is not supported by the natal CSL chain. '+verdict.reason);
 if(verdict.qualified)throw Error('This event needs additional rule review before searching.');
 const explicit=String(event.timingRaw||'').trim(),required=/^(?:1[0-2]|[1-9])(?:\s*,\s*(?:1[0-2]|[1-9]))*$/.test(explicit)?explicit.split(',').map(Number):analysis.proofs.find(p=>!p.missing.length)?.required;
 const range=KPTransit.currentRange(data),periods=window.KPTransitSelection?.filterPeriods(KPEventOutcome.periodMatches(currentKPModel,{method},range,required),data)||KPEventOutcome.periodMatches(currentKPModel,{method},range,required);
 if(!periods.length)throw Error('No MD / AD / PD period supports houses '+required.join(', ')+' in the selected dates / DBA.');
 return {periods,required,event:eventLabel(event)};
}
function init(){
 const card=$('transit').querySelector('.tr-card'),storage=document.createElement('div');storage.hidden=true;storage.id='tr-calculation-fields';
 const heading=card.querySelector('h2'),actions=card.querySelector('.tr-actions'),current=$('tr-current-periods'),eventPanel=$('tr-event-panel'),dashaPanel=$('tr-dasha-panel');
 const header=document.createElement('header');header.className='tr-compact-header';card.prepend(header);header.append(heading);const preview=$('transit-preview');if(preview)header.append(preview);
 const choices=document.createElement('div');choices.className='tr-simple-choice';choices.innerHTML='<label>Search<div id="tr-simple-mode-choice"></div></label><label id="tr-simple-event-choice">Event</label>';
 header.after(choices);$('tr-simple-mode-choice').append($('tr-mode'));storage.append($('tr-period'));$('tr-simple-event-choice').append($('tr-event'));
 const cuspLabel=document.createElement('label');cuspLabel.id='tr-simple-cusp-choice';cuspLabel.append(document.createTextNode('Cusp'));const cuspSelect=document.createElement('select');cuspSelect.id='tr-main-cusp';cuspSelect.append(new Option('All','all'));for(const [i,roman] of ['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'].entries()){const option=new Option(roman,String(i+1));option.dataset.noLocalize='true';cuspSelect.append(option);}cuspLabel.append(cuspSelect);$('tr-simple-event-choice').before(cuspLabel);cuspSelect.addEventListener('change',()=>{eventOptions();KPTransit.cancel();apply();});
 const note=document.createElement('p');note.id='tr-simple-rule-note';choices.after(current,$('tr-period-summary'),actions,note);
 const feedback=$('tr-status'),resultTable=card.querySelector('.tr-result-mount');note.after(feedback,resultTable);
 const options=document.createElement('details');options.id='tr-rule-options';options.className='no-print';options.innerHTML='<summary>Transit rules and details</summary><div class="tr-compact-options"></div>';resultTable.after(options);options.lastChild.append(eventPanel,dashaPanel,card.querySelector('.tr-model-note'));
 const scope=document.createElement('label');scope.id='tr-search-scope';scope.innerHTML='Event search<select id="tr-event-search-scope"><option value="transits">Transit intervals</option><option value="supported">Natal promise + DBA support</option></select>';choices.after(scope);scope.lastChild.addEventListener('change',()=>{view();KPTransit.cancel();KPTransit.refresh();});
 for(const id of ['tr-houses','tr-significator-method','tr-match'])$(id).parentElement.classList.add('tr-event-option');
 const timezone=document.createElement('label');timezone.textContent='Date / time zone';timezone.append($('tr-timezone'));options.lastChild.prepend(timezone);
 // Native period lords are automatic. Keep the existing controls for saved chart compatibility.
 dashaPanel.querySelector('.tr-role-grid').hidden=true;$('tr-dasha-source').parentElement.hidden=true;
 for(const node of [...card.children])if(!node.matches('.tr-compact-header,.tr-simple-choice,#tr-search-scope,#tr-current-periods,#tr-period-summary,.tr-actions,#tr-simple-rule-note,#tr-rule-options,#tr-status,.tr-result-mount'))storage.append(node);
 card.append(storage);
 const select=$('tr-event');eventOptions();window.addEventListener('kp-preferences-changed',eventOptions);
 const marriage=events.find(e=>/^marriage$/i.test(e.event.en||''))||events.find(e=>/marriage/i.test(e.event.en||''));if(marriage)select.value=String(marriage.id);
 $('tr-mode').value='event';$('tr-significator-method').value='fourfold';$('tr-match').value='star-sub';$('tr-dasha-source').value='auto';$('tr-zone').value='natal';
 const offset=KPHomeDasha.getData().timeZoneHours,minutes=String(offset*60);if(![...$('tr-timezone').options].some(o=>o.value===minutes))$('tr-timezone').append(new Option('Native time · UTC'+(offset>=0?'+':'')+offset,minutes));$('tr-timezone').value=minutes;
 for(const input of $('tr-planet-options').querySelectorAll('input'))input.checked=true;
 select.addEventListener('change',apply);$('tr-mode').addEventListener('change',view);$('tr-run').textContent='Find dates';heading.textContent='Find event transit dates · गोचर';apply();
}
window.KPSimpleTransits=Object.freeze({criteria,apply,restoreSelection,getEvents:()=>JSON.parse(JSON.stringify(events))});if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(init,0));else init();
})();

