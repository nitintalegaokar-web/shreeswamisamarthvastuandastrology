window.KPHandbook=Object.freeze({getCatalogue:()=>JSON.parse(document.getElementById("kp-handbook-catalogue").textContent)});
