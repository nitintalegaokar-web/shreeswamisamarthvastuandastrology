/* User-supplied childbirth notes, evaluated as traditional rule conditions only. */
(function(root){'use strict';
const names={Su:['Sun','रवी'],Mo:['Moon','चंद्र'],Ma:['Mars','मंगळ'],Me:['Mercury','बुध'],Ju:['Jupiter','गुरु'],Ve:['Venus','शुक्र'],Sa:['Saturn','शनि'],Ra:['Rahu','राहू'],Ke:['Ketu','केतू']};
const rules=[
 {id:'both-barren',b:[true,true],groups:[[1,4,10],[6,8,12],[2,5,11]],en:'The supplied table associates this combination with adoption or surrogacy; this does not determine fertility.',mr:'दिलेल्या तक्त्यात या संयोगाचा संबंध दत्तक किंवा सरोगसीशी जोडला आहे; यावरून प्रजननक्षमता ठरत नाही.'},
 {id:'star-barren',b:[false,true],groups:[[2,5,11,4,8,10],[2,5,11,6,8,12]],en:'The supplied table mentions treatment / IVF. A medical assessment is required; the chart cannot establish a need for IVF.',mr:'दिलेल्या तक्त्यात उपचार किंवा कृत्रिम गर्भधारणेचा उल्लेख आहे. त्याची गरज वैद्यकीय तपासणीनेच ठरते.'},
 {id:'csl-barren',b:[true,false],groups:[[2,5,11],[4,6,8,12]],en:'The supplied table mentions treatment. It also gives an overlapping adoption / pregnancy-loss interpretation for this same combination, so no single outcome is selected.',mr:'दिलेल्या तक्त्यात उपचाराचा उल्लेख आहे. याच संयोगासाठी दत्तक किंवा गर्भहानीचा वेगळा अर्थही दिला असल्याने एकच निष्कर्ष निवडलेला नाही.'},
 {id:'both-mars',pair:['Ma','Ma'],en:'Both lords are Mars. The supplied adverse child-survival statement cannot establish a medical outcome.',mr:'दोन्ही स्वामी मंगळ आहेत. दिलेल्या प्रतिकूल बालजीवनविषयक विधानावरून वैद्यकीय निष्कर्ष ठरत नाही.'},
 {id:'ketu',ketu:true,en:'A Ketu connection is present. The supplied one-child statement is retained as a traditional reference; it cannot determine family size.',mr:'केतूचा संबंध आहे. दिलेले एक-संततीविषयक विधान पारंपरिक संदर्भ आहे; यावरून कुटुंबातील मुलांची संख्या ठरत नाही.'},
 {id:'mars-negative',star:'Ma',groups:[[1,4,10]],en:'Mars star lord with adverse-house support: the supplied notes mention complications. No surgery, loss, survival or percentage is predicted.',mr:'मंगळ नक्षत्रस्वामी व प्रतिकूल भावांचा संबंध: दिलेल्या नोंदीत अडचणींचा उल्लेख आहे. शस्त्रक्रिया, गर्भहानी, बालजीवन किंवा टक्केवारीचे भाकीत केलेले नाही.'}
];
function degreeSignal(planet){
 if(!planet||!Number.isFinite(planet.longitude))return null;
 const total=((planet.longitude%1296000)+1296000)%1296000,sign=Math.floor(total/108000),degree=(total%108000)/3600,node=['Ra','Ke'].includes(planet.id),shift=node?(degree<10?-1:0):(degree>=20?1:0),effectiveSign=(sign+shift+12)%12;
 return {planet:planet.id,degree,sign,effectiveSign,shift,result:effectiveSign%2===0?'male':'female',convention:'supplied-degree-sign',medicalDetermination:false};
}
function analyze(model,cusp=5){
 if(!model?.ready)return {ready:false,rows:[],reason:'Complete the natal chart to see predictions.'};
 const c=model.houses?.find(h=>h.id===Number(cusp)),lord=model.planets?.find(p=>p.id===c?.sl),star=model.planets?.find(p=>p.id===lord?.stl);
 if(!lord||!star||![lord,star].every(p=>Number.isInteger(p.signIndex)&&p.signIndex>=0&&p.signIndex<12)||![5,7,9].includes(Number(cusp)))return {ready:false,rows:[],reason:'The selected child cusp and its lords are required.'};
 const lang=root.KPPreferences?.get?.().language||'english',mr=lang==='marathi',bi=lang==='bilingual',say=(en,ma)=>bi?en+'\n'+ma:mr?ma:en;
 const rows=[],add=(id,en,ma)=>rows.push({id:'childbirth-'+id,language:mr?'marathi':'english',title:say('Traditional childbirth interpretation','पारंपरिक संतती फलविचार'),text:say(en,ma),status:'review'});
 const housesFor=id=>{const r=model.fourfold?.planets?.find(p=>p.id===id);return [...new Set(['A','B','C','D'].flatMap(k=>r?.[k]||[]))];};
 const houses=[...new Set([...housesFor(lord.id),...housesFor(star.id)])],barren=p=>[0,2,4,5].includes(p.signIndex),matched=[];
 const positive=[2,5,11].filter(h=>houses.includes(h)),negative=[1,4,10].filter(h=>houses.includes(h));
 add('house-support','Positive houses (2, 5, 11): '+(positive.join(', ')||'none')+'. Negative houses (1, 4, 10): '+(negative.join(', ')||'none')+'. '+(negative.length&&!positive.length?'Only negative-house support is present. Your rule associates this with sterility / no child; this is not a diagnosis of infertility.':positive.length&&negative.length?'Both positive and negative support are present; do not treat the result as a definite yes or no.':positive.length?'Positive childbirth-house support is present; pregnancy is not medically confirmed.':'Neither group has support; no conclusion.'),'अनुकूल भाव (२, ५, ११): '+(positive.join(', ')||'नाही')+'. प्रतिकूल भाव (१, ४, १०): '+(negative.join(', ')||'नाही')+'. '+(negative.length&&!positive.length?'केवळ प्रतिकूल भावांचा संबंध आहे. आपल्या नियमानुसार हा वंध्यत्व किंवा संतती नसण्याचा पारंपरिक संकेत आहे; हे वंध्यत्वाचे वैद्यकीय निदान नाही.':positive.length&&negative.length?'अनुकूल व प्रतिकूल दोन्ही संबंध असल्याने निश्चित होकार किंवा नकार दिलेला नाही.':positive.length?'संततीविषयक अनुकूल भावांचा संबंध आहे; यावरून गर्भधारणा वैद्यकीयदृष्ट्या निश्चित होत नाही.':'दोन्ही गटांचा संबंध नसल्याने निष्कर्ष नाही.'));
 for(const r of rules){if(r.b&&(barren(lord)!==r.b[0]||barren(star)!==r.b[1]))continue;if(r.pair&&(lord.id!==r.pair[0]||star.id!==r.pair[1]))continue;if(r.ketu&&lord.id!=='Ke'&&star.id!=='Ke')continue;if(r.star&&star.id!==r.star)continue;if(r.groups&&!r.groups.some(g=>g.every(h=>houses.includes(h))))continue;matched.push(r.id);add(r.id,r.en,r.mr);}
 if(!matched.length)add('no-match','No unambiguous condition in the supplied childbirth table fully matches this selection.','दिलेल्या संतती तक्त्यातील स्पष्ट अट या निवडीशी पूर्ण जुळत नाही.');
 const horary=root.document?.getElementById('chart-kind')?.value==='horary'||root.document?.getElementById('instant-prashna')?.value==='1';
 if(horary){const group=['Ke','Mo','Su','Ju'].includes(lord.id)?0:['Me','Ve'].includes(lord.id)?1:2;add('delivery',['Horary delivery reference: on-time category.','Horary delivery reference: premature category.','Horary delivery reference: delayed category.'][group]+' This is not an estimated medical delivery date.',['प्रश्नकुंडलीतील प्रसूती संदर्भ: वेळेवर गट.','प्रश्नकुंडलीतील प्रसूती संदर्भ: मुदतपूर्व गट.','प्रश्नकुंडलीतील प्रसूती संदर्भ: विलंब गट.'][group]+' हा वैद्यकीय प्रसूतीदिनाचा अंदाज नाही.');}
 const degree=degreeSignal(lord);
 if(degree)add('degree-sign','Supplied sign-and-degree convention: '+(degree.result==='male'?'male':'female')+' indication. This does not reliably determine a baby’s sex.','दिलेल्या राशी-अंश परंपरेनुसार '+(degree.result==='male'?'पुरुष':'स्त्री')+' संततीचा संकेत. यावरून बाळाचे लिंग विश्वसनीयरीत्या ठरत नाही.');
 if(horary){const moon=model.planets.find(p=>p.id==='Mo');if(Number.isInteger(moon?.occ)){const count=(moon.occ-5+12)%12;add('moon-counter','Traditional fifth-house Moon offset: '+count+'. This is a symbolic house count, not gestational age or pregnancy confirmation.','पंचम भावापासून चंद्राचे पारंपरिक भावांतर: '+count+'. ही सांकेतिक भावगणना आहे; गर्भावधी किंवा गर्भधारणा निश्चित करणारी तपासणी नाही.');}}
 if([2,8,11].includes(lord.signIndex)&&star.signIndex===lord.signIndex)add('twins-review','Both lords occupy a sign listed in the supplied twin table. Its planet-specific statements overlap or remain undefined; twins, their sex and survival are not confirmed.','दोन्ही स्वामी दिलेल्या जुळ्या संततीच्या तक्त्यातील एकाच राशीत आहेत. ग्रहविशिष्ट विधानांत संदिग्धता किंवा आच्छादन असल्याने जुळी संतती, लिंग किंवा बालजीवन निश्चित केलेले नाही.');
 return {ready:true,rows,cusp:Number(cusp),degreeSignal:degree,matched,houseSystem:'existing-kp-fourfold',houses,positive,negative,lord:lord.id,star:star.id};
}
root.KPChildbirth=Object.freeze({analyze,rules,degreeSignal});if(typeof module!=='undefined'&&module.exports)module.exports=root.KPChildbirth;
})(typeof window==='undefined'?globalThis:window);

