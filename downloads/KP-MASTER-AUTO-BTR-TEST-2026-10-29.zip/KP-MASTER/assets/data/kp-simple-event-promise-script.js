(()=>{'use strict';
const $=id=>document.getElementById(id),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const roles=[['CSL','Cusp sub lord'],['STL','Star lord of CSL'],['SBL','Sub lord of CSL'],['STL_STL','Star lord of STL'],['SBL_STL','Star lord of SBL'],['SBL_SBL','Sub lord of SBL']];
const colours={favorable:[1,3,5,9,11],neutral:[2,6,10],opposed:[4,7,8,12]};
function houses(values,groups=colours){return (values||[]).map(h=>'<span class="ep-number" data-house="'+h+'" data-tone="'+(Object.keys(groups).find(k=>groups[k].includes(h))||'unclassified')+'">'+h+'</span>').join(' ')||'<span class="ep-empty">—</span>';}
function content(data){
 if(!data?.ready)return '<article data-event-verdict="incomplete"><h3>Result: Chart incomplete</h3><p>'+esc(data?.reason||'Complete the native kundali.')+'</p></article>';
 const v=KPEventOutcome.assess(data),review=v.promised&&v.qualified;
 const result=v.pending?'Conditions require review':review?'Event is Promised · provisional support':v.promised?'Event is Promised':'Event is not Promised';
 return '<article data-event-verdict="'+(review?'review':v.promised?'promised':'not-promised')+'"><h3>Result: '+result+'</h3><p class="ep-event-name"><strong>'+esc(data.rule.label)+'</strong><span> · Main cusp '+data.cusp+'</span></p><p class="ep-why"><strong>Why?</strong> '+esc(v.reason)+'</p>'+(review?'<p class="ep-condition">'+esc(data.rule.remarks||'The supplied rule includes conditions beyond the house group that cannot be decided automatically.')+'</p>':'')+'<div class="ep-required"><strong>Required houses:</strong><div>'+((data.rule.groups||[]).map(g=>'<span class="ep-alternative">'+houses(g,data.categories)+'</span>').join('<span class="ep-or">OR</span>')||'No numeric group supplied')+'</div></div><div class="ep-match-summary"><div><strong>Matched:</strong><span>'+houses(data.best?.matched,data.categories)+'</span></div><div><strong>Missing:</strong><span>'+(data.best?.missing.length?houses(data.best.missing,data.categories):'None')+'</span></div></div></article>';
}
function rule(){return KPHandbook.getCatalogue().events.find(e=>String(e.id)===$('ep-event')?.value);}
function syncMainCusp(){const event=rule();if($('ep-auto-cusp')?.checked&&event?.mainHouses?.length)$('ep-cusp').value=String(event.mainHouses[0]);}
function seedManual(){const d=KPEventPromise.analyze(window.currentKPModel,{cusp:Number($('ep-cusp').value),event:rule(),method:$('ep-method').value,inputMode:'automatic',layers:roles.filter(([role])=>$('ep-layer-'+role).checked).map(([role])=>role),strongest:$('ep-strongest').checked});for(const layer of d.layers||[])$('ep-houses-'+layer.role).value=layer.houses.join(',');}
function render(data){
 const panel=document.querySelector('.ep-simple-card');if(!panel)return;
 const manual=$('ep-input-mode').value==='manual';panel.dataset.inputMode=manual?'manual':'automatic';
 for(const [mode,id] of [['automatic','ep-mode-auto'],['manual','ep-mode-manual']])$(id).setAttribute('aria-pressed',String($('ep-input-mode').value===mode));
 for(const [role] of roles){const layer=data?.layers?.find(l=>l.role===role);$('ep-compact-lord-'+role).textContent=layer?.id||'—';$('ep-compact-houses-'+role).innerHTML=houses(layer?.houses,data?.categories);$('ep-houses-'+role).readOnly=!manual;}
 for(const key of Object.keys(colours))$('ep-group-'+key).innerHTML=houses(data?.categories?.[key]||colours[key],data?.categories);
 $('ep-simple-result').innerHTML=content(data);$('ep-compact-combined').innerHTML=houses(data?.ready?data.houses:[],data?.categories);
 $('ep-input-note').textContent=manual?'Manual house input':'Calculated from native kundali';$('ep-simple-preview').disabled=!data?.ready;
 const model=window.currentKPModel,cusp=data?.ready?model?.houses?.find(h=>h.id===data.cusp):null,csl=cusp?model.planets.find(p=>p.id===cusp.sl):null;
 $('ep-cusp-occupants').textContent=cusp?(cusp.occ.join(', ')||'Empty house'):'—';$('ep-csl-star-tenants').textContent=csl?(model.planets.filter(p=>p.stl===csl.id).map(p=>p.id).join(', ')||'None'):'—';$('ep-cusp-aspects').textContent=cusp?(cusp.aspd.join(', ')||'None'):'—';$('ep-csl-aspects').textContent=csl?(csl.aspd.join(', ')||'None'):'—';
}
function refresh(){syncMainCusp();const data=KPEventPromise.refresh(true);render(data);return data;}
function snapshot(){const data=refresh(),groups=data?.categories||colours;return '<div class="ep-simple-report"><h2>Event Promise · CSL analysis</h2><p data-no-localize>'+esc($('name')?.value)+' · '+esc($('dob')?.value)+' · '+esc($('birthTime')?.value)+'</p><p><strong>'+(data?.inputMode==='manual'?'Manual house input':'Calculated from native kundali')+'</strong> · '+esc(data?.method||'fourfold')+'</p>'+content(data)+(data?.ready?'<h3>Cusp significators</h3><table><thead><tr><th>CSL chain</th><th>Planet</th><th>Signified houses</th></tr></thead><tbody>'+data.layers.filter(l=>l.selected).map(l=>'<tr><td>'+esc(l.label)+' · '+esc(l.role)+'</td><td>'+esc(l.id)+'</td><td>'+houses(l.houses,groups)+'</td></tr>').join('')+'</tbody></table><p class="ep-report-combined"><strong>Combined Significators:</strong> '+houses(data.houses,groups)+'</p><div class="ep-report-legend">'+Object.entries(groups).map(([key,values])=>'<span><strong>'+({favorable:'Favorable houses',neutral:'Neutral houses',opposed:'Opposed houses'}[key])+':</strong> '+houses(values,groups)+'</span>').join(' ')+'</div>':'')+'</div>';}
function row(role,label){const node=document.createElement('div');node.className='ep-compact-layer';node.dataset.epCompactRole=role;node.innerHTML='<label class="ep-compact-label" for="ep-layer-'+role+'"><span>'+esc(label)+'</span></label><strong id="ep-compact-lord-'+role+'" class="ep-compact-planet"></strong><div class="ep-compact-values"><div id="ep-compact-houses-'+role+'" class="ep-auto-houses"></div></div>';node.querySelector('label').prepend($('ep-layer-'+role));node.querySelector('.ep-compact-values').append($('ep-houses-'+role));return node;}
function init(){
 const section=$('event-promise'),hidden=document.createElement('div');hidden.hidden=true;hidden.id='ep-calculation-fields';while(section.firstChild)hidden.append(section.firstChild);
 const panel=document.createElement('article');panel.className='kp-feature-card ep-simple-card';panel.innerHTML='<header class="ep-compact-header"><h2>Event Promise · CSL analysis</h2><button id="ep-simple-preview" type="button">Preview · Print / PDF</button></header><div class="ep-compact-grid"><div class="ep-compact-left"><div class="ep-group-strip"><label class="ep-cusp-choice">Cusp<span id="ep-compact-cusp"></span></label><div><span>Favorable houses</span><div id="ep-group-favorable"></div></div><div><span>Neutral houses</span><div id="ep-group-neutral"></div></div><div><span>Opposed houses</span><div id="ep-group-opposed"></div></div></div><div class="ep-significator-panel"><div class="ep-mode-bar"><div role="group" aria-label="House input mode"><button id="ep-mode-auto" type="button" aria-pressed="true">Auto Mode</button><button id="ep-mode-manual" type="button" aria-pressed="false">Manual Mode</button></div><span id="ep-input-note"></span></div><h3>Cusp significators</h3><div id="ep-compact-primary"></div><details class="ep-more-options"><summary>More chain options</summary><div id="ep-compact-additional"></div><label class="ep-auto-cusp-label" for="ep-auto-cusp">Select event’s main cusp automatically</label></details><div class="ep-combined-line"><strong>Combined Significators</strong><div id="ep-compact-combined"></div></div></div><details class="ep-native-evidence"><summary>Native cusp details</summary><dl><dt>Cusp occupancy</dt><dd id="ep-cusp-occupants"></dd><dt>Planets in CSL’s star</dt><dd id="ep-csl-star-tenants"></dd><dt>Cusp aspected by</dt><dd id="ep-cusp-aspects"></dd><dt>CSL aspected by</dt><dd id="ep-csl-aspects"></dd></dl></details></div><div class="ep-compact-right"><div class="ep-event-controls"><label>Event category<span id="ep-compact-category"></span></label><label>Select an event<span id="ep-simple-choice"></span></label></div><div id="ep-simple-result" role="status" aria-live="polite"></div></div></div>';
 section.append(hidden,panel);$('ep-simple-choice').append($('ep-event'));$('ep-compact-category').append($('ep-category'));$('ep-compact-cusp').append($('ep-cusp'));for(const option of $('ep-cusp').options)option.textContent=option.value;
 $('ep-event').querySelector('[value="custom"]')?.remove();
 roles.forEach(([role,label],i)=>$(i<3?'ep-compact-primary':'ep-compact-additional').append(row(role,label)));panel.querySelector('.ep-auto-cusp-label').prepend($('ep-auto-cusp'));
 function mode(value){if($('ep-input-mode').value===value)return;syncMainCusp();if(value==='manual')seedManual();$('ep-input-mode').value=value;refresh();}
 $('ep-mode-auto').addEventListener('click',()=>mode('automatic'));$('ep-mode-manual').addEventListener('click',()=>mode('manual'));
 panel.addEventListener('change',event=>{const id=event.target.id;
  if(id==='ep-category')KPEventPromise.refresh(true);
  if(id==='ep-cusp')$('ep-auto-cusp').checked=false;
  if(id.startsWith('ep-layer-')&&!roles.some(([role])=>$('ep-layer-'+role).checked))event.target.checked=true;
  syncMainCusp();if(['ep-event','ep-category','ep-cusp'].includes(id)&&$('ep-input-mode').value==='manual')seedManual();refresh();
 });
 $('ep-simple-preview').addEventListener('click',()=>KPReportPreview.open('event-promise'));
 const previous=window.KPEventOutcome;window.KPEventOutcome=Object.freeze({...previous,snapshot});
 const previousPromise=window.KPEventPromise;window.KPEventPromise=Object.freeze({...previousPromise,snapshot});
 new MutationObserver(()=>{if(section.classList.contains('active'))refresh();}).observe(section,{attributes:true,attributeFilter:['class']});
 for(const event of ['chart-saved','chart-manual-change','kp-preferences-changed'])window.addEventListener(event,refresh);
 new MutationObserver(()=>render(KPEventPromise.getData())).observe($('ep-status'),{childList:true});refresh();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(init,0));else init();
})();

