
/* v21 FINAL: जन्मवेळची स्थिती = DOB row EXACT COPY.
   IMPORTANT: no interpolation, no daily-motion calculation, no elapsed-time
   calculation is used for this row. The source is the planetary-position row
   whose selected date exactly equals the birth date. Tabs 1-5 are untouched.
*/
(function(){
  function copyExactBirthDatePosition(){
    if(document.getElementById('chart-kind')?.value==='horary')return;
    const dob=(document.getElementById('dob')?.value||'').trim();
    if(!dob) return;
    const d1=(document.getElementById('p6_row_date_1')?.value||'').trim();
    const d2=(document.getElementById('p6_row_date_2')?.value||'').trim();
    let srcPrefix='';
    if(d1===dob) srcPrefix='p6_d_';
    else if(d2===dob) srcPrefix='p6_t_';
    else return;

    for(let i=0;i<9;i++){
      const src=document.getElementById(srcPrefix+i);
      const dst=document.getElementById('p6_birth_'+i);
      if(src && dst) dst.value=src.value || '';
    }

    const bp=document.getElementById('p6_birth_pos_date');
    if(bp){ bp.value=dob; bp.dataset.auto='0'; }
  }

  window.copyExactBirthDatePosition=copyExactBirthDatePosition;

  // Run after the existing calculation/render routines, so their interpolation
  // can never replace the exact DOB copy.
  function runFinalCopy(){
    copyExactBirthDatePosition();
    setTimeout(copyExactBirthDatePosition,0);
    setTimeout(copyExactBirthDatePosition,50);
  }

  document.addEventListener('DOMContentLoaded',function(){
    ['dob','birthTime','p6_row_date_1','p6_row_date_2'].forEach(id=>{
      const e=document.getElementById(id);
      if(e){
        e.addEventListener('input',runFinalCopy);
        e.addEventListener('change',runFinalCopy);
      }
    });
    for(let i=0;i<9;i++){
      ['p6_d_'+i,'p6_t_'+i].forEach(id=>{
        const e=document.getElementById(id);
        if(e){e.addEventListener('input',runFinalCopy);e.addEventListener('change',runFinalCopy);}
      });
    }
    runFinalCopy();
    setTimeout(runFinalCopy,100);
    setTimeout(runFinalCopy,500);
  });

  // Wrap calculateAll once. Existing calculations remain exactly as they are;
  // only the final display row is corrected after calculation completes.
  function wrap(){
    if(typeof window.calculateAll!=='function' || window.calculateAll.__v21wrapped) return;
    const original=window.calculateAll;
    function wrapped(){
      const result=original.apply(this,arguments);
      runFinalCopy();
      return result;
    }
    wrapped.__v21wrapped=true;
    window.calculateAll=wrapped;
  }
  document.addEventListener('DOMContentLoaded',function(){
    wrap();
    setTimeout(wrap,50);
    setTimeout(wrap,250);
    setTimeout(wrap,600);
  });
})();

