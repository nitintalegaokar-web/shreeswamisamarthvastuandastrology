

document.addEventListener("DOMContentLoaded",()=>{
  ["sampattikBase","lmtFinal","birthTime","stdLon","placeStdLon","lmtDeg","lmtKala"].forEach(id=>{
    const el=document.getElementById(id);
    if(el){
      el.addEventListener("input",()=>{
        if(typeof updateLMTCalculation==="function") updateLMTCalculation();
        if(typeof updateLongitudeDifference==="function") updateLongitudeDifference();
        updateTab4SampattikKaal(); updateSampattikTimeDifferences();
      });
      el.addEventListener("change",()=>{
        if(typeof updateLMTCalculation==="function") updateLMTCalculation();
        if(typeof updateLongitudeDifference==="function") updateLongitudeDifference();
        updateTab4SampattikKaal(); updateSampattikTimeDifferences();
      });
    }
  });
  updateTab4SampattikKaal(); updateSampattikTimeDifferences();
});


