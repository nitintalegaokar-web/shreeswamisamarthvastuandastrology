
/* Tab 6 authoritative calculation: signed angular corrections from the exact
   DOB 05:30 position, with Ketu always derived from Rahu + 180 degrees. */
(function(){
  const FULL=1296000, HALF=648000, RASHI=108000, DAY=86400, FIVE30=19800;
  const names=['रवी','चंद्र','मंगळ','बुध','गुरु','शुक्र','शनि','राहू','केतू'];
  const signs=['मेष','वृषभ','मिथुन','कर्क','सिंह','कन्या','तुला','वृश्चिक','धनु','मकर','कुंभ','मीन'];
  const outputs=['motion','hours','minutes','total','birth','add','ayan','final','rashi'];
  const get=id=>String(document.getElementById(id)?.value||'').trim();
  const set=(id,value)=>{const el=document.getElementById(id);if(el)el.value=value??'';};
  const norm=value=>((value%FULL)+FULL)%FULL;
  function dms(value){
    if(!Number.isFinite(value))return '';
    const rounded=Math.round(Math.abs(value));
    return (value<0&&rounded>0?'-':'')+Math.floor(rounded/3600)+':'+String(Math.floor(rounded%3600/60)).padStart(2,'0')+':'+String(rounded%60).padStart(2,'0');
  }
  const longitude=value=>dms(norm(Math.round(value)));
  function angle(value){
    const match=/^(\d{1,3}):([0-5]?\d):([0-5]?\d)(?:\s+R)?$/i.exec(String(value||'').trim());
    if(!match)return NaN;
    const result=Number(match[1])*3600+Number(match[2])*60+Number(match[3]);
    // The embedded ephemeris uses unwrapped longitudes such as 364:42:00.
    // Normalize those values before taking a signed daily difference.
    return norm(result);
  }
  function birthSeconds(){
    const match=/^(\d{1,2}):([0-5]\d)(?::([0-5]\d))?$/.exec(get('birthTime'));
    if(!match||Number(match[1])>23)return NaN;
    return Number(match[1])*3600+Number(match[2])*60+Number(match[3]||0);
  }
  function calendarDay(value){
    const match=/^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
    if(!match)return NaN;
    const y=Number(match[1]),m=Number(match[2]),d=Number(match[3]);
    const date=new Date(0);date.setUTCFullYear(y,m-1,d);date.setUTCHours(0,0,0,0);
    return date.getUTCFullYear()===y&&date.getUTCMonth()===m-1&&date.getUTCDate()===d?date.getTime()/86400000:NaN;
  }
  function finalPosition(index,position,retro){
    const absolute=norm(Math.round(position)),si=Math.floor(absolute/RASHI);
    set('p6_add_'+index,longitude(absolute));
    set('p6_ayan_'+index,longitude(si*RASHI));
    set('p6_final_'+index,dms(absolute%RASHI)+(retro&&index<7?' R':''));
    set('p6_rashi_'+index,signs[si]);
    const field=document.getElementById('p6_final_'+index);
    if(field)field.dataset.rashi=signs[si];
    return absolute;
  }
  function clear(index){
    outputs.forEach(field=>set('p6_'+field+'_'+index,''));
    const final=document.getElementById('p6_final_'+index);
    if(final)delete final.dataset.rashi;
  }
  function calculate(){
    window.KPWorksheetEphemeris?.preparePositions();
    const bt=birthSeconds(),dob=get('dob');
    const row1=get('p6_row_date_1')||get('p6_date_1'),row2=get('p6_row_date_2')||get('p6_date_2');
    const day1=calendarDay(row1),day2=calendarDay(row2),interval=day2-day1;
    const validDates=Number.isFinite(calendarDay(dob))&&Number.isFinite(interval)&&interval!==0;
    const source=row1===dob?0:row2===dob?1:-1;
    const elapsed=Number.isFinite(bt)?bt-FIVE30:NaN;
    const direction=elapsed<0?-1:1,absoluteElapsed=Math.abs(elapsed);
    const hours=Math.floor(absoluteElapsed/3600),remaining=absoluteElapsed-hours*3600;
    const hoursLabel=document.getElementById('p6-hours-label'),minutesLabel=document.getElementById('p6-minutes-label');
    if(hoursLabel)hoursLabel.textContent=Number.isFinite(elapsed)?`${elapsed<0?'−':''}${hours} तास:`:'तास:';
    if(minutesLabel)minutesLabel.textContent=Number.isFinite(elapsed)?`${elapsed<0?'−':''}${Math.floor(remaining/60)} मिनिटे${remaining%60?' '+remaining%60+' सेकंद':''}:`:'मिनिटे:';
    if(Number.isFinite(bt)){
      const h=Math.floor(bt/3600),m=Math.floor(bt%3600/60),s=bt%60;
      set('planet6BirthTime',String(h%12||12).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0'));
      set('planet6BirthAmPm',h>=12?'PM':'AM');
    }else set('planet6BirthTime','');
    const positions={};
    for(let i=0;i<8;i++){
      const first=angle(get('p6_d_'+i)),second=angle(get('p6_t_'+i));
      if(!Number.isFinite(first)||!Number.isFinite(second)||!validDates||source<0||!Number.isFinite(elapsed)){
        clear(i);continue;
      }
      // Use the shortest signed change across 0 degrees, then normalize to one
      // day. The date controls determine chronology even if rows are swapped.
      let difference=second-first;
      if(difference>HALF)difference-=FULL;
      if(difference<-HALF)difference+=FULL;
      const daily=difference/interval;
      const roundCorrection=value=>Math.sign(value)*Math.round(Math.abs(value));
      const total=roundCorrection(daily*elapsed/DAY);
      const hourCorrection=roundCorrection(daily*direction*hours/24);
      // Round once for the final correction; keep the displayed components
      // additive, including any one-second rounding remainder.
      const minuteCorrection=total-hourCorrection;
      const base=source===0?first:second;
      set('p6_motion_'+i,dms(Math.abs(daily))+(daily<0&&i<7?' R':''));
      set('p6_hours_'+i,dms(hourCorrection));
      set('p6_minutes_'+i,dms(minuteCorrection));
      set('p6_total_'+i,dms(total));
      set('p6_birth_'+i,get((source===0?'p6_d_':'p6_t_')+i));
      positions[names[i]]=finalPosition(i,base+total,daily<0);
    }
    // Hidden legacy index-8 fields remain for old save/worksheet helpers, but
    // none is an independent source: every Ketu value follows Rahu.
    for(const prefix of ['d','t']){
      const rahu=angle(get('p6_'+prefix+'_7'));
      set('p6_'+prefix+'_8',Number.isFinite(rahu)?longitude(rahu+HALF):'');
    }
    if(Object.hasOwn(positions,'राहू')){
      for(const field of ['motion','hours','minutes','total'])set('p6_'+field+'_8',get('p6_'+field+'_7').replace(/\s+R$/i,''));
      const birth=angle(get('p6_birth_7'));
      set('p6_birth_8',Number.isFinite(birth)?longitude(birth+HALF):'');
      positions['केतू']=finalPosition(8,positions['राहू']+HALF,false);
    }else clear(8);
    const baseDate=document.getElementById('p6_birth_pos_date');
    if(baseDate){baseDate.value=dob;baseDate.disabled=true;}
    const horaryPositions=window.KPHorary?.applyPlanets();
    window.lastPlanetPositions=horaryPositions||positions;
    return window.lastPlanetPositions;
  }
  window.updatePlanet6Automatic=calculate;
  window.calculateTab6SunMethod=calculate;
  let timer;
  function refresh(event){
    if(event&&!event.target?.closest('#basic,#planet'))return;
    calculate();
    clearTimeout(timer);timer=setTimeout(calculate,70);
  }
  document.addEventListener('DOMContentLoaded',()=>{
    document.addEventListener('input',refresh);
    document.addEventListener('change',refresh);
    // All older worksheet initialization timers have finished before this last
    // pass; main Calculate and load/import also call the authoritative function.
    calculate();setTimeout(calculate,650);setTimeout(calculate,1250);
  });
})();

