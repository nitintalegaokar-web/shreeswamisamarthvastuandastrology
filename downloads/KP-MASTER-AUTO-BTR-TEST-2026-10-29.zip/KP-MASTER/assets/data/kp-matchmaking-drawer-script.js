
(()=>{'use strict';const $=id=>document.getElementById(id);let queued=false;
function sync(){queued=false;const drawer=$('mm-settings-drawer');if(!drawer)return;const kp=$('mm-settings-kp');kp.hidden=$('mm-kp-panel')?.hidden||false;
 const report=$('mm-kp-analysis')?.querySelector('.mm-kp-report'),table=report?.querySelector('.kp-feature-scroll');if(table?.nextElementSibling){const evidence=$('mm-settings-evidence');evidence.replaceChildren();while(table.nextElementSibling)evidence.append(table.nextElementSibling);}
 if(table){let detail=$('mm-category-evidence');if(!detail){detail=document.createElement('div');detail.id='mm-category-evidence';$('mm-settings-evidence').prepend(detail);}const signature=table.innerHTML;if(detail.dataset.signature!==signature){detail.dataset.signature=signature;const rows=[...table.querySelectorAll('tbody tr')];detail.innerHTML='<h3>House evidence</h3><table class="kp-feature-table"><thead><tr><th>KP category</th><th>House evidence</th></tr></thead><tbody>'+rows.map(r=>'<tr><th>'+r.cells[0].innerHTML+'</th><td>'+r.cells[r.cells.length-1].innerHTML+'</td></tr>').join('')+'</tbody></table>';}}
 const status=$('mm-status');if(status&&!drawer.contains(status))$('mm-settings-common').append(status);
}
function schedule(){if(queued)return;queued=true;queueMicrotask(sync);}
function init(){const section=$('matchmaking'),panel=$('mm-kp-panel');if(!section||!panel)return;const drawer=document.createElement('details');drawer.id='mm-settings-drawer';drawer.className='mm-settings-drawer';drawer.innerHTML='<summary>Matchmaking settings and details</summary><div id="mm-settings-kp"><div id="mm-settings-evidence"></div></div><div id="mm-settings-common"></div>';panel.after(drawer);
 const kp=$('mm-settings-kp'),analysis=$('mm-kp-analysis');while(analysis.nextElementSibling)kp.append(analysis.nextElementSibling);
 const common=$('mm-settings-common'),main=section.querySelector('.mm-reference-main');for(const node of [...main.children]){if(node.matches('details,.mm-note,.mm-status')||node.id==='mm-status')common.append(node);}
 const label=main.querySelector(':scope>h2');if(label)label.hidden=true;
 new MutationObserver(schedule).observe(analysis,{childList:true,subtree:true});new MutationObserver(schedule).observe(panel,{attributes:true,attributeFilter:['hidden']});sync();}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(init,0));else init();})();


