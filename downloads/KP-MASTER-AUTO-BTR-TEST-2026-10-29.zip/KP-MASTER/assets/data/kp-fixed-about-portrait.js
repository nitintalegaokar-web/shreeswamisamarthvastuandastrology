
window.KPFixedAboutPortrait='assets/about-portrait.jpg';

