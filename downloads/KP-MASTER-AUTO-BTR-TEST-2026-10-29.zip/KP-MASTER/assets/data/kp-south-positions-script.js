
(()=>{'use strict';const $=id=>document.getElementById(id);let timer,method='basic';
const views={basic:'Basic calculations',fourfold:'Four-fold significators',sixfold:'Six-fold significators',fourstep:'Four-step Theory',nadi:'Nadi significators'};
function copy(id){const source=$(id);if(!source)return '';const clone=source.cloneNode(true);[clone,...clone.querySelectorAll('*')].forEach(n=>{for(const a of [...n.attributes])if(['id','name','for','contenteditable','tabindex','data-bridge-id'].includes(a.name)||/^on/i.test(a.name))n.removeAttribute(a.name);});clone.hidden=false;return clone.outerHTML;}
function refresh(){
 const mount=$('south-position-tables');if(!mount)return;
 mount.querySelectorAll('[data-south-method]').forEach(b=>{const selected=b.dataset.southMethod===method;b.setAttribute('aria-pressed',String(selected));b.classList.toggle('active',selected);});
 const chooser=$('south-nadi-event-row'),sourceEvent=$('na-event'),eventSelect=$('south-nadi-event');if(chooser)chooser.hidden=method!=='nadi';if(sourceEvent&&eventSelect){if(eventSelect.innerHTML!==sourceEvent.innerHTML)eventSelect.innerHTML=sourceEvent.innerHTML;eventSelect.value=sourceEvent.value;}
 const body=$('south-calculation-body'),model=window.currentKPModel;let html='';
 if(!model?.ready)html='<p>Complete the birth details to calculate positions and significators.</p>';
 else if(method==='fourstep')html='<h3>Four-step Theory</h3>'+copy('kp-fourstep');
 else if(method==='nadi')html='<h3>Nadi significators · नाडी कारक</h3><div class="na-grid">'+($('na-grid')?.innerHTML||'')+'</div>';
 else html='<article><h3>Planets · '+views[method]+'</h3><div class="south-table-scroll" tabindex="0" aria-label="Planet calculation table">'+copy('kp-'+method+'-planet')+'</div></article><article><h3>Houses · '+views[method]+'</h3><div class="south-table-scroll" tabindex="0" aria-label="Cusp calculation table">'+copy('kp-'+method+'-house')+'</div></article>';
 if(body.innerHTML!==html)body.innerHTML=html;
 if(method==='nadi')body.querySelectorAll('[id],[data-bridge-id]').forEach(n=>{n.removeAttribute('id');n.removeAttribute('data-bridge-id');});
 const legend=$('south-calculation-legend'),markup=KPDisplay.legendHTML();if(legend.innerHTML!==markup)legend.innerHTML=markup;legend.hidden=KPPreferences.get().notationMarkers===false;
}
function schedule(){clearTimeout(timer);timer=setTimeout(refresh,80);}
function init(){
 const section=$('south9'),card=section.querySelector('.card');card.classList.add('south-simple-layout');const mount=document.createElement('section');mount.id='south-position-tables';mount.className='south-calculations';mount.setAttribute('aria-label','Chart calculations');
 mount.innerHTML='<header class="south-calculation-heading"><h2>Chart calculations</h2><div class="south-view-buttons" role="group" aria-label="South Indian significator view">'+Object.keys(views).map(key=>'<button type="button" data-south-method="'+key+'" aria-pressed="'+(key===method)+'">'+({basic:'Basic',fourfold:'Four-fold',sixfold:'Six-fold',fourstep:'Four-step',nadi:'Nadi Significators'}[key])+'</button>').join('')+'</div></header><label id="south-nadi-event-row" hidden>Event <select id="south-nadi-event" aria-label="Nadi event"></select></label><div id="south-calculation-body"></div><div id="south-calculation-legend" class="kp-notation-legend" aria-label="Planet and cusp notation meanings"></div>';card.append(mount);
 $('south-nadi-event').addEventListener('change',()=>{const source=$('na-event');if(source){source.value=$('south-nadi-event').value;source.dispatchEvent(new Event('change',{bubbles:true}));schedule();}});$('na-event')?.addEventListener('change',schedule);
 mount.addEventListener('click',e=>{const button=e.target.closest('[data-south-method]');if(!button)return;method=button.dataset.southMethod;refresh();e.stopPropagation();});
 section.querySelector('[onclick="autoFillKundali()"]')?.remove();const status=$('kundaliEditStatus');if(status)status.hidden=true;section.querySelector('.kundali-style-label')?.remove();section.querySelector('.kundali-note')?.remove();section.querySelector('#south-single-page-print')?.remove();if($('south-single-page-preview'))$('south-single-page-preview').textContent='Preview · Print / PDF';
 for(const id of ['kp-basic-planet','kp-basic-house','kp-fourfold-planet','kp-fourfold-house','kp-sixfold-planet','kp-sixfold-house','kp-fourstep','na-grid']){const n=$(id);if(n)new MutationObserver(schedule).observe(n,{childList:true,subtree:true});}
 for(const e of ['chart-saved','chart-manual-change','kp-preferences-changed'])window.addEventListener(e,schedule);new MutationObserver(()=>{if(section.classList.contains('active'))refresh();}).observe(section,{attributes:true,attributeFilter:['class']});refresh();
}
window.KPSouthPositions=Object.freeze({refresh,getMethod:()=>method});if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(init,0));else init();})();

