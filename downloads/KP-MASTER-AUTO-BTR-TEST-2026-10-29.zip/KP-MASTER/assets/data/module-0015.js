

document.addEventListener("DOMContentLoaded",()=>{
  ["lmtDeg","lmtKala","birthTime","stdLon","placeStdLon","lon"].forEach(id=>{
    const el=document.getElementById(id);
    if(el) el.addEventListener("input",updateLMTCalculation);
  });
  updateLMTCalculation();
});


