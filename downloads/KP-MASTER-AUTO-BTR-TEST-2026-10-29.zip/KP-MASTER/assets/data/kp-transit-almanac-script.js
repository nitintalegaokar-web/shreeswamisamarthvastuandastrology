
(() => {
  'use strict';
  const DAY=86400000,HOUR=3600000,IDS=['Su','Mo','Ma','Me','Ju','Ve','Sa','Ra','Ke'];
  const byId=id=>document.getElementById(id),value=id=>String(byId(id)?.value||'').trim();
  const escape=text=>String(text??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const signed=angle=>((angle+540)%360)-180;
  let panchangData=null,panchangSignature='',ephemerisData=null,ephemerisSignature='',runToken=0,running=false,defaultsReady=false;
  function coordinate(text){
    const match=/^([+-]?\d+(?:\.\d+)?)(?::([0-5]?\d))?(?::([0-5]?\d))?$/.exec(String(text||'').trim());
    if(!match)return NaN;
    return (match[1].startsWith('-')?-1:1)*(Math.abs(Number(match[1]))+Number(match[2]||0)/60+Number(match[3]||0)/3600);
  }
  function dateOK(text){const date=new Date(text+'T00:00:00Z');return /^\d{4}-\d{2}-\d{2}$/.test(text)&&Number.isFinite(date.getTime())&&date.toISOString().slice(0,10)===text&&text>='1900-01-01'&&text<='2100-12-31';}
  function timeValue(text){const normalized=/^\d{2}:\d{2}$/.test(text)?text+':00':text;if(!/^([01]\d|2[0-3]):[0-5]\d:[0-5]\d$/.test(normalized))throw new Error('Choose a valid local time, including hours and minutes.');return normalized;}
  function timezone(id){const text=value(id),number=Number(text);if(!text||!Number.isFinite(number)||Math.abs(number)>14)throw new Error('Enter a UTC offset between −14 and +14 hours.');return number;}
  function utc(date,time,offset){if(!dateOK(date))throw new Error('Choose a valid date from 1900 through 2100.');return window.KPEphemeris.dateValue(new Date(Date.parse(date+'T'+time+'Z')-offset*HOUR));}
  function dateText(text){return window.KPPreferences?.isConfigured()?window.KPPreferences.formatDate(text):text.slice(8,10)+'/'+text.slice(5,7)+'/'+text.slice(0,4);}
  function timeText(text){return window.KPPreferences?.isConfigured()?window.KPPreferences.formatTime(text):text;}
  function offsetText(offset){const seconds=Math.round(Math.abs(offset)*3600);return (offset<0?'−':'+')+String(Math.floor(seconds/3600)).padStart(2,'0')+':'+String(Math.floor(seconds%3600/60)).padStart(2,'0')+(seconds%60?':'+String(seconds%60).padStart(2,'0'):'');}
  function localStamp(date,offset){return new Date(date.getTime()+offset*HOUR).toISOString();}
  function seed(id,text){if(byId(id)&&!value(id))byId(id).value=String(text);}
  function defaults(){
    mount();
    if(defaultsReady||!byId('tp-date')||!byId('eph-start'))return;
    defaultsReady=true;
    const meridian=coordinate(value('stdLon'))/15,offset=Number.isFinite(meridian)&&Math.abs(meridian)<=14?meridian:-new Date().getTimezoneOffset()/60;
    seed('tp-timezone',offset);seed('eph-timezone',offset);
    const tpOffset=Number(value('tp-timezone')),ephOffset=Number(value('eph-timezone'));
    const today=localStamp(new Date(),Number.isFinite(tpOffset)?tpOffset:offset);
    seed('tp-date',today.slice(0,10));seed('tp-time',today.slice(11,19));
    const epToday=localStamp(new Date(),Number.isFinite(ephOffset)?ephOffset:offset).slice(0,10);
    seed('eph-start',epToday);seed('eph-end',epToday);seed('eph-time','12:00:00');
    const latitude=coordinate(value('lat')),longitude=coordinate(value('lon'));
    if(Number.isFinite(latitude))seed('tp-latitude',latitude.toFixed(6));
    if(Number.isFinite(longitude))seed('tp-longitude',longitude.toFixed(6));
    seed('tp-place',value('birthPlace'));
  }
  function signature(ids){return JSON.stringify(ids.map(value).concat([value('dob'),value('ayanValue'),value('kp-ayanamsha-source'),window.KPPreferences?.get().combustionRule||'planet-specific']));}
  const tpSignature=()=>signature(['tp-date','tp-time','tp-timezone','tp-latitude','tp-longitude','tp-place']);
  const ephSignature=()=>signature(['eph-start','eph-end','eph-time','eph-timezone']);
  function status(id,text,state='idle'){const element=byId(id);if(element){element.textContent=text;element.dataset.state=state;}}
  function enableEphemeris(){if(byId('eph-run'))byId('eph-run').disabled=running;if(byId('eph-cancel')){byId('eph-cancel').disabled=!running;byId('eph-cancel').hidden=!running;}for(const id of ['eph-csv','eph-print'])if(byId(id))byId(id).disabled=!ephemerisData?.ready||running;}
  function clearPanchang(message,state='idle'){
    panchangData=null;panchangSignature='';if(byId('tp-summary'))byId('tp-summary').replaceChildren();
    if(byId('tp-positions'))byId('tp-positions').querySelector('tbody').innerHTML='<tr><td colspan="8">'+escape(message)+'</td></tr>';
    if(byId('tp-print'))byId('tp-print').disabled=true;status('tp-status',message,state);
  }
  function clearEphemeris(message,state='idle'){
    ephemerisData=null;ephemerisSignature='';if(byId('eph-summary'))byId('eph-summary').textContent='';
    if(byId('eph-table'))byId('eph-table').querySelector('tbody').innerHTML='<tr><td colspan="11">'+escape(message)+'</td></tr>';
    status('eph-status',message,state);enableEphemeris();
  }
  function planetsAt(date){
    const positions=window.KPEphemeris.positions(date);
    // Ephemeris positions are degrees; all KP lord calculations use arcseconds.
    const low=Math.max(Date.UTC(1900,0,1),date.getTime()-6*HOUR),high=Math.min(Date.UTC(2101,0,1)-1,date.getTime()+6*HOUR);
    const before=window.KPEphemeris.positions(new Date(low)),after=window.KPEphemeris.positions(new Date(high));
    const planets=IDS.map(id=>({id,longitude:positions[id],details:window.KPDisplay.longitudeDetails(positions[id]*3600),retrograde:signed(after[id]-before[id])<0,motionDegreesPerDay:signed(after[id]-before[id])*DAY/(high-low)}));
    const model={ready:true,planets:planets.map(p=>({id:p.id,...p.details,retrograde:p.retrograde}))};
    const retrograde=Object.fromEntries(planets.map(p=>[p.id,p.retrograde]));
    for(const planet of planets){planet.markers=window.KPDisplay.getNotations(planet.id,model,{retrograde});planet.combust=planet.markers.includes('[C]');}
    return {positions,planets};
  }
  function riseSet(date,latitude,longitude,offset,direction){
    const start=new Date(Date.parse(date+'T00:00:00Z')-offset*HOUR),observer=new Astronomy.Observer(latitude,longitude,0);
    const result=Astronomy.SearchRiseSet(Astronomy.Body.Sun,observer,direction,start,1);
    return result&&result.date.getTime()>=start.getTime()&&result.date.getTime()<start.getTime()+DAY?result.date.toISOString():null;
  }
  function eventTime(iso,offset){if(!iso)return 'No event on this date';const stamp=localStamp(new Date(iso),offset);return timeText(stamp.slice(11,19));}
  function valueHTML(label,text,note=''){return '<div class="almanac-value"><dt>'+escape(label)+'</dt><dd>'+escape(text)+(note?'<small>'+escape(note)+'</small>':'')+'</dd></div>';}
  function panchangSummary(data){const p=data.panchang;return [
    ['Weekday',p.weekday,'Civil day at selected UTC offset'],['Tithi',p.tithi,p.paksha+' paksha · tithi '+p.tithiNumber],['Nakshatra',p.nakshatra,'Pada '+p.pada+' · lord '+p.nakLord],
    ['Yoga',p.yoga],['Karana',p.karana],['Moon rashi',p.rashi],['Sunrise',eventTime(data.sunrise,data.timezone)],['Sunset',eventTime(data.sunset,data.timezone)],
    ['Day length',data.sunrise&&data.sunset&&Date.parse(data.sunset)>Date.parse(data.sunrise)?Math.floor(Math.round((Date.parse(data.sunset)-Date.parse(data.sunrise))/60000)/60)+'h '+Math.round((Date.parse(data.sunset)-Date.parse(data.sunrise))/60000)%60+'m':'—']
  ].map(item=>valueHTML(...item)).join('');}
  function positionRows(points){return points.map(planet=>{const d=planet.details;return '<tr data-planet="'+escape(planet.id)+'"><th scope="row">'+escape(planet.id)+(planet.retrograde&&!['Ra','Ke'].includes(planet.id)?' [R]':'')+(planet.combust?' [C]':'')+'</th><td>'+escape(d.signCode)+'</td><td>'+escape(d.degree)+'</td><td>'+escape(d.nakshatra)+' ('+d.pada+')</td><td>'+escape(d.sgl)+'</td><td>'+escape(d.stl)+'</td><td>'+escape(d.sl)+'</td><td>'+escape(d.ssl)+'</td></tr>';}).join('');}
  function calculatePanchang(){
    defaults();
    try{
      if(!window.KPEphemeris||!window.KPDisplay||!window.KPSinglePageReport?.panchang)throw new Error('The offline ephemeris or Panchang calculation is unavailable.');
      const date=value('tp-date'),time=timeValue(value('tp-time')),offset=timezone('tp-timezone'),moment=utc(date,time,offset);
      const latitudeText=value('tp-latitude'),longitudeText=value('tp-longitude'),latitude=coordinate(latitudeText),longitude=coordinate(longitudeText);
      if(!latitudeText||!Number.isFinite(latitude)||Math.abs(latitude)>=89)throw new Error('Enter latitude between −89° and +89°, excluding these limits.');
      if(!longitudeText||!Number.isFinite(longitude)||Math.abs(longitude)>180)throw new Error('Enter longitude between −180° and +180°.');
      const points=planetsAt(moment),panchang=window.KPSinglePageReport.panchang(points.positions.Su*3600,points.positions.Mo*3600,date);
      const ascendant=window.KPEphemeris.ascendant(moment,latitude,longitude);
      panchangData={ready:true,utc:moment.toISOString(),localDate:date,localTime:time,timezone:offset,latitude,longitude,place:value('tp-place'),ayanamsha:window.KPEphemeris.ayanamsha(moment),panchang,sunrise:riseSet(date,latitude,longitude,offset,1),sunset:riseSet(date,latitude,longitude,offset,-1),...points,ascendant:{id:'As',longitude:ascendant,details:window.KPDisplay.longitudeDetails(ascendant*3600)}};
      panchangSignature=tpSignature();byId('tp-summary').innerHTML=panchangSummary(panchangData);
      byId('tp-positions').querySelector('tbody').innerHTML=positionRows([...points.planets,panchangData.ascendant]);
      byId('tp-print').disabled=false;
      status('tp-status',dateText(date)+' · '+timeText(time)+' · UTC '+offsetText(offset)+(panchangData.place?' · '+panchangData.place:'')+' · Ayanamsha '+window.KPDisplay.formatDegree(panchangData.ayanamsha*3600),'ready');
      return getPanchangData();
    }catch(error){clearPanchang(error.message||'Panchang could not be calculated.','error');return null;}
  }
  function getPanchangData(){if(panchangData&&panchangSignature!==tpSignature())clearPanchang('Settings changed. Calculate to update Panchang.');return panchangData?JSON.parse(JSON.stringify(panchangData)):null;}
  function refreshPanchang(){return calculatePanchang();}
  function snapshotPanchang(){
    defaults();if(!getPanchangData())calculatePanchang();
    if(!panchangData)return '<div class="almanac-report"><p>'+escape(byId('tp-status')?.textContent||'Calculate Transit Panchang.')+'</p></div>';
    const d=panchangData;
    return '<div class="almanac-report"><p>'+escape(dateText(d.localDate)+' '+timeText(d.localTime)+' · UTC '+offsetText(d.timezone)+(d.place?' · '+d.place:'')+' · Latitude '+window.KPClientPresentation.formatCoordinate(Number(d.latitude),false)+', longitude '+window.KPClientPresentation.formatCoordinate(Number(d.longitude),true))+'</p><dl class="almanac-grid">'+panchangSummary(d)+'</dl><h3>Sidereal transit positions · SGL / STL / SBL / SSL</h3><table>'+byId('tp-positions').querySelector('thead').outerHTML+'<tbody>'+positionRows([...d.planets,d.ascendant])+'</tbody></table><p>Values apply to the selected instant. Sunrise and sunset use the selected local civil date and sea-level location. Sidereal geocentric positions; '+escape(window.KPEphemeris.convention())+'. Mean Rahu; Ketu exactly 180° opposite. R: retrograde; C: combust using your selected limits.</p></div>';
  }
  function ephemerisRows(data){return data.rows.map(day=>day.planets.map((planet,index)=>{const d=planet.details;return '<tr data-date="'+day.date+'" data-planet="'+planet.id+'"'+(index===0?' data-first="true"':'')+'><th scope="row">'+escape(dateText(day.date))+'</th><td>'+planet.id+'</td><td>'+escape(d.signCode)+'</td><td>'+escape(d.degree)+'</td><td>'+escape(d.nakCode)+' ('+d.pada+')</td><td>'+d.sgl+'</td><td>'+d.stl+'</td><td>'+d.sl+'</td><td>'+d.ssl+'</td><td>'+(planet.retrograde?'[R]':'D')+'</td><td>'+(planet.combust?'[C]':'—')+'</td></tr>';}).join('')).join('');}
  function ephemerisMetadata(data){return dateText(data.start)+' to '+dateText(data.end)+' · '+data.days+' day'+(data.days===1?'':'s')+' · Daily at '+timeText(data.time)+' · UTC '+offsetText(data.timezone);}
  async function runEphemeris(){
    defaults();const token=++runToken;running=true;clearEphemeris('Calculating daily ephemeris…','running');
    try{
      const start=value('eph-start'),end=value('eph-end'),time=timeValue(value('eph-time')),offset=timezone('eph-timezone');
      if(!dateOK(start)||!dateOK(end))throw new Error('Choose valid start and end dates from 1900 through 2100.');
      const first=Date.parse(start+'T00:00:00Z'),last=Date.parse(end+'T00:00:00Z'),days=Math.round((last-first)/DAY)+1;
      if(days<1)throw new Error('The end date must be on or after the start date.');if(days>366)throw new Error('Choose no more than 366 days, including the start and end dates.');
      utc(start,time,offset);utc(end,time,offset);
      const expectedSignature=ephSignature(),rows=[];
      for(let index=0;index<days;index++){
        if(token!==runToken)return null;
        if(expectedSignature!==ephSignature())throw new Error('Settings changed. Calculate again to update the ephemeris.');
        const date=new Date(first+index*DAY).toISOString().slice(0,10),moment=utc(date,time,offset),points=planetsAt(moment);
        rows.push({date,utc:moment.toISOString(),ayanamsha:window.KPEphemeris.ayanamsha(moment),planets:points.planets});
        if(index%4===0){status('eph-status','Calculating '+(index+1)+' of '+days+' days…','running');await new Promise(resolve=>setTimeout(resolve,0));}
      }
      if(token!==runToken)return null;
      if(expectedSignature!==ephSignature())throw new Error('Settings changed. Calculate again to update the ephemeris.');
      ephemerisData={ready:true,start,end,time,timezone:offset,days,rows};ephemerisSignature=expectedSignature;
      byId('eph-table').querySelector('tbody').innerHTML=ephemerisRows(ephemerisData);byId('eph-summary').textContent=ephemerisMetadata(ephemerisData);
      status('eph-status','Calculated '+days+' days · '+(days*IDS.length)+' planet positions.','ready');return getEphemerisData();
    }catch(error){if(token===runToken)clearEphemeris(error.message||'The daily ephemeris could not be calculated.','error');return null;}
    finally{if(token===runToken){running=false;enableEphemeris();}}
  }
  function cancelEphemeris(){runToken++;running=false;clearEphemeris('Calculation cancelled. Choose your dates and calculate again.');}
  function getEphemerisData(){if(ephemerisData&&ephemerisSignature!==ephSignature())clearEphemeris('Settings changed. Calculate to update the ephemeris.');return ephemerisData?JSON.parse(JSON.stringify(ephemerisData)):null;}
  function refreshEphemeris(){defaults();getEphemerisData();return getEphemerisData();}
  function snapshotEphemeris(){
    defaults();getEphemerisData();
    if(!ephemerisData)return '<div class="almanac-report"><p>'+escape(byId('eph-status')?.textContent||'Choose dates and calculate the daily ephemeris.')+'</p></div>';
    return '<div class="almanac-report"><p>'+escape(ephemerisMetadata(ephemerisData))+'</p><table>'+byId('eph-table').querySelector('thead').outerHTML+'<tbody>'+ephemerisRows(ephemerisData)+'</tbody></table><p>Daily sidereal geocentric positions at the selected local time and fixed UTC offset. '+escape(window.KPEphemeris.convention())+'. Mean Rahu; Ketu exactly 180° opposite. SGL: sign lord; STL: star lord; SBL: sub lord; SSL: sub-sub lord. R: retrograde, D: direct; C: combust using your selected limits.</p></div>';
  }
  function csvCell(text){const source=String(text??'');return '"'+(/^[=+\-@\t\r]/.test(source)?"'":'')+source.replace(/"/g,'""')+'"';}
  function exportCSV(){
    const data=getEphemerisData();if(!data)return;
    const rows=[['Date','Local time','UTC offset hours','Planet','Sign','DMS','Nakshatra','Pada','SGL','STL','SBL','SSL','Motion','Combust','Sidereal longitude degrees']];
    for(const day of data.rows)for(const p of day.planets)rows.push([day.date,data.time,data.timezone,p.id,p.details.signCode,p.details.degree,p.details.nakshatra,p.details.pada,p.details.sgl,p.details.stl,p.details.sl,p.details.ssl,p.retrograde?'R':'D',p.combust?'C':'',p.longitude.toFixed(8)]);
    const url=URL.createObjectURL(new Blob(['\ufeff'+rows.map(row=>row.map(csvCell).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}));
    const link=document.createElement('a');link.href=url;link.download='KP-Ephemeris-'+data.start+'-to-'+data.end+'.csv';document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
  function copyTransit(target){
    defaults();const mapping=target==='tp'?{'tp-date':'tc-date','tp-time':'tc-time','tp-timezone':'tc-timezone','tp-place':'tc-place','tp-latitude':'tc-latitude','tp-longitude':'tc-longitude'}:{'eph-start':'tc-date','eph-end':'tc-date','eph-time':'tc-time','eph-timezone':'tc-timezone'};
    for(const [destination,source]of Object.entries(mapping))if(value(source))byId(destination).value=value(source);
    if(target==='tp')calculatePanchang();else{cancelEphemeris();status('eph-status','Copied Transit Chart moment. Calculate to produce the daily ephemeris.');}
  }
  function nowPanchang(){defaults();try{const offset=timezone('tp-timezone'),stamp=localStamp(new Date(),offset);byId('tp-date').value=stamp.slice(0,10);byId('tp-time').value=stamp.slice(11,19);return calculatePanchang();}catch(error){clearPanchang(error.message,'error');return null;}}
  function field(id,label,type,extra=''){return '<label for="'+id+'">'+label+'<input id="'+id+'" type="'+type+'" '+extra+'></label>';}
  function mount(){
    const tp=byId('transit-panchang'),eph=byId('ephemeris');
    if(tp&&!byId('tp-date')){
      tp.innerHTML='<div class="card almanac-card"><h2>Transit Panchang</h2><p class="almanac-note">Choose a date, time and place to see the Panchang and transit lord details together.</p><div class="almanac-controls">'+field('tp-date','Local date','date','min="1900-01-01" max="2100-12-31"')+field('tp-time','Local time','time','step="1"')+field('tp-timezone','UTC offset (hours)','number','min="-14" max="14" step="any"')+field('tp-place','Place','text')+field('tp-latitude','Latitude (° north; negative south)','text','inputmode="decimal"')+field('tp-longitude','Longitude (° east; negative west)','text','inputmode="decimal"')+'</div><div class="almanac-actions"><button id="tp-calculate" type="button">Calculate Panchang</button><button id="tp-now" type="button">Now</button><button id="tp-copy-transit" type="button">Use Transit Chart moment</button><button id="tp-print" type="button" disabled>Select for print</button></div><p id="tp-status" class="almanac-status" role="status" aria-live="polite">Calculate Panchang for the selected moment.</p><dl id="tp-summary" class="almanac-grid"></dl><div class="almanac-table-wrap"><table id="tp-positions" class="almanac-table"><caption>Sidereal transit positions · degrees within each sign</caption><thead><tr><th>Planet / Asc</th><th>Sign</th><th>DMS</th><th>Nakshatra (Pada)</th><th>SGL</th><th>STL</th><th>SBL</th><th>SSL</th></tr></thead><tbody><tr><td colspan="8">Calculate Panchang for the selected moment.</td></tr></tbody></table></div><p class="almanac-note">Panchang values apply to the selected instant. Sunrise and sunset use the selected local civil date, latitude and longitude at sea level. No sunrise or sunset is shown if none occurs that day. Positions use the selected ayanamsha source (uploaded annual table, or manual birth ayanamsha advanced by 50.29″ per year); mean Rahu and opposite Ketu. Enter a valid native birth date and ayanamsha first.</p></div>';
      byId('tp-calculate').addEventListener('click',calculatePanchang);byId('tp-now').addEventListener('click',nowPanchang);byId('tp-copy-transit').addEventListener('click',()=>copyTransit('tp'));
      tp.addEventListener('input',()=>clearPanchang('Settings changed. Calculate to update Panchang.'));tp.addEventListener('change',()=>clearPanchang('Settings changed. Calculate to update Panchang.'));
    }
    if(eph&&!byId('eph-start')){
      eph.innerHTML='<div class="card almanac-card"><h2>Daily Ephemeris</h2><p class="almanac-note">Calculate nine planets for each selected date, at the same local time and UTC offset. Choose up to 366 days.</p><div class="almanac-controls">'+field('eph-start','Start date','date','min="1900-01-01" max="2100-12-31"')+field('eph-end','End date','date','min="1900-01-01" max="2100-12-31"')+field('eph-time','Daily local time','time','step="1"')+field('eph-timezone','UTC offset (hours)','number','min="-14" max="14" step="any"')+'</div><div class="almanac-actions"><button id="eph-run" type="button">Calculate ephemeris</button><button id="eph-cancel" type="button" disabled>Cancel calculation</button><button id="eph-copy-transit" type="button">Use Transit Chart moment</button><button id="eph-print" type="button" disabled>Select for print</button></div><p id="eph-status" class="almanac-status" role="status" aria-live="polite">Choose dates and calculate the daily ephemeris.</p><p id="eph-summary" class="almanac-note"></p><div class="almanac-table-wrap"><table id="eph-table" class="almanac-table"><caption>Nine grahas · exact Ketu opposite Rahu · sign-relative DMS</caption><thead><tr><th>Date</th><th>Planet</th><th>Sign</th><th>DMS</th><th>Nak (Pada)</th><th>SGL</th><th>STL</th><th>SBL</th><th>SSL</th><th>Motion</th><th>Combust</th></tr></thead><tbody><tr><td colspan="11">Choose dates and calculate the daily ephemeris.</td></tr></tbody></table></div><p class="almanac-note">Sidereal geocentric positions use the selected ayanamsha source: uploaded annual table, or manual birth ayanamsha advanced by 50.29″ per year. Rahu is the mean lunar node; Ketu is exactly 180° opposite. [R] marks retrograde motion; [C] uses your combustion settings. Latitude and longitude do not change these geocentric planet positions. Preview includes every calculated row.</p></div>';
      byId('eph-run').addEventListener('click',runEphemeris);byId('eph-cancel').addEventListener('click',cancelEphemeris);byId('eph-copy-transit').addEventListener('click',()=>copyTransit('eph'));
      const changed=()=>{runToken++;running=false;clearEphemeris('Settings changed. Calculate to update the ephemeris.');};eph.addEventListener('input',changed);eph.addEventListener('change',changed);
    }
  }
  window.KPTransitPanchang=Object.freeze({calculate:calculatePanchang,refresh:refreshPanchang,getData:getPanchangData,snapshot:snapshotPanchang,now:nowPanchang});
  window.KPDailyEphemeris=Object.freeze({run:runEphemeris,refresh:refreshEphemeris,cancel:cancelEphemeris,getData:getEphemerisData,snapshot:snapshotEphemeris,exportCSV});
  defaults();
})();

