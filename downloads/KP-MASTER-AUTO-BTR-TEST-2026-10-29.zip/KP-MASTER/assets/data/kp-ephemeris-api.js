
/* Offline ephemeris API. All returned longitudes and coordinates are DEGREES.
 * Astronomy Engine 2.1.19 supplies geocentric tropical positions.
 * Ayanamsha uses the uploaded annual DMS table when selected, otherwise the
 * worksheet's value at DOB advanced 50.29 arcsec/year.
 * Nodes use Meeus's mean ascending node polynomial; Ketu is exactly opposite.
 */
(() => {
  'use strict';
  const DAY = 86400000, YEAR = DAY * 365.2425;
  const bodies = {Su:'Sun', Mo:'Moon', Ma:'Mars', Me:'Mercury', Ju:'Jupiter', Ve:'Venus', Sa:'Saturn'};
  const norm = value => ((value % 360) + 360) % 360;
  function dateValue(value) {
    const date = value instanceof Date ? new Date(value.getTime()) : new Date(value);
    if (!Number.isFinite(date.getTime()) || date.getUTCFullYear() < 1900 || date.getUTCFullYear() > 2100) throw new Error('Ephemeris dates must be between 1900 and 2100.');
    return date;
  }
  function ayanamsha(value) {
    if(window.KPAnnualAyanamsha?.enabled())return window.KPAnnualAyanamsha.at(dateValue(value));
    const date = dateValue(value), birthText = document.getElementById('dob')?.value || '';
    const anchor = new Date(birthText + 'T00:00:00Z');
    const text = (document.getElementById('ayanValue')?.value || '').trim();
    const parts = text.split(':').map(Number);
    if (!/^\d+(?:\.\d+)?(?::\d+(?:\.\d+)?){0,2}$/.test(text) || parts.some(x => !Number.isFinite(x)) || parts[0] >= 360 || parts.slice(1).some(x=>x<0 || x>=60) || !/^\d{4}-\d{2}-\d{2}$/.test(birthText) || !Number.isFinite(anchor.getTime()) || anchor.toISOString().slice(0,10)!==birthText) throw new Error('Enter a valid birth date and calculated birth ayanamsha.');
    const degrees = parts[0] + (parts[1] || 0)/60 + (parts[2] || 0)/3600;
    return degrees + (date.getTime()-anchor.getTime())/YEAR * 50.29/3600;
  }
  function tropical(value, id) {
    const date = dateValue(value);
    if (id === 'Ra' || id === 'Ke') {
      const t = (date.getTime()/DAY + 2440587.5 - 2451545)/36525;
      const node = 125.0445479 - 1934.1362891*t + .0020754*t*t + t*t*t/467441 - t*t*t*t/60616000;
      return norm(node + (id==='Ke'?180:0));
    }
    if (!bodies[id]) throw new Error('Unknown transit planet: ' + id);
    if (id === 'Mo') return Astronomy.EclipticGeoMoon(date).lon;
    return Astronomy.Ecliptic(Astronomy.GeoVector(bodies[id], date, true)).elon;
  }
  function longitude(value, id) { return norm(tropical(value, id) - ayanamsha(value)); }
  function positions(value) {
    const date = dateValue(value), ayan = ayanamsha(date);
    return Object.fromEntries([...Object.keys(bodies),'Ra','Ke'].map(id=>[id,norm(tropical(date,id)-ayan)]));
  }
  function ascendant(value, latitude, longitudeEast) {
    const date = dateValue(value), lat=Number(latitude), lon=Number(longitudeEast);
    if (!Number.isFinite(lat) || Math.abs(lat)>=89 || !Number.isFinite(lon) || Math.abs(lon)>180) throw new Error('Use latitude between −89° and 89° and longitude between −180° and 180°.');
    const r = Math.PI/180, theta=(Astronomy.SiderealTime(date)*15+lon)*r, eps=Astronomy.e_tilt(Astronomy.MakeTime(date)).tobl*r;
    return norm(Math.atan2(Math.cos(theta), -Math.sin(theta)*Math.cos(eps)-Math.tan(lat*r)*Math.sin(eps))/r - ayanamsha(date));
  }
  const convention=()=>window.KPAnnualAyanamsha?.enabled()?'Uploaded annual Krishnamurti table · DMS column · interpolation between January 1 values':'Worksheet birth ayanamsha advanced by 50.29″/year';
  window.KPEphemeris = Object.freeze({positions, longitude, tropical, ascendant, ayanamsha, convention, normalize:norm, version:'Astronomy Engine 2.1.19', nodeModel:'mean lunar node', units:'degrees', dateValue});
  window.dispatchEvent(new CustomEvent('kp-ephemeris-ready'));
})();


