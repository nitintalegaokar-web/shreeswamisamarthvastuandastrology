import json,datetime as dt,pathlib,sys,math
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from generate import day_record,phase
root=pathlib.Path(__file__).parent
count=0;max_residual=0
for year in range(1900,2501):
 text=(root/'payload/years'/f'y{year}.js').read_text();raw=json.loads(text.split(']=',1)[1].rstrip(';\n'))
 assert raw['year']==year
 rows=raw['rows'];dates=[r[0] for r in rows];start=dt.date(year,1,1);end=dt.date(year+1,1,1)
 expected=[(start+dt.timedelta(days=i)).isoformat() for i in range((end-start).days)]
 assert [d for d in dates if d.startswith(str(year)+'-')]==expected,(year,'coverage')
 assert len(set(dates))==len(dates),(year,'duplicates')
 for r in rows:
  assert len(r)==34 and all(math.isfinite(v) for v in r[1:]),(year,'shape')
  assert r[1]<r[2]<r[1]+1
  assert 0<=r[3]<30 and 0<=r[5]<27 and 0<=r[7]<27 and 0<=r[9]<60
  assert all(0<=r[i]<360 for i in range(13,31,2))
  for index in (4,6,8,10):assert r[1]<r[index]<r[1]+3
 # Recompute one winter and one summer day from each year; verify root residuals.
 for key in (f'{year}-01-15',f'{year}-07-15'):
  row=rows[dates.index(key)];fresh=day_record(dt.date.fromisoformat(key));assert row==fresh
  for kind,i,unit in [('tithi',4,12),('nak',6,360/27),('yoga',8,360/27),('karana',10,6)]:
   angle,_=phase(row[i],kind);res=abs((angle+unit/2)%unit-unit/2);max_residual=max(max_residual,res)
   assert res<1e-5,(year,kind,res)
 count+=len(expected)
report={'years':601,'first':'1900-01-01','last':'2500-12-31','days':count,'coverage':'complete, ordered, unique','recomputed_sample_days':1202,'max_sample_transition_residual_arcseconds':max_residual*3600,'model':'Swiss Ephemeris 2.10.03 / Moshier','ayanamsa':'Krishnamurti','location':'Pune, IST','note':'Numerical/model checks do not certify festivals or external Panchang conventions.'}
(root/'data-validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
# Tropical apparent positions for an independent comparison with Astronomy Engine.
import swisseph as swe
samples=[]
for year,month,day in [(1900,1,1),(2000,1,1),(2024,4,8),(2026,11,14),(2100,6,21),(2500,12,31)]:
 jd=swe.julday(year,month,day,0)
 samples.append({'date':f'{year:04}-{month:02}-{day:02}T00:00:00Z','ttDaysJ2000':jd+swe.deltat(jd)-2451545,'sun':swe.calc_ut(jd,swe.SUN,swe.FLG_MOSEPH)[0][0],'moon':swe.calc_ut(jd,swe.MOON,swe.FLG_MOSEPH)[0][0]})
(root/'tropical-samples.json').write_text(json.dumps(samples))
