from pathlib import Path
import base64,json
r=Path(__file__).resolve().parent
css=(r/'payload/studio.css').read_text()+'\n'+(r/'payload/desktop.css').read_text()
font='data:font/ttf;base64,'+base64.b64encode((r/'payload/fonts/NotoSansDevanagari-Regular.ttf').read_bytes()).decode()
(r/'payload/export-assets.js').write_text('window.KP_EXPORT_ASSETS='+json.dumps({'css':css,'font':font})+';\n')
logo=r/'payload/assets/logo.png'
if logo.exists():(r/'payload/brand.js').write_text('window.KP_DEFAULT_LOGO='+json.dumps('data:image/png;base64,'+base64.b64encode(logo.read_bytes()).decode())+';\n')
licenses=[]
for p in sorted((r/'node_modules').glob('*/package.json')):
 try:
  package=json.loads(p.read_text())
  if package['name'] in ['@playwright/test','playwright','playwright-core','esbuild','astronomy-engine']:continue
  licensefile=next((x for x in p.parent.iterdir() if x.name.upper() in ['LICENSE','LICENSE.TXT','LICENSE.MD','LICENCE']),None)
  if licensefile:licenses.append(package['name']+' '+package.get('version','')+'\n'+licensefile.read_text(errors='replace'))
 except (ValueError,OSError):pass
(r/'payload/vendor/LICENSES.txt').write_text('\n\n'+'\n\n'.join(licenses))
