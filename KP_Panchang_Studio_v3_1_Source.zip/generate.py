"""Generate offline Pune / IST Panchang using pyswisseph 2.10.3.2.
No Swiss Ephemeris executable/library is shipped in the app, only calculated data.
Use: PYTHONPATH=python-tools python3 generate.py --start 1900 --end 2500
"""
import argparse,datetime as dt,json,math,pathlib,time
import swisseph as swe
ROOT=pathlib.Path(__file__).resolve().parent
swe.set_sid_mode(swe.SIDM_KRISHNAMURTI)
FLAGS=swe.FLG_MOSEPH|swe.FLG_SPEED
SID=FLAGS|swe.FLG_SIDEREAL
BODIES=[swe.SUN,swe.MOON,swe.MARS,swe.MERCURY,swe.JUPITER,swe.VENUS,swe.SATURN,swe.MEAN_NODE]
GEO=(73.8567,18.5204,0)

def calc(jd,body,sid=False):
    p,flags=swe.calc_ut(jd,body,SID if sid else FLAGS)
    if not flags&swe.FLG_MOSEPH: raise RuntimeError('Unexpected ephemeris model')
    return p

def phase(jd,kind):
    sun=calc(jd,swe.SUN,kind in ('nak','yoga'))
    moon=calc(jd,swe.MOON,kind in ('nak','yoga'))
    if kind in ('tithi','karana'): return (moon[0]-sun[0])%360,moon[3]-sun[3]
    if kind=='nak': return moon[0],moon[3]
    return (moon[0]+sun[0])%360,moon[3]+sun[3]

def limb(jd,kind):
    unit={'tithi':12,'karana':6,'nak':360/27,'yoga':360/27}[kind]
    angle,speed=phase(jd,kind); index=int(angle/unit); target=(index+1)*unit
    end=jd+(target-angle)/speed
    for _ in range(8):
        a,v=phase(end,kind); error=(a-target+180)%360-180
        if abs(error)<1e-8:break
        end-=error/v
    a,_=phase(end,kind)
    if abs((a-target+180)%360-180)>1e-6 or not jd<end<jd+3: raise RuntimeError('Invalid event solution')
    return index,round(end,8)

def day_record(date):
    jd=swe.julday(date.year,date.month,date.day,0)
    midnight=jd-5.5/24
    rise=swe.rise_trans(midnight,swe.SUN,swe.CALC_RISE,GEO,1013.25,15,swe.FLG_MOSEPH)
    setting=swe.rise_trans(midnight,swe.SUN,swe.CALC_SET,GEO,1013.25,15,swe.FLG_MOSEPH)
    if rise[0]!=0 or setting[0]!=0: raise RuntimeError('No sunrise or sunset in Pune')
    sr,ss=rise[1][0],setting[1][0]
    t,te=limb(sr,'tithi');n,ne=limb(sr,'nak');y,ye=limb(sr,'yoga');k,ke=limb(sr,'karana')
    p=[calc(jd,b,True) for b in BODIES]
    p.append(((p[-1][0]+180)%360,0,0,p[-1][3],0,0))
    return [date.isoformat(),round(sr,8),round(ss,8),t,te,n,ne,y,ye,k,ke,
            round(swe.get_ayanamsa_ut(jd),8),round(swe.sidtime(jd),8),
            *[round(v,7) for b in p for v in (b[0],b[3])],
            round(swe.houses_ex(jd,GEO[1],GEO[0],b'P',swe.FLG_SIDEREAL)[1][0],7),
            round(swe.calc_ut(jd,swe.ECL_NUT)[0][0],10),
            round(swe.calc_ut(jd,swe.ECL_NUT)[0][2],10)]

def generate(year):
    start=dt.date(year,1,1);end=dt.date(year+1,1,17)
    # Previous and next days support reports that cross a year boundary.
    date=start-dt.timedelta(days=1); rows=[]
    while date<end:
        rows.append(day_record(date));date+=dt.timedelta(days=1)
    meta={'year':year,'engine':'KP EPHEMERIES','model':'Moshier',
          'ayanamsa':'Krishnamurti (SE_SIDM_KRISHNAMURTI)', 'timezone':'IST (UTC+05:30)',
          'location':{'city':'Pune','latitude':GEO[1],'longitude':GEO[0],'altitude':0},
          'sunrise':'Apparent upper limb; pressure 1013.25 hPa; temperature 15 C',
          'limbs':'At local sunrise; transitions solved to <0.004 arcseconds; displayed nearest minute',
          'positions':'Geocentric sidereal, 05:30 IST; mean lunar nodes', 'rows':rows}
    dest=ROOT/'payload/years'/f'y{year}.js'
    dest.write_text('window.KP_YEARS=window.KP_YEARS||{};window.KP_YEARS['+str(year)+']='+json.dumps(meta,separators=(',',':'))+';\n')
    return len(rows)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--start',type=int,default=1900);p.add_argument('--end',type=int,default=2500);args=p.parse_args()
    start=time.time()
    for year in range(args.start,args.end+1):
        count=generate(year)
        print(f'{year}: {count} records ({time.time()-start:.1f}s elapsed)',flush=True)
