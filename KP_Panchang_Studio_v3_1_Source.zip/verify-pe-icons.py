from pathlib import Path
import struct,hashlib

def ico_hashes(path):
 data=Path(path).read_bytes();reserved,kind,count=struct.unpack_from('<HHH',data,0);assert reserved==0 and kind==1
 result=[]
 for i in range(count):
  size,offset=struct.unpack_from('<II',data,6+i*16+8)
  result.append(hashlib.sha256(data[offset:offset+size]).hexdigest())
 return result

def pe_icon_hashes(path):
 data=Path(path).read_bytes();pe=struct.unpack_from('<I',data,0x3c)[0];assert data[pe:pe+4]==b'PE\0\0'
 count=struct.unpack_from('<H',data,pe+6)[0];opsize=struct.unpack_from('<H',data,pe+20)[0];opt=pe+24;magic=struct.unpack_from('<H',data,opt)[0]
 dd=opt+(96 if magic==0x10b else 112)
 resource_rva=struct.unpack_from('<I',data,dd+16)[0];sections=[]
 for i in range(count):
  vs,va,rs,rp=struct.unpack_from('<IIII',data,opt+opsize+40*i+8);sections.append((va,max(vs,rs),rp))
 def raw(rva):
  for va,sz,rp in sections:
   if va<=rva<va+sz:return rp+rva-va
  raise ValueError('RVA outside sections')
 root=raw(resource_rva)
 def entries(offset):
  named,ids=struct.unpack_from('<HH',data,root+offset+12)
  return [struct.unpack_from('<II',data,root+offset+16+i*8) for i in range(named+ids)]
 found=[]
 for kind,offset in entries(0):
  if kind!=3:continue
  def walk(off):
   for _,child in entries(off&0x7fffffff):
    if child&0x80000000:walk(child)
    else:
     rva,size=struct.unpack_from('<II',data,root+child);blob=data[raw(rva):raw(rva)+size];found.append(hashlib.sha256(blob).hexdigest())
  walk(offset)
 return found

if __name__=='__main__':
 import sys
 expected=ico_hashes('payload/assets/logo.ico')
 for filename in sys.argv[1:]:
  actual=pe_icon_hashes(filename)
  assert set(expected).issubset(set(actual)),filename
  print('PASS:',filename,'contains all',len(expected),'uploaded-logo icon resolutions')
