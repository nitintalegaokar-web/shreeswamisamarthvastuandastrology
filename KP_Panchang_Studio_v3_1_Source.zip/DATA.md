Year files are reproduced by generate.py using the pinned requirement, or extracted from the installer. See BUILD-v3.md.
