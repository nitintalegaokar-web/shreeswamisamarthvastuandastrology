const A=require('astronomy-engine'),fs=require('fs'),assert=require('assert/strict');
const samples=JSON.parse(fs.readFileSync(__dirname+'/tropical-samples.json','utf8'));
const angle=(a,b)=>Math.abs((a-b+540)%360-180);
const report=samples.map(s=>{const date=A.AstroTime.FromTerrestrialTime(s.ttDaysJ2000),sun=A.SunPosition(date).elon,moon=A.EclipticGeoMoon(date).lon;const x={date:s.date,sunDifferenceArcminutes:angle(s.sun,sun)*60,moonDifferenceArcminutes:angle(s.moon,moon)*60};assert(x.sunDifferenceArcminutes<1);assert(x.moonDifferenceArcminutes<1);return x});
fs.writeFileSync(__dirname+'/independent-check.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));console.log('PASS: apparent tropical Sun and Moon agree with Astronomy Engine within 1 arcminute on 6 sampled epochs (1900–2500), using the same terrestrial time (TT).');
