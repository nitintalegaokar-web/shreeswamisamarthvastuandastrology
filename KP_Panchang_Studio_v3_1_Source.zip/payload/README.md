# KP Panchang Studio 3.1

KP EPHEMERIES · Offline edition · 1900–2500

The supplied KP Panchang Studio logo is bundled as the default app/report logo,
browser icon, Windows launcher icon, and installer/uninstaller icon.

## File
- New settings, Open settings and Save settings manage report preferences.
- Places library searches your saved city catalog.
- Import places reads Access MDB/ACCDB, CSV and JSON locally. Choose the place
  table and map its city and coordinate columns. Separate degree/minute/second
  and N/S/E/W columns are supported. Preview the first rows before importing.
  All valid rows are saved, including distinct places with the same city name.
- Export places saves the city catalog as JSON.
- Choose logo uses your PNG/JPG/WebP in the app and on reports. It also travels
  with Save settings. No file is uploaded to a server.

## View
Daily, monthly, annual and Paksha reports. North Indian Kundali uses fixed
houses with Rashi numbers; South Indian uses a fixed clockwise zodiac beginning
with Pisces at top left. The highlighted compartment contains Lagna. Switch
styles using the chart buttons or View menu. Compact view and Full screen are
available from View.

## Report
Choose Modern yearbook or Traditional Panchang. Both use one month per page.
Print current view or Print full year opens your browser/printer dialog, including
Save as PDF. Select the matching A4 orientation, 100% scale and disable browser
headers/footers. Print Kundali prints the chart separately. Save report as HTML
produces a self-contained offline report; Save Kundali as SVG preserves its chart.
Report header & paper controls the business name, contact, logo and page format.

## About
Version, calculation settings and third-party licenses are available here.

## Calculation settings
KP EPHEMERIES · Krishnamurti ayanamsa · mean lunar nodes. Panchang is for Pune,
IST. Selecting another place changes Kundali coordinates; it does not change
Pune's sunrise-based Panchang. Tithi/Nakshatra/Yoga/Karana are taken at sunrise.
Moon lords and planet positions are at 05:30 IST. +1 is the next civil day.
Paksha ingress/aspect times marked approx. use daily interpolation. Future civil
times depend on the Delta-T model. Festivals/muhurta are not included.

The app works offline; no Python, Node.js, account or server is needed. Extract
all portable files together, or use the Windows installer. The installer is
unsigned. Windows installation, shortcuts and file-URL launch still require a
Windows verification run. The development checks use local HTTP on Linux.

Fonts: fonts/LICENSE.txt. MDB reader and bundled dependencies: vendor/LICENSES.txt.
