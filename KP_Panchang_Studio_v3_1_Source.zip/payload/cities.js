window.KP_CITIES=[{"city":"Pune","latitude":18.5204,"longitude":73.8567,"state":"Maharashtra","country":"India"}];
