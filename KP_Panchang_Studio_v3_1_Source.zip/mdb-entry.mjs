import { Buffer } from 'buffer';
import MDBReader from 'mdb-reader';
globalThis.Buffer = Buffer;
globalThis.KPMdb = { open(bytes) { return new MDBReader(Buffer.from(bytes)); } };
