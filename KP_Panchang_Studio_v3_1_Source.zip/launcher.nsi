Unicode true
Name "KP Panchang"
OutFile "payload/KP Panchang.exe"
!if /FileExists "payload/assets/logo.ico"
Icon "payload/assets/logo.ico"
!endif
RequestExecutionLevel user
SilentInstall silent
AutoCloseWindow true
Section
  IfFileExists "$EXEDIR\index.html" found
  MessageBox MB_ICONSTOP "KP Panchang files are missing. Please reinstall the application."
  Quit
found:
  StrCpy $0 "$PROGRAMFILES64\Microsoft\Edge\Application\msedge.exe"
  IfFileExists "$0" launch
  StrCpy $0 "$PROGRAMFILES32\Microsoft\Edge\Application\msedge.exe"
  IfFileExists "$0" launch
  StrCpy $0 "$LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe"
  IfFileExists "$0" launch fallback
launch:
  Exec '"$0" --app="file:///$EXEDIR/index.html"'
  IfErrors fallback done
fallback:
  ExecShell "open" "$EXEDIR\index.html"
  IfErrors 0 done
  MessageBox MB_ICONSTOP "Unable to open KP Panchang. Install Microsoft Edge or set a default web browser and try again."
done:
SectionEnd
