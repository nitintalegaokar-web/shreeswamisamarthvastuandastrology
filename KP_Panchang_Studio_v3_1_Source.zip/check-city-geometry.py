import swisseph as swe,math,json,pathlib
swe.set_sid_mode(swe.SIDM_KRISHNAMURTI)
rows=[]
for y in (1900,2000,2026,2100,2500):
 for m in (1,6,11):
  jd=swe.julday(y,m,14,0)
  for lat,lon,name in [(18.5204,73.8567,'Pune'),(51.5074,-.1278,'London'),(-33.8688,151.2093,'Sydney'),(-80,73.8567,'Polar South'),(80,-73,'Polar North')]:
   exact=swe.houses_ex(jd,lat,lon,b'E',swe.FLG_SIDEREAL)[1][0]
   rows.append({'date':f'{y}-{m:02}-14','latitude':lat,'longitude':lon,'city':name,'expected':exact})
pathlib.Path('city-geometry-reference.json').write_text(json.dumps(rows))
